"""Loopback-only, serialized OpenAI-compatible inference for the v4 agent.

HTTP requests have a hard response deadline; CUDA generation is cooperatively
stopped between tokens. A timed-out generation keeps the busy gate until the
actual worker exits, so a slow CUDA operation cannot overlap another request.
"""
import argparse
import hmac
import json
import os
import queue
import stat
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY = 65536
MAX_INPUT_TOKENS = 6000
MAX_OUTPUT_TOKENS = 256
MAX_CALL_SECONDS = 30.0


class APIError(Exception):
    def __init__(self, status, code, message):
        super().__init__(message)
        self.status, self.code = status, code


def read_key_file(path):
    """Read an owner-only regular file without following a symlink."""
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
            raise ValueError("API key file must be regular and owner-only (0600 or 0400)")
        if hasattr(os, "getuid") and info.st_uid != os.getuid():
            raise ValueError("API key file must belong to the current user")
        value = os.read(fd, 1025).decode("ascii").strip()
        if not 16 <= len(value) <= 256 or any(c.isspace() for c in value):
            raise ValueError("API key file contains an invalid token")
        return value
    finally:
        os.close(fd)


def validate_request(value, model_name):
    if not isinstance(value, dict):
        raise APIError(400, "invalid_request_error", "Expected a JSON object")
    if value.get("model") != model_name:
        raise APIError(404, "model_not_found", "Unknown model")
    if value.get("stream", False) is not False:
        raise APIError(400, "invalid_request_error", "Streaming is not supported")
    if value.get("temperature", 0) != 0:
        raise APIError(400, "invalid_request_error", "Only temperature=0 is supported")
    count = value.get("max_tokens", 128)
    if type(count) is not int or not 1 <= count <= MAX_OUTPUT_TOKENS:
        raise APIError(400, "invalid_request_error", "max_tokens must be 1..256")
    messages = value.get("messages")
    if not isinstance(messages, list) or not 1 <= len(messages) <= 64:
        raise APIError(400, "invalid_request_error", "messages must contain 1..64 entries")
    for item in messages:
        if (not isinstance(item, dict) or item.get("role") not in ("system", "user", "assistant")
                or not isinstance(item.get("content"), str)):
            raise APIError(400, "invalid_request_error", "Only system/user/assistant plain-text messages are supported")
    return [{"role": m["role"], "content": m["content"]} for m in messages], count


class QwenGenerator:
    def __init__(self, model_dir):
        # Reuse the tested qwen3_5 class/device compatibility, never its skill or call path.
        from experiments.practice_v9.agent import Backend
        loaded = Backend(model_dir)
        self.tokenizer, self.model, self.device = loaded.tokenizer, loaded.model, loaded.device
        del loaded

    def generate(self, messages, max_tokens, deadline):
        import torch
        from transformers import StoppingCriteria, StoppingCriteriaList
        text = self.tokenizer.apply_chat_template(messages, tokenize=False,
            add_generation_prompt=True, enable_thinking=False)
        tokens = self.tokenizer(text, return_tensors="pt", add_special_tokens=False)
        prompt_count = int(tokens["input_ids"].shape[1])
        if prompt_count > MAX_INPUT_TOKENS:
            raise APIError(400, "context_length_exceeded", "Prompt exceeds 6000 input tokens")
        if time.monotonic() >= deadline:
            raise APIError(504, "generation_timeout", "Inference deadline exceeded")
        tokens = {k: v.to(self.device) for k, v in tokens.items()}

        class Deadline(StoppingCriteria):
            def __call__(self, input_ids, scores, **kwargs):
                return time.monotonic() >= deadline

        with torch.inference_mode():
            result = self.model.generate(**tokens, max_new_tokens=max_tokens, do_sample=False,
                pad_token_id=self.tokenizer.eos_token_id,
                stopping_criteria=StoppingCriteriaList([Deadline()]))
        if time.monotonic() >= deadline:
            raise APIError(504, "generation_timeout", "Inference deadline exceeded; partial output discarded")
        output = result[0, prompt_count:]
        output_count = int(output.shape[0])
        eos = getattr(self.model.generation_config, "eos_token_id", None)
        eos_ids = eos if isinstance(eos, (list, tuple)) else [eos]
        stopped = output_count > 0 and int(output[-1]) in eos_ids
        return dict(content=self.tokenizer.decode(output, skip_special_tokens=True).strip(),
            prompt_tokens=prompt_count, completion_tokens=output_count,
            finish_reason="length" if output_count >= max_tokens and not stopped else "stop")


class InferenceServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 8

    def __init__(self, address, generator, token, model_name="qwen27b-v4", call_seconds=MAX_CALL_SECONDS):
        if address[0] != "127.0.0.1":
            raise ValueError("Only 127.0.0.1 binding is allowed")
        if not 0 < call_seconds <= MAX_CALL_SECONDS:
            raise ValueError("Call deadline must be positive and at most 30 seconds")
        self.generator, self.token, self.model_name = generator, token, model_name
        self.call_seconds = call_seconds
        self.gate = threading.Lock()
        super().__init__(address, Handler)

    def infer(self, messages, max_tokens, deadline):
        if not self.gate.acquire(blocking=False):
            raise APIError(503, "server_busy", "Another inference is still running; retry later")
        result = queue.Queue(maxsize=1)

        def run():
            try:
                result.put((True, self.generator.generate(messages, max_tokens, deadline)))
            except APIError as exc:
                result.put((False, exc))
            except Exception:
                # Never expose model internals, prompt text, paths, or credentials.
                result.put((False, APIError(500, "model_error", "Model inference failed")))
            finally:
                self.gate.release()

        worker = threading.Thread(target=run, name="serialized-inference", daemon=True)
        try:
            worker.start()
        except Exception:
            self.gate.release()
            raise APIError(500, "model_error", "Unable to start inference worker")
        try:
            ok, value = result.get(timeout=max(0, deadline - time.monotonic()))
        except queue.Empty:
            raise APIError(504, "generation_timeout", "Inference exceeded request deadline")
        if time.monotonic() >= deadline:
            raise APIError(504, "generation_timeout", "Inference exceeded request deadline")
        if not ok:
            raise value
        return value


class Handler(BaseHTTPRequestHandler):
    server_version = "LocalModelAPI/1"

    def log_message(self, *args):
        pass

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def respond(self, status, value):
        body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        self.close_connection = True

    def do_GET(self):
        if self.path == "/health":
            self.respond(200, dict(status="ok", model=self.server.model_name,
                busy=self.server.gate.locked(), max_input_tokens=MAX_INPUT_TOKENS,
                max_output_tokens=MAX_OUTPUT_TOKENS, max_call_seconds=self.server.call_seconds))
        else:
            self.respond(404, {"error": {"code": "not_found", "message": "Unknown path"}})

    def do_POST(self):
        started = time.monotonic()
        try:
            if self.path != "/v1/chat/completions":
                raise APIError(404, "not_found", "Unknown path")
            supplied = self.headers.get("Authorization", "")
            if not hmac.compare_digest(supplied.encode(), ("Bearer " + self.server.token).encode()):
                raise APIError(401, "authentication_error", "Invalid bearer token")
            if self.headers.get("Transfer-Encoding"):
                raise APIError(400, "invalid_request_error", "Chunked requests are not supported")
            lengths = self.headers.get_all("Content-Length", [])
            if len(lengths) != 1 or not lengths[0].isdigit():
                raise APIError(400, "invalid_request_error", "One Content-Length header is required")
            length = int(lengths[0])
            if not 0 < length <= MAX_BODY:
                raise APIError(413, "request_too_large", "Body must be 1..65536 bytes")
            parts, remaining = [], length
            read_deadline = min(started + self.server.call_seconds, started + 5)
            while remaining:
                left = read_deadline - time.monotonic()
                if left <= 0:
                    raise APIError(408, "request_timeout", "Request body deadline exceeded")
                self.connection.settimeout(left)
                part = self.rfile.read1(remaining)
                if not part:
                    break
                parts.append(part)
                remaining -= len(part)
            raw = b"".join(parts)
            if len(raw) != length:
                raise APIError(400, "invalid_request_error", "Incomplete request body")
            try:
                value = json.loads(raw, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
            except (ValueError, UnicodeDecodeError):
                raise APIError(400, "invalid_request_error", "Invalid JSON body")
            messages, count = validate_request(value, self.server.model_name)
            self.connection.settimeout(5)
            output = self.server.infer(messages, count, started + self.server.call_seconds)
            usage = dict(prompt_tokens=output["prompt_tokens"], completion_tokens=output["completion_tokens"])
            usage["total_tokens"] = sum(usage.values())
            self.respond(200, dict(id="chatcmpl-" + uuid.uuid4().hex, object="chat.completion",
                created=int(time.time()), model=self.server.model_name, usage=usage,
                choices=[dict(index=0, message=dict(role="assistant", content=output["content"]),
                    finish_reason=output.get("finish_reason", "stop"))],
                elapsed_seconds=round(time.monotonic() - started, 6)))
        except APIError as exc:
            self.respond(exc.status, {"error": {"type": exc.code, "code": exc.code, "message": str(exc)}})
        except (TimeoutError, OSError):
            self.respond(408, {"error": {"code": "request_timeout", "message": "Request read timed out"}})
        except Exception:
            self.respond(500, {"error": {"code": "server_error", "message": "Request failed"}})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--key-file", required=True)
    parser.add_argument("--model-name", default="qwen27b-v4")
    parser.add_argument("--port", type=int, default=18027)
    args = parser.parse_args()
    key = read_key_file(args.key_file)
    server = InferenceServer(("127.0.0.1", args.port), QwenGenerator(args.model_dir), key, args.model_name)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
