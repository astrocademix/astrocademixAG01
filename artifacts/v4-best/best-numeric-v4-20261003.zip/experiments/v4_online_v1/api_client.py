"""No-retry OpenAI chat client with explicit timing and strict JSON-plan parsing."""
import json
import os
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse


class ClientError(RuntimeError):
    def __init__(self, code, elapsed_seconds, status=None):
        super().__init__(code)
        self.code, self.elapsed_seconds, self.status = code, elapsed_seconds, status


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "Redirect refused", headers, fp)


def parse_single_json(text):
    if not isinstance(text, str):
        raise ValueError("Expected text containing one JSON object")
    value = text.strip()
    if value.startswith("```"):
        lines = value.splitlines()
        if len(lines) < 3 or lines[0].lower() not in ("```", "```json") or lines[-1] != "```":
            raise ValueError("Invalid JSON code fence")
        value = "\n".join(lines[1:-1]).strip()
    try:
        result = json.loads(value, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    except ValueError as exc:
        raise ValueError("Expected exactly one complete JSON object") from exc
    if not isinstance(result, dict):
        raise ValueError("Plan must be one JSON object")
    return result


class APIClient:
    def __init__(self, base_url, api_key, model="qwen27b-v4", timeout=32):
        parsed = urlparse(base_url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.username or parsed.password:
            raise ValueError("Invalid API base URL")
        if parsed.query or parsed.fragment:
            raise ValueError("API base URL cannot contain a query or fragment")
        if parsed.scheme == "http" and parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
            raise ValueError("Plain HTTP is allowed only on loopback")
        if not isinstance(api_key, str) or not api_key or any(c.isspace() for c in api_key):
            raise ValueError("API key is missing or invalid")
        if not 0 < timeout <= 120:
            raise ValueError("Client timeout must be in (0,120]")
        base = base_url.rstrip("/")
        self.url = base + "/chat/completions"
        self.api_key, self.model, self.timeout = api_key, model, timeout
        self.calls, self.elapsed_seconds = 0, 0.0
        # Do not forward local bearer credentials through an environment proxy.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    @classmethod
    def from_env(cls, timeout=None):
        key_file = os.environ.get("OPENAI_API_KEY_FILE")
        if key_file:
            from .model_api import read_key_file
            key = read_key_file(key_file)
        else:
            key = os.environ.get("OPENAI_API_KEY", "")
        return cls(os.environ.get("OPENAI_BASE_URL", "http://127.0.0.1:18027/v1"), key,
            os.environ.get("OPENAI_MODEL", "qwen27b-v4"),
            float(timeout if timeout is not None else os.environ.get("OPENAI_TIMEOUT_SECONDS", "32")))

    def chat(self, messages, max_tokens=192):
        if type(max_tokens) is not int or not 1 <= max_tokens <= 256:
            raise ValueError("max_tokens must be 1..256")
        body = json.dumps(dict(model=self.model, messages=messages, max_tokens=max_tokens,
            temperature=0, stream=False), allow_nan=False).encode()
        if len(body) > 65536:
            raise ValueError("Request exceeds local API body limit")
        req = urllib.request.Request(self.url, data=body, headers={
            "Content-Type": "application/json", "Authorization": "Bearer " + self.api_key})
        started = time.monotonic()
        self.calls += 1
        try:
            with self.opener.open(req, timeout=self.timeout) as response:
                raw = response.read(1048577)
            if len(raw) > 1048576:
                raise ClientError("response_too_large", time.monotonic() - started)
            value = json.loads(raw)
            choice = value["choices"][0]
            content = choice["message"]["content"]
            if not isinstance(content, str):
                raise ValueError("Nontext response")
            return dict(content=content, usage=value.get("usage", {}), model=value.get("model"),
                finish_reason=choice.get("finish_reason"), id=value.get("id"),
                elapsed_seconds=time.monotonic() - started, server_elapsed_seconds=value.get("elapsed_seconds"))
        except urllib.error.HTTPError as exc:
            # Retain only bounded machine codes; never echo provider response bodies.
            code = "http_error"
            try:
                parsed = json.loads(exc.read(8192))
                candidate = parsed.get("error", {}).get("code")
                if isinstance(candidate, str) and candidate.replace("_", "").isalnum() and len(candidate) <= 64:
                    code = candidate
            except Exception:
                pass
            raise ClientError(code, time.monotonic() - started, exc.code) from None
        except (TimeoutError, urllib.error.URLError, OSError):
            raise ClientError("transport_timeout_or_error", time.monotonic() - started) from None
        except (ValueError, KeyError, IndexError, TypeError):
            raise ClientError("invalid_api_response", time.monotonic() - started) from None
        finally:
            self.elapsed_seconds += time.monotonic() - started

    def plan(self, messages, max_tokens=192):
        result = self.chat(messages, max_tokens)
        if result["finish_reason"] == "length":
            raise ClientError("truncated_plan", result["elapsed_seconds"])
        try:
            result["plan"] = parse_single_json(result["content"])
        except ValueError:
            raise ClientError("invalid_plan_json", result["elapsed_seconds"]) from None
        return result
