"""Bounded, public-information alternatives to the current numerical planner.

``window_rescue`` values scarce remaining geometric opportunities, ``fibre_pack``
repacks a few fields by sub-fibre translations, and ``window_pack`` combines the
two. These are search objectives, never modifications to the score formula.
The window table uses only the released night calendar and celestial positions;
it does not predict future weather or inspect the development environment.
"""
from datetime import timedelta
import math

import numpy as np

from .planner import (Planner, local_sidereal_deg, normalized_airmass,
                      offset_horizontal, horizontal_to_equatorial, utc_datetime)


STRATEGIES = ('baseline', 'window_rescue', 'fibre_pack', 'window_pack')
_SIDEREAL_DEGREES_PER_SECOND = 360.98564736629 / 86400.


def visible_window_seconds(ra, dec, start, end, latitude, longitude, minimum_altitude):
    """Analytic visible time and maximum altitude inside one public night.

    The linear sidereal approximation is the same as the documented planner.
    Summing interval intersections handles RA wrap and both circumpolar cases.
    The returned time is geometric capacity, not a forecast of usable weather.
    """
    ra, dec = np.broadcast_arrays(np.asarray(ra, dtype=float), np.asarray(dec, dtype=float))
    span = max(0., (utc_datetime(end)-utc_datetime(start)).total_seconds())
    h0 = (local_sidereal_deg(start, longitude)-ra+180.) % 360.-180.
    h1 = h0+span*_SIDEREAL_DEGREES_PER_SECOND
    lat = math.radians(latitude)
    baseline = np.sin(np.deg2rad(dec))*math.sin(lat)
    amplitude = np.cos(np.deg2rad(dec))*math.cos(lat)
    numerator = math.sin(math.radians(minimum_altitude))-baseline
    ratio = np.divide(numerator, amplitude, out=np.full_like(numerator, np.inf), where=amplitude > 1e-14)
    # At a geographic/celestial pole altitude is constant.
    ratio = np.where((amplitude <= 1e-14) & (numerator <= 0), -np.inf, ratio)
    half_width = np.rad2deg(np.arccos(np.clip(ratio, -1., 1.)))
    visible_degrees = np.zeros_like(ra)
    max_cos = np.maximum(np.cos(np.deg2rad(h0)), np.cos(np.deg2rad(h1)))
    # A night is shorter than a sidereal day in released cards. Derive bounds
    # from span nevertheless so this utility also handles longer test windows.
    upper_k = int(math.ceil(span*_SIDEREAL_DEGREES_PER_SECOND/360.))+1
    for cycle in range(-1, upper_k+1):
        center = cycle*360.
        visible_degrees += np.maximum(0., np.minimum(h1, center+half_width)-np.maximum(h0, center-half_width))
        max_cos = np.where((h0 <= center) & (center <= h1), 1., max_cos)
    seconds = np.where(ratio > 1., 0., np.minimum(span, visible_degrees/_SIDEREAL_DEGREES_PER_SECOND))
    maximum_altitude = np.rad2deg(np.arcsin(np.clip(baseline+amplitude*max_cos, -1., 1.)))
    return seconds, maximum_altitude


class StrategyPlanner(Planner):
    """Planner-compatible strategy wrapper with an explicit selection objective.

    Use ``selection_values(candidates, state)`` wherever the base experiment uses
    candidate.rate to form its shortlist. ``teacher_targets`` keeps the original
    two-step score estimate and adds the same disclosed window preference.
    Raw ``est_gain``, ``rate``, scores and factors always remain untouched.
    """
    def __init__(self, catalogue, strategy='baseline'):
        if strategy not in STRATEGIES:
            raise ValueError('Unknown planner strategy: '+str(strategy))
        super().__init__(catalogue)
        self.strategy = strategy
        self.use_windows = strategy in ('window_rescue', 'window_pack')
        self.use_packing = strategy in ('fibre_pack', 'window_pack')
        self.strategy_stats = dict(proposals=0, packing_geometries=0,
                                   packing_evaluations=0, rescue_evaluations=0)
        self._required_indices = np.flatnonzero(catalogue.required)
        self._window_capacity = np.zeros((len(catalogue.calendar), len(self._required_indices)))
        self._window_peak_altitude = np.zeros_like(self._window_capacity)
        if self.use_windows:
            for row, night in enumerate(catalogue.calendar):
                capacity, peak = visible_window_seconds(
                    catalogue.ra[self._required_indices], catalogue.dec[self._required_indices],
                    night['observing_start_utc'], night['observing_end_utc'], catalogue.latitude,
                    catalogue.longitude, catalogue.minimum_altitude)
                self._window_capacity[row] = capacity
                self._window_peak_altitude[row] = peak

    def window_summary(self, state):
        """Per-target rescue weights from public geometry, never hidden truth.

        Future opportunity counts deliberately assume an optimistic normalized
        zenith quality of 1.5. This prevents today's cloudy belief from declaring
        every later night impossible. Counts are planning hints, not guarantees.
        """
        cat = self.catalogue
        bonus = np.zeros(len(cat.ids), dtype=float)
        future_count = np.zeros(len(cat.ids), dtype=np.int32)
        current_seconds = np.zeros(len(cat.ids), dtype=float)
        if not self.use_windows or not len(self._required_indices):
            return dict(bonus=bonus, future_nights=future_count, visible_seconds=current_seconds)
        ids = self._required_indices
        threshold = float(cat.score_config['required']['observed_factor_threshold'])
        factor, _ = self._progress(state)
        missing = factor[ids]+1e-12 < threshold
        now = utc_datetime(state['now_utc'])
        later_rows = [i for i, night in enumerate(cat.calendar)
                      if utc_datetime(night['observing_start_utc']) > now]
        if later_rows:
            capacity = self._window_capacity[later_rows]
            peak = self._window_peak_altitude[later_rows]
            optimistic_q = 1.5/normalized_airmass(np.maximum(peak, cat.minimum_altitude))**float(cat.score_config.get('airmass_exponent', .6))
            usable = np.minimum(capacity, float(cat.fiber_config['exposure']['max_duration_seconds']))
            opportunities = (usable >= cat.fiber_config['exposure']['min_duration_seconds']) & (
                usable*optimistic_q*cat.flux[ids][None, :]/cat.norm >= threshold)
            future_count[ids] = opportunities.sum(axis=0)
        visible, _ = visible_window_seconds(cat.ra[ids], cat.dec[ids], now, state['end_utc'],
                                           cat.latitude, cat.longitude, cat.minimum_altitude)
        current_seconds[ids] = visible
        # The finite penalty is counted once by the original scorer. This
        # additional amount is solely a priority for losing an opportunity.
        scarcity = 1./(future_count[ids]+1.)
        closing = np.exp(-visible/1800.)
        multiplier = 1.6*scarcity + .7*scarcity*closing
        penalty = float(cat.score_config['required']['penalty_per_missing'])
        bonus[ids] = penalty*multiplier*missing
        return dict(bonus=bonus, future_nights=future_count, visible_seconds=current_seconds)

    def _candidate_window_bonus(self, candidate, state, summary=None):
        if not self.use_windows:
            return 0.
        summary = summary if summary is not None else self.window_summary(state)
        ids = np.asarray(candidate['target_indices'], dtype=int)
        factors = np.asarray(candidate['factors'])
        threshold = float(self.catalogue.score_config['required']['observed_factor_threshold'])
        return float(np.sum(summary['bonus'][ids]*(factors+1e-12 >= threshold)))

    def selection_values(self, candidates, state):
        summary = self.window_summary(state) if self.use_windows else None
        return np.asarray([(float(c['est_gain'])+self._candidate_window_bonus(c, state, summary)) /
                           max(1., float(c['duration_seconds'])) for c in candidates], dtype=np.float32)

    @staticmethod
    def _key(candidate):
        action = candidate['action']
        return (round(float(action['pointing']['alt_deg']), 9),
                round(float(action['pointing']['az_deg']), 9),
                int(action['duration_seconds']), action['program'],
                tuple(sorted(action['assignments'].items())))

    def _rescue_controls(self, state, supplied, summary):
        controls = self._controls(supplied)
        cat = self.catalogue
        alt, _ = self._horizontal(cat.ra, cat.dec, state['now_utc'])
        ids = np.flatnonzero((summary['bonus'] > 0) & (alt >= cat.minimum_altitude+.1))
        if not len(ids):
            return controls, []
        quality = self._quality(state, alt[ids], cat.ra[ids], cat.dec[ids], state['now_utc'])
        threshold = float(cat.score_config['required']['observed_factor_threshold'])
        need = threshold*cat.norm/np.maximum(cat.flux[ids]*quality, 1e-12)
        time_left = (utc_datetime(state['end_utc'])-utc_datetime(state['now_utc'])).total_seconds()
        viable = need <= min(float(cat.fiber_config['exposure']['max_duration_seconds']), time_left)
        ranking = np.where(viable, (float(cat.score_config['required']['penalty_per_missing'])+summary['bonus'][ids]) /
                           np.maximum(60., need), -np.inf)
        chosen = [int(ids[i]) for i in np.argsort(-ranking, kind='stable') if np.isfinite(ranking[i])][:4]
        # Preserve explicit Agent targets, leaving room for bounded rescue roots.
        controls['priority_targets'] = list(dict.fromkeys(controls['priority_targets'][:4] +
                                                         [str(cat.ids[i]) for i in chosen]))[:8]
        return controls, chosen

    def _rescue_candidates(self, roots, state, controls):
        cat = self.catalogue
        remaining = (utc_datetime(state['end_utc'])-utc_datetime(state['now_utc'])).total_seconds()
        items = []
        # Explicit threshold actions ensure a scarce target cannot be lost in
        # an unrelated high-rate field's six-duration screen.
        for target in roots[:3]:
            alt, az = self._horizontal(cat.ra[target], cat.dec[target], state['now_utc'])
            a, z = offset_horizontal(float(alt), float(az), cat.cell_width*.5, cat.cell_width*.5)
            ra, dec = horizontal_to_equatorial(a, z, state['now_utc'], cat.latitude, cat.longitude)
            geometry = self._geometry(float(ra), float(dec), state)
            if geometry is None:
                continue
            position = np.flatnonzero(geometry['indices'] == target)
            if not len(position):
                continue
            q = self._quality(state, np.asarray([alt]), np.asarray([cat.ra[target]]),
                              np.asarray([cat.dec[target]]), state['now_utc'])[0]
            if q*cat.flux[target] <= 0:
                continue
            threshold = float(cat.score_config['required']['observed_factor_threshold'])
            minimum = max(int(cat.fiber_config['exposure']['min_duration_seconds']),
                          int(state.get('min_planning_duration', 60)))
            duration = max(minimum, int(math.ceil(threshold*cat.norm/(q*cat.flux[target])*controls['exposure_margin'])))
            if duration > min(remaining, cat.fiber_config['exposure']['max_duration_seconds']):
                continue
            # Recompute integrated Q once so a setting target is not just below
            # the completion threshold due to using initial altitude alone.
            _, integrated, _, _ = self._astronomy(geometry, duration, state)
            real_q = float(integrated[int(position[0])])
            if real_q > 0:
                duration = max(duration, int(math.ceil(threshold*cat.norm/(real_q*cat.flux[target])*controls['exposure_margin'])))
            if duration > min(remaining, cat.fiber_config['exposure']['max_duration_seconds']):
                continue
            item = self._evaluate(geometry, duration, state, controls)
            self.strategy_stats['rescue_evaluations'] += 1
            if item is not None:
                item['strategy_origin'] = 'required_threshold_rescue'
                items.append(item)
        return items

    def _packing_candidates(self, candidates, state, controls):
        cat = self.catalogue
        items = []
        roots = []
        for candidate in sorted(candidates, key=lambda c: -c.get('strategy_priority', c['rate'])):
            p = candidate['action']['pointing']
            if any(abs(p['alt_deg']-a) < cat.cell_width*.6 and
                   abs((p['az_deg']-z+180)%360-180)*max(.1, math.cos(math.radians(p['alt_deg']))) < cat.cell_width*.6
                   for a, z in roots):
                continue
            roots.append((p['alt_deg'], p['az_deg']))
            # Axis translations move cell boundaries without changing the
            # instrument model. The fixed eight-point ceiling is deliberate.
            for dx, dy in ((-.45, 0.), (.45, 0.), (0., -.45), (0., .45)):
                a, z = offset_horizontal(p['alt_deg'], p['az_deg'], dx*cat.cell_width, dy*cat.cell_width)
                ra, dec = horizontal_to_equatorial(a, z, state['now_utc'], cat.latitude, cat.longitude)
                geometry = self._geometry(float(ra), float(dec), state)
                self.strategy_stats['packing_geometries'] += 1
                if geometry is None:
                    continue
                item = self._evaluate(geometry, candidate['duration_seconds'], state, controls)
                self.strategy_stats['packing_evaluations'] += 1
                if item is not None:
                    item['strategy_origin'] = 'fibre_boundary_translation'
                    items.append(item)
            if len(roots) >= 2:
                break
        return items

    def propose(self, state, controls=None, max_candidates=64):
        self.strategy_stats['proposals'] += 1
        # The base planner caches these arrays only in its own copied state.
        # Our extra evaluations also need that cache: rebuilding 10,000-entry
        # dictionaries for each of eleven refinements would dominate geometry.
        state = dict(state)
        state['_planner_progress_arrays'] = self._progress(state)
        summary = self.window_summary(state) if self.use_windows else None
        roots = []
        adjusted = controls
        if self.use_windows:
            adjusted, roots = self._rescue_controls(state, controls, summary)
        adjusted = self._controls(adjusted)
        cap = min(int(max_candidates), int(adjusted['candidate_budget']))
        baseline = super().propose(state, adjusted, max_candidates=cap)
        if self.strategy == 'baseline' or cap < 1:
            return baseline
        candidates = list(baseline)
        if self.use_windows:
            candidates.extend(self._rescue_candidates(roots, state, adjusted))
        for item in candidates:
            bonus = self._candidate_window_bonus(item, state, summary)
            item['strategy_window_bonus'] = bonus
            item['strategy_priority'] = (item['est_gain']+bonus)/item['duration_seconds']
        if self.use_packing:
            candidates.extend(self._packing_candidates(candidates, state, adjusted))
        for item in candidates:
            bonus = self._candidate_window_bonus(item, state, summary)
            item['strategy_window_bonus'] = bonus
            item['strategy_priority'] = (item['est_gain']+bonus)/item['duration_seconds']
            item['strategy_name'] = self.strategy
        selected = []
        seen = set()
        for item in sorted(candidates, key=lambda c: (-c['strategy_priority'], -c['est_gain'], c['duration_seconds'])):
            key = self._key(item)
            if key in seen:
                continue
            selected.append(item)
            seen.add(key)
            if len(selected) >= cap:
                break
        return selected

    def teacher_targets(self, candidates, state, controls=None, indices=None):
        values = super().teacher_targets(candidates, state, controls, indices)
        if not self.use_windows:
            return values
        summary = self.window_summary(state)
        chosen = range(len(candidates)) if indices is None else indices
        budget = max(1., min(7200., (utc_datetime(state['end_utc'])-utc_datetime(state['now_utc'])).total_seconds()))
        # This is deliberately named an objective correction: it is not added
        # to candidate.est_gain and never enters the environment/scorer.
        for row, index in enumerate(chosen):
            bonus = self._candidate_window_bonus(candidates[int(index)], state, summary)
            values[row] += bonus/budget
            self.last_teacher_details[row]['strategy_window_priority_bonus'] = bonus
            self.last_teacher_details[row]['strategy_name'] = self.strategy
        return values


def make_planner(catalogue, strategy='baseline'):
    return StrategyPlanner(catalogue, strategy)
