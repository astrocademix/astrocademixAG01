"""Development environment, NOT the official v4 runner.

Only the six current public files are loaded. Hidden weather, observation requests,
faults and data loss below are deliberately generated development disturbances.
Their numerical scores must not be presented as competition scores. The policy
receives a public snapshot, never this object's weather/events/RNG internals.
Geometry is the same explicitly approximate adapter used by the search tool;
agreement here is NOT independent validation of official instrument geometry.
"""
import hashlib
import math
import copy
import numpy as np

from .common import timestamp, utc, required_missing, SCOPE


class DevelopmentSurvey:
    def __init__(self, catalogue, episode=0, seed=17, max_nights=None, weather_profile='nominal'):
        if weather_profile not in ('nominal', 'adverse', 'variable', 'clear'):
            raise ValueError('Unknown synthetic weather profile')
        self.weather_profile = weather_profile
        self.cat = catalogue
        self.nights = list(catalogue.calendar)[:max_nights]
        if not self.nights:
            raise ValueError('A development episode needs at least one public observing night')
        self.index = {str(t): i for i, t in enumerate(catalogue.ids)}
        card = str(catalogue.scenario['name'])
        scenario_seed = int.from_bytes(hashlib.sha256(f'{seed}:{episode}:{card}'.encode()).digest()[:8], 'little')
        rng = np.random.default_rng(scenario_seed)
        # Pre-generated time-indexed disturbances make policy comparisons paired:
        # changes in the number of actions do not change the weather realization.
        # These are *normalized* station composites tau*K/(seeing*q0), not raw
        # sky_quality. Thus no additional q0 division belongs in Q or B below.
        self._weather = []
        self._requests = []
        self._fault_at = {}
        for n, night in enumerate(self.nights):
            slots = max(1, math.ceil((timestamp(night['observing_end_utc']) - timestamp(night['observing_start_utc'])) / 900))
            values = []
            q = float(rng.uniform(.35, 1.65))
            for slot in range(slots + 5):
                q = float(np.clip(.90 * q + .10 * rng.uniform(.15, 1.85) + rng.normal(0, .08), .06, 1.85))
                values.append(q)
            values = np.asarray(values)
            # Explicit stress domains, paired by card/episode across policies.
            # These are development distributions, not claims about hidden truth.
            if weather_profile == 'adverse':
                values = np.clip(values * .65, .06, 1.85)
            elif weather_profile == 'clear':
                values = np.clip(values * 1.30, .06, 1.85)
            elif weather_profile == 'variable':
                phase = np.arange(len(values)) // 4
                values = np.clip(values * np.where(phase % 2 == 0, .50, 1.50), .06, 1.85)
            self._weather.append(values)
            # One synthetic request every sixth night, clustered in a public field.
            if n % 6 == 2:
                center = int(rng.integers(len(catalogue.ids)))
                dr = ((catalogue.ra - catalogue.ra[center] + 180) % 360 - 180) * np.cos(np.deg2rad(catalogue.dec[center]))
                dist = dr * dr + (catalogue.dec - catalogue.dec[center]) ** 2
                ids = np.argsort(dist)[:6]
                self._requests.append(dict(request_id=f'dev-{n}', night=n,
                    schema_version='v4-observation-request-v1',
                    record_type='observation_request',
                    target_ids=[str(catalogue.ids[i]) for i in ids], minimum_completed=3,
                    completion_factor_threshold=.5, completion_reward=60., deadline_utc=night['observing_end_utc'],
                    issued_at_utc=night['observing_start_utc']))
            if n in (12, 29):
                self._fault_at[n] = timestamp(night['observing_start_utc']) + 3600
        self.night_index = 0
        self.now = timestamp(self.nights[0]['observing_start_utc'])
        self.best_factor, self.best_score = {}, {}
        self.request_hits = {}
        self.request_rewards = 0.
        self.completed_requests = set()
        self.report_balance = 0.
        self.false_reports = 0
        self.consecutive_reports = 0
        self.repaired_nights = set()
        self.actions = self.observations = self.invalid_assignments = 0
        self.wait_seconds = 0.
        self.resyncs = 0
        self.done = False
        self.last_result = None
        self.messages = []
        self.history = []
        self._request_results = {}
        self._message_cursor = 0
        self._timeline = []
        self._latest_bulletin = self._latest_forecast = None
        for n, night in enumerate(self.nights):
            start = timestamp(night['observing_start_utc'])
            end = timestamp(night['observing_end_utc'])
            for slot, when in enumerate(np.arange(start, end, 900)):
                q = float(self._weather[n][slot])
                notices = ([dict(event_kind='overcast' if q < .45 else 'haze', direction='ALL')]
                           if q < .75 else [])
                self._timeline.append((float(when), dict(record_type='bulletin', night_id=night['night_id'],
                    slot_id=f"{night['night_id']}-S{slot + 1:03d}", issued_at_utc=utc(when),
                    initial=n == 0 and slot == 0, notices=notices)))
            if n % 7 == 0:
                # This development environment does not simulate forecastable
                # discrete weather events; empty forecasts disclose no truth.
                self._timeline.append((start, dict(record_type='forecast', issued_at_utc=utc(start),
                    coverage_start_utc=utc(start), coverage_end_utc=utc(start + 7 * 86400), notices=[])))
        for request in self._requests:
            self._timeline.append((timestamp(request['issued_at_utc']),
                                   {k: v for k, v in request.items() if k != 'night'}))
        self._timeline.sort(key=lambda pair: pair[0])

    def _fault(self):
        at = self._fault_at.get(self.night_index)
        return at is not None and self.now >= at and self.night_index not in self.repaired_nights

    def _advance_night(self):
        if self.done:
            return
        end = timestamp(self.nights[self.night_index]['observing_end_utc'])
        if self.now < end:
            return
        self.night_index += 1
        if self.night_index >= len(self.nights):
            self.done = True
            return
        self.now = timestamp(self.nights[self.night_index]['observing_start_utc'])
        if self.night_index == 23 and self.cat.scenario.get('stress', {}).get('enabled'):
            # Invalidate a contiguous interval of observe indices, not arbitrary
            # target IDs. Earlier valid observations of the same target survive.
            first, last = int(len(self.history) * .70), int(len(self.history) * .75)
            self._invalidate_observations(first, last)

    def _invalidate_observations(self, first, last):
        """Rebuild separate maxima and window-specific requests from the ledger."""
        for record in self.history[first:last]:
            record['valid'] = False
        self.best_score.clear()
        self.best_factor.clear()
        self.request_hits.clear()
        self.completed_requests.clear()
        self.request_rewards = 0.
        for record in self.history:
            if not record['valid']:
                continue
            for h in record['hits']:
                tid = h['target_id']
                self.best_score[tid] = max(self.best_score.get(tid, 0.), h['score'])
                self.best_factor[tid] = max(self.best_factor.get(tid, 0.), h['factor'])
                self._attribute_requests(tid, h['factor'], record['start'], record['end'])
        self._settle_requests()
        self.resyncs += 1
        count = len(self.history)
        window = dict(action_count_at_trigger=count, action_index_start=first,
            action_index_end_exclusive=last, window_start_fraction=first / count if count else 0.,
            window_end_fraction=last / count if count else 0.,
            window_max_fraction=(last - first) / count if count else 0.)
        self.messages.append(dict(record_type='state_resync', issued_at_utc=utc(self.now),
            trigger_event_id='development-data-loss', invalidated_window=window,
            observed_target_ids=list(self.best_score),
            best_scores=[dict(target_id=k, best_score=v) for k, v in self.best_score.items()],
            observation_requests=self._active_requests()))
        self._emit_request_results(revised=True)

    def _active_requests(self):
        result = []
        for request in self._requests:
            if timestamp(request['issued_at_utc']) <= self.now < timestamp(request['deadline_utc']):
                completed = sorted(self.request_hits.get(request['request_id'], set()))
                # Completed requests remain public until their deadline.
                result.append(dict({k: v for k, v in request.items() if k != 'night'},
                    completed_target_ids=completed, completed_count=len(completed),
                    remaining_count=max(0, request['minimum_completed'] - len(completed))))
        return result

    def _emit_request_results(self, revised=False):
        for request in self._requests:
            rid = request['request_id']
            if self.now < timestamp(request['deadline_utc']):
                continue
            completed = sorted(self.request_hits.get(rid, set()))
            success = len(completed) >= request['minimum_completed']
            current = dict(status='completed' if success else 'expired', completed_target_ids=completed,
                           completed_count=len(completed), minimum_completed=request['minimum_completed'])
            previous = self._request_results.get(rid)
            if previous == current:
                continue
            reward = float(request['completion_reward'])
            prior_reward = reward if previous and previous['status'] == 'completed' else 0.
            delta = (reward if success else 0.) - prior_reward
            self.messages.append(dict(record_type='observation_request_result', request_id=rid,
                issued_at_utc=utc(self.now), **current, score_delta=delta,
                revised=bool(previous is not None)))
            self._request_results[rid] = current

    def _publish_messages(self):
        while self._message_cursor < len(self._timeline) and self._timeline[self._message_cursor][0] <= self.now:
            record = self._timeline[self._message_cursor][1]
            if record['record_type'] == 'bulletin':
                self._latest_bulletin = record
            elif record['record_type'] == 'forecast':
                self._latest_forecast = record
            self.messages.append(record)
            self._message_cursor += 1
        self._emit_request_results()

    def _slot(self, when):
        start = timestamp(self.nights[self.night_index]['observing_start_utc'])
        return int(np.clip((when - start) // 900, 0, len(self._weather[self.night_index]) - 1))

    def _quality(self, when):
        return float(self._weather[self.night_index][self._slot(when)])

    def initialize_payload(self):
        c = self.cat
        cols = ['target_id', 'ra_deg', 'dec_deg', 'target_class', 'feature_flux', 'science_weight', 'required']
        classes = getattr(c, 'target_classes', None)
        rows = [[str(c.ids[i]), float(c.ra[i]), float(c.dec[i]), str(classes[i]) if classes is not None else 'PUBLIC', float(c.flux[i]),
                 float(c.weight[i]), bool(c.required[i])] for i in range(len(c.ids))]
        components = {}
        for vertex in c.footprint:
            components.setdefault(vertex['component_id'], []).append(vertex)
        footprint = [dict(component_id=key, vertices=[[float(v['ra_deg']), float(v['dec_deg'])]
                      for v in sorted(vertices, key=lambda x: int(x['vertex_index']))])
                     for key, vertices in components.items()]
        field = c.fiber_config['field']
        side = math.sqrt(float(field['fiber_area_deg2']))
        return copy.deepcopy(dict(schema_version='v4-initialize-v1', task_card=c.scenario['task_card'],
            site=dict(c.scenario['site'], minimum_altitude_deg=c.scenario.get('minimum_altitude_deg', 30.)),
            survey=dict(start_utc=self.nights[0]['observing_start_utc'],
                end_utc=self.nights[-1]['observing_end_utc'], slot_seconds=900, nights=self.nights),
            instrument=dict(n_fibers=field['n_fibers'], grid_side=4, fiber_area_deg2=field['fiber_area_deg2'], gap_deg=field.get('gap_deg', 0.),
                glass_side_deg=side, pitch_deg=side, fov_side_deg=4*side,
                layout='row-major, fiber 0 bottom-left; rows along +alt, columns along +az at exposure start',
                exposure=c.fiber_config['exposure']), scoring=c.score_config,
            targets=dict(columns=cols, rows=rows), footprint=footprint,
            limits=dict(global_wallclock_seconds=c.scenario.get('limits', {}).get('global_wallclock_seconds', 900),
                max_consecutive_reports=c.score_config['reporting']['max_consecutive_reports'], response_max_bytes=524288)))

    def public_payload(self, elapsed=0., limit=900.):
        if self.done:
            return None
        night = self.nights[self.night_index]
        self._publish_messages()
        return copy.deepcopy(dict(schema_version='v4-decision-snapshot-v1', now_utc=utc(self.now),
            survey_end_utc=self.nights[-1]['observing_end_utc'], observe_action_index=self.observations,
            running_total=sum(self.best_score.values()),
            wallclock=dict(elapsed_seconds=elapsed, remaining_seconds=max(0., limit-elapsed)),
            latest_bulletin=self._latest_bulletin, latest_forecast=self._latest_forecast,
            active_requests=self._active_requests(), last_result=self.last_result,
            new_messages=list(self.messages)))

    def step(self, action):
        if self.done:
            raise ValueError('Survey already complete')
        self._validate_action(action)
        self.messages = []
        self.actions += 1
        kind = action.get('action')
        before = self.now
        end = timestamp(self.nights[self.night_index]['observing_end_utc'])
        if kind == 'finish':
            self.done = True
            self.last_result = dict(action=kind)
            return self.last_result
        if kind == 'wait':
            until = timestamp(action['until_utc']) if 'until_utc' in action else min(end, self.now + action['duration_seconds'])
            while not self.done and self.now < until:
                end = timestamp(self.nights[self.night_index]['observing_end_utc'])
                previous = self.now
                self.now = min(end, until)
                self.wait_seconds += self.now - previous
                self._advance_night()
            self.consecutive_reports = 0
            self.last_result = dict(action='wait')
        elif kind == 'report':
            reporting = self.cat.score_config['reporting']
            self.consecutive_reports += 1
            if self.consecutive_reports > reporting['max_consecutive_reports']:
                raise ValueError('Consecutive report cap exceeded')
            correct = self._fault()
            if correct:
                self.repaired_nights.add(self.night_index)
                self.false_reports = 0
                delta = float(reporting['correct_reward'])
            else:
                self.false_reports += 1
                delta = float(reporting['false_penalty']) if self.false_reports > reporting['false_report_free_allowance'] else 0.
            self.report_balance += delta
            self.last_result = dict(action='report', correct=correct, repaired=correct, score_delta=delta)
            self.messages.append(dict(record_type='report_result', issued_at_utc=utc(self.now),
                correct=correct, repaired=correct, score_delta=delta))
        elif kind == 'observe':
            self.last_result = self._observe(action, end)
            self.consecutive_reports = 0
            self.observations += 1
        else:
            raise ValueError('Unknown development action')
        self._advance_night()
        return self.last_result

    def _validate_action(self, action):
        if not isinstance(action, dict):
            raise ValueError('Action must be an object')
        kind = action.get('action')
        specific = dict(observe={'duration_seconds', 'pointing', 'assignments', 'program'},
                        wait={'duration_seconds', 'until_utc'}, report=set(), finish=set())
        common = {'action', 'reason', 'decision_source'}
        if kind not in specific or set(action) - specific[kind] - common:
            raise ValueError('Unknown action or extra action fields')
        exposure = self.cat.fiber_config['exposure']
        low, high = exposure['min_duration_seconds'], exposure['max_duration_seconds']
        if kind == 'wait' and 'until_utc' in action:
            when = action['until_utc']
            if ('duration_seconds' in action or not isinstance(when, str) or not when.endswith('Z')
                    or timestamp(when) <= self.now):
                raise ValueError('Invalid until_utc wait')
        elif kind in ('wait', 'observe'):
            duration = action.get('duration_seconds')
            if type(duration) is not int or not low <= duration <= high:
                raise ValueError('Invalid exposure/wait duration')
        if kind == 'report' and self.consecutive_reports >= self.cat.score_config['reporting']['max_consecutive_reports']:
            raise ValueError('Consecutive report cap exceeded')
        if kind != 'observe':
            return
        pointing, assignments = action.get('pointing'), action.get('assignments')
        if not isinstance(pointing, dict) or set(pointing) != {'alt_deg', 'az_deg'}:
            raise ValueError('Invalid pointing fields')
        alt, az = pointing['alt_deg'], pointing['az_deg']
        if (isinstance(alt, bool) or isinstance(az, bool) or not isinstance(alt, (int, float))
                or not isinstance(az, (int, float)) or not math.isfinite(alt) or not math.isfinite(az)
                or not 0 <= alt <= 90 or not 0 <= az < 360):
            raise ValueError('Invalid pointing coordinates')
        if not isinstance(assignments, dict):
            raise ValueError('Explicit assignments object is required')
        try:
            fibres = [int(key) for key in assignments if isinstance(key, str)]
        except ValueError as exc:
            raise ValueError('Invalid fibre identifiers') from exc
        n_fibres = self.cat.fiber_config['field']['n_fibers']
        if (len(fibres) != len(assignments) or len(set(fibres)) != len(fibres)
                or any(x < 0 or x >= n_fibres for x in fibres)):
            raise ValueError('Duplicate or out-of-range fibre identifiers')
        values = list(assignments.values())
        if any(not isinstance(value, str) or value not in self.index for value in values) or len(set(values)) != len(values):
            raise ValueError('Unknown or repeated target')
        if action.get('program', 'BACKUP') not in self.cat.score_config['program']['multipliers']:
            raise ValueError('Unknown program')

    def _observe(self, action, end):
        from .planner import equatorial_to_horizontal, fibre_indices
        d = action['duration_seconds']
        if type(d) is not int or not 60 <= d <= 3600:
            raise ValueError('Invalid exposure duration')
        d = min(d, end - self.now)
        pointing = action['pointing']
        assignments = action['assignments']
        if len(assignments) > 16 or len(set(assignments.values())) != len(assignments):
            raise ValueError('Repeated target or too many fibres')
        tids = [str(t) for t in assignments.values()]
        if any(t not in self.index for t in tids):
            raise ValueError('Unknown target')
        indices = np.asarray([self.index[t] for t in tids], dtype=int)
        site = self.cat.scenario['site']
        boundaries = [self.now]
        while boundaries[-1] < self.now + d:
            t = boundaries[-1]
            stop = min(self.now + d, (math.floor(t / 900) + 1) * 900,
                       self._fault_at.get(self.night_index, float('inf')) if t < self._fault_at.get(self.night_index, float('inf')) else float('inf'))
            while t < stop:
                t = min(stop, t + 120)
                boundaries.append(t)
        widths = np.diff(boundaries)
        mids = (np.asarray(boundaries[:-1]) + np.asarray(boundaries[1:])) / 2
        samples = np.concatenate(([self.now], mids, [self.now + d]))
        altitudes, initial_az = [], None
        for when in samples:
            alt, az = equatorial_to_horizontal(self.cat.ra[indices], self.cat.dec[indices], utc(when),
                site['latitude_deg'], site['longitude_deg'])
            altitudes.append(alt)
            if initial_az is None:
                initial_az = az
        altitudes = np.asarray(altitudes)
        cells = fibre_indices(altitudes[0], initial_az, pointing['alt_deg'], pointing['az_deg'])
        legal = (cells == np.asarray([int(x) for x in assignments])) & (altitudes.min(axis=0) >= self.cat.scenario.get('minimum_altitude_deg', 30))
        # Integrate changing quality across the exposure; do not just evaluate the
        # conditions at its beginning. The fault is hidden from the policy.
        sky = np.asarray([self._quality(t) for t in mids])[:, None]
        exponent = self.cat.score_config.get('airmass_exponent', .6)
        z = 90. - altitudes[1:-1]
        airmass = (1. + .50572 * 96.07995 ** -1.6364) / (np.cos(np.deg2rad(z)) + .50572 * np.maximum(.1, 96.07995-z) ** -1.6364)
        # Public lunar ephemeris is applied when supplied by the shared adapter.
        from .planner import lunar_factor
        lunar = np.asarray([lunar_factor(self.cat.ra[indices], self.cat.dec[indices], utc(t),
            site['latitude_deg'], site['longitude_deg'], self.cat.score_config) for t in mids])
        program_quality = sky * lunar / airmass ** exponent
        efficiency = np.full((len(mids), 1), .90)
        at = self._fault_at.get(self.night_index, float('inf'))
        if self.night_index not in self.repaired_nights:
            efficiency[np.asarray(mids) >= at] *= .22
        quality = ((program_quality * efficiency) * widths[:, None]).sum(axis=0) / d
        band_quality = (program_quality * widths[:, None]).sum(axis=0) / d
        if self.now < at < self.now + d:
            # B uses its own weather-slot/120-second segmentation. An instrument
            # fault boundary changes Q, but must not even alter B's quadrature.
            band_bounds = [self.now]
            while band_bounds[-1] < self.now + d:
                t = band_bounds[-1]
                stop = min(self.now + d, (math.floor(t / 900) + 1) * 900)
                while t < stop:
                    t = min(stop, t + 120)
                    band_bounds.append(t)
            band_widths = np.diff(band_bounds)
            band_mids = (np.asarray(band_bounds[:-1]) + np.asarray(band_bounds[1:])) / 2
            band_parts = []
            from .planner import normalized_airmass
            for t in band_mids:
                altitude, _ = equatorial_to_horizontal(self.cat.ra[indices], self.cat.dec[indices], utc(t),
                    site['latitude_deg'], site['longitude_deg'])
                moon = lunar_factor(self.cat.ra[indices], self.cat.dec[indices], utc(t),
                    site['latitude_deg'], site['longitude_deg'], self.cat.score_config)
                band_parts.append(self._quality(t) * moon / normalized_airmass(altitude) ** exponent)
            band_quality = (np.asarray(band_parts) * band_widths[:, None]).sum(axis=0) / d
        cfg = self.cat.score_config
        norm = cfg['flux_zero_point'] * cfg['exposure_zero_point_seconds']
        factors = np.clip(self.cat.flux[indices] * d * quality / norm, 0, 1)
        bands = cfg['program']['bands']
        correct = np.where(band_quality >= bands['DARK'], 'DARK', np.where(band_quality >= bands['BRIGHT'], 'BRIGHT', 'BACKUP'))
        program = action.get('program', 'BACKUP')
        if program not in cfg['program']['multipliers']:
            raise ValueError('Unknown program')
        bonus = np.where(correct == program, cfg['program']['multipliers'][program], cfg['program']['mismatch_multiplier'])
        scores = self.cat.weight[indices] * factors * bonus
        hits = []
        for i, tid in enumerate(tids):
            if not legal[i]:
                self.invalid_assignments += 1
                continue
            factor, score = float(factors[i]), float(scores[i])
            self.best_score[tid] = max(self.best_score.get(tid, 0.), score)
            self.best_factor[tid] = max(self.best_factor.get(tid, 0.), factor)
            hits.append(dict(target_id=tid, score=score, factor=factor))
            self._attribute_requests(tid, factor, self.now, self.now + d)
        self._settle_requests()
        self.history.append(dict(valid=True, start=self.now, end=self.now+d, hits=hits))
        self.now += d
        # The public protocol does not expose completion factors or hidden quality.
        return dict(action='observe', observe_index=self.observations,
            assigned_count=len(tids), hit_count=len(hits),
            hits=[dict(target_id=h['target_id'], score=h['score']) for h in hits])

    def _attribute_requests(self, tid, factor, start, end):
        for r in self._requests:
            if (timestamp(r['issued_at_utc']) <= start and end <= timestamp(r['deadline_utc'])
                    and tid in r['target_ids'] and factor >= r['completion_factor_threshold']):
                self.request_hits.setdefault(r['request_id'], set()).add(tid)

    def _settle_requests(self):
        for r in self._requests:
            if r['request_id'] not in self.completed_requests and len(self.request_hits.get(r['request_id'], set())) >= r['minimum_completed']:
                self.completed_requests.add(r['request_id'])
                self.request_rewards += r['completion_reward']

    def summary(self):
        cfg = self.cat.score_config
        # Coverage includes every RA band occupied by the public catalogue,
        # including zero-completion bands (not merely already-observed bands).
        band_width = cfg['uniformity']['ra_band_width_deg']
        bands = (self.cat.ra // band_width).astype(int)
        counts = np.asarray([np.mean([self.best_factor.get(str(self.cat.ids[i]), 0.) >= cfg['uniformity']['observed_factor_threshold']
            for i in np.flatnonzero(bands == b)]) for b in sorted(set(bands))], dtype=float)
        jain = float(counts.sum() ** 2 / (len(counts) * (counts @ counts))) if np.any(counts) else 0.
        uniformity = cfg['uniformity']['weight'] * (1 - jain)
        science = float(sum(self.best_score.values()))
        missing = required_missing(self.cat, self.best_factor)
        penalty = missing * cfg['required']['penalty_per_missing']
        return dict(scope=SCOPE, official_score=None,
            proxy_total=science - penalty - uniformity + self.request_rewards + self.report_balance,
            science_with_program_bonus=science, required_missing=missing,
            required_penalty=penalty, uniformity_penalty=uniformity,
            request_rewards=self.request_rewards, requests_completed=len(self.completed_requests),
            report_balance=self.report_balance, observed_targets=len(self.best_score),
            actions=self.actions, observations=self.observations,
            invalid_assignments=self.invalid_assignments, wait_seconds=self.wait_seconds,
            state_resyncs=self.resyncs, survey_complete=self.done, night_index=self.night_index)
