"""Regression tests for public-state isolation and published scoring semantics."""
import copy
import json
import unittest
from unittest.mock import patch

import numpy as np

from .common import timestamp, utc
from .environment import DevelopmentSurvey
from .test_planner import fixture


def environment(nights=3):
    catalogue, state = fixture()
    catalogue.scenario.update(name='v4-practice-test', task_card=dict(card_id='alpha'))
    catalogue.score_config.update(uniformity=dict(ra_band_width_deg=10, observed_factor_threshold=.5, weight=200),
        reporting=dict(max_consecutive_reports=32, correct_reward=100, false_penalty=-150, false_report_free_allowance=2))
    start = timestamp(state['now_utc'])
    catalogue.calendar = [dict(night_id=f'N{i}', night_date=f'2026-10-{5+i:02d}',
        observing_start_utc=utc(start+i*86400), observing_end_utc=utc(start+i*86400+10800), slot_count=12)
        for i in range(nights)]
    return DevelopmentSurvey(catalogue)


class EnvironmentTests(unittest.TestCase):
    def test_public_payload_contains_no_hidden_factor_or_future_request(self):
        env = environment()
        payload = env.public_payload()
        encoded = json.dumps(payload)
        for secret in ('quality', 'efficiency', 'best_factor', 'dev-2'):
            self.assertNotIn(secret, encoded)
        self.assertEqual(payload['active_requests'], [])
        original_time = payload['latest_bulletin']['issued_at_utc']
        payload['latest_bulletin']['notices'].append({'event_kind': 'mutated'})
        env.step(dict(action='wait', duration_seconds=60))
        after = env.public_payload()
        self.assertEqual(after['latest_bulletin']['issued_at_utc'], original_time)
        self.assertFalse(any(x.get('event_kind') == 'mutated' for x in after['latest_bulletin']['notices']))
        self.assertEqual(after['last_result'], {'action': 'wait'})
        self.assertEqual(after['new_messages'], [])
        env.step(dict(action='wait', duration_seconds=1800))
        bulletins = [x for x in env.public_payload()['new_messages'] if x['record_type'] == 'bulletin']
        self.assertEqual(len(bulletins), 2)

    def test_requests_require_full_window_and_remain_active_after_completion(self):
        env = environment()
        start = env.now
        request = dict(request_id='r', target_ids=['a'], minimum_completed=1,
            completion_factor_threshold=.5, completion_reward=60,
            issued_at_utc=utc(start+60), deadline_utc=utc(start+1800))
        env._requests = [request]
        env._attribute_requests('a', .8, start, start+120)
        env._attribute_requests('a', .8, start+1500, start+1860)
        self.assertEqual(env.request_hits, {})
        env._attribute_requests('a', .8, start+60, start+1800)
        env._settle_requests()
        env.now = start+900
        active = env._active_requests()
        self.assertEqual(active[0]['remaining_count'], 0)
        self.assertEqual(env.request_rewards, 60)
        env.now = start+1800
        self.assertEqual(env._active_requests(), [])
        env._emit_request_results()
        self.assertEqual(env.messages[-1]['status'], 'completed')
        self.assertEqual(env.messages[-1]['score_delta'], 60)

    def test_resync_rebuilds_two_maxima_and_revokes_expired_request_reward(self):
        env = environment()
        start = env.now
        env._requests = [dict(request_id='r', target_ids=['a'], minimum_completed=1,
            completion_factor_threshold=.85, completion_reward=60,
            issued_at_utc=utc(start), deadline_utc=utc(start+1800))]
        env.history = [dict(valid=True, start=start, end=start+600,
                            hits=[dict(target_id='a', factor=.8, score=1.632)]),
                       dict(valid=True, start=start+600, end=start+1200,
                            hits=[dict(target_id='a', factor=.9, score=1.53)])]
        env.now = start+1800
        env._invalidate_observations(0, 0)
        self.assertEqual(env.best_score['a'], 1.632)
        self.assertEqual(env.best_factor['a'], .9)
        self.assertEqual(env.request_rewards, 60)
        env.messages = []
        env._invalidate_observations(1, 2)
        self.assertEqual(env.best_score['a'], 1.632)
        self.assertEqual(env.best_factor['a'], .8)
        self.assertEqual(env.request_rewards, 0)
        resync = env.messages[0]
        self.assertEqual(resync['invalidated_window']['action_index_start'], 1)
        self.assertNotIn('factor', json.dumps(resync))
        revised = env.messages[-1]
        self.assertEqual(revised['status'], 'expired')
        self.assertEqual(revised['score_delta'], -60)
        self.assertTrue(revised['revised'])

    def test_uniformity_uses_completed_fraction_and_includes_zero_bands(self):
        env = environment()
        env.cat.ra[:] = [1, 2, 11]
        env.best_factor = {'a': .5, 'c': .5}
        self.assertAlmostEqual(env.summary()['uniformity_penalty'], 20)
        env.best_factor = {'a': .5, 'b': .5}
        self.assertAlmostEqual(env.summary()['uniformity_penalty'], 100)

    def test_fault_reduces_completion_but_not_program_band(self):
        env = environment()
        env._weather[0][:] = 1.
        env._fault_at[0] = env.now
        env.cat.flux[0] = .1
        action = dict(action='observe', duration_seconds=900, pointing=dict(alt_deg=60., az_deg=0.),
                      assignments={'0': 'a'}, program='DARK')
        def horizontal(ra, dec, *args):
            return np.full(len(ra), 60.), np.zeros(len(ra))
        with patch('experiments.v4_current_v2.planner.equatorial_to_horizontal', horizontal), \
             patch('experiments.v4_current_v2.planner.fibre_indices', lambda alt, az, *args: np.zeros(len(alt), dtype=int)), \
             patch('experiments.v4_current_v2.planner.lunar_factor', lambda ra, dec, *args: np.ones(len(ra))):
            result = env.step(action)
        hit = env.history[-1]['hits'][0]
        self.assertAlmostEqual(hit['score'] / (env.cat.weight[0] * hit['factor']), 1.2)
        self.assertLess(hit['factor'], .05)
        self.assertEqual(set(result['hits'][0]), {'target_id', 'score'})

    def test_duplicate_numeric_fibres_and_extra_fields_are_rejected(self):
        env = environment()
        base = dict(action='observe', duration_seconds=60, pointing=dict(alt_deg=60., az_deg=0.),
                    assignments={'5': 'a', '05': 'b'}, program='DARK')
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            env.step(base)
        self.assertEqual(env.actions, 0)
        with self.assertRaisesRegex(ValueError, 'extra'):
            env.step(dict(action='wait', duration_seconds=60, hidden=1))
        with self.assertRaisesRegex(ValueError, 'until_utc'):
            env.step(dict(action='wait', duration_seconds=60, until_utc=utc(env.now+60)))

    def test_wait_until_crosses_nights_and_delivers_request(self):
        env = environment()
        env.public_payload()
        when = env.nights[2]['observing_start_utc']
        env.step(dict(action='wait', until_utc=when))
        snapshot = env.public_payload()
        self.assertEqual(snapshot['now_utc'], when)
        self.assertEqual(len(snapshot['active_requests']), 1)
        self.assertTrue(any(x['record_type'] == 'observation_request' for x in snapshot['new_messages']))


if __name__ == '__main__':
    unittest.main()
