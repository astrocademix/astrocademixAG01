import unittest
from datetime import timedelta
from unittest.mock import patch
import numpy as np

from .planner import (Catalogue, Planner, equatorial_to_horizontal,
                      horizontal_to_equatorial, project_fibres, offset_horizontal,
                      normalized_airmass, minimum_altitude_over_exposure,
                      local_sidereal_deg, utc_datetime)


def fixture():
    when='2026-10-05T02:00:00Z';lat=-24.6157;lon=-70.3976
    ra,dec=horizontal_to_equatorial(np.asarray([65.,65.2,65.4]),np.asarray([30.,30.2,30.4]),when,lat,lon)
    scenario=dict(site=dict(latitude_deg=lat,longitude_deg=lon),minimum_altitude_deg=30.)
    score=dict(q0=.68,flux_zero_point=.5,exposure_zero_point_seconds=900,airmass_exponent=.6,
               program=dict(bands=dict(DARK=.65,BRIGHT=.4),multipliers=dict(DARK=1.2,BRIGHT=1.12,BACKUP=1.06),mismatch_multiplier=1.),
               required=dict(penalty_per_missing=50,observed_factor_threshold=.5),
               observation_requests=dict(completion_factor_threshold=.5))
    fiber=dict(field=dict(n_fibers=16,fiber_area_deg2=.4,gap_deg=0),exposure=dict(min_duration_seconds=60,max_duration_seconds=3600))
    cat=Catalogue(np.asarray(['a','b','c']),ra,dec,np.asarray([1.,.5,.1]),np.asarray([1.,1.5,2.]),
                  np.asarray([True,False,True]),scenario,score,fiber,[],[])
    state=dict(now_utc=when,end_utc='2026-10-05T06:00:00Z',quality_estimate=.8,quality_uncertainty=0.,best_factor={},best_score={},remaining_nights=10,active_requests=[])
    return cat,state


class PlannerTests(unittest.TestCase):
    def test_equatorial_horizontal_roundtrip_and_ra_wrap(self):
        ra=np.asarray([359.99,.01,90.,180.]);dec=np.asarray([-50.,-10.,0.,35.])
        alt,az=equatorial_to_horizontal(ra,dec,'2026-10-05T02:00:00Z',-24.6157,-70.3976)
        back_r,back_d=horizontal_to_equatorial(alt,az,'2026-10-05T02:00:00Z',-24.6157,-70.3976)
        np.testing.assert_allclose((back_r-ra+180)%360-180,0,atol=1e-9)
        np.testing.assert_allclose(back_d,dec,atol=1e-9)

    def test_horizontal_grid_wrap_and_outside(self):
        cells,x,y=project_fibres([60.,60.,60.],[359.9,.1,10.],60.,0.)
        self.assertTrue(np.all(cells[:2]>=0));self.assertEqual(cells[2],-1)
        self.assertTrue(x[0]<0<x[1]);self.assertTrue(np.isfinite(y).all())

    def test_threshold_and_nonaccumulating_progress(self):
        cat,state=fixture();planner=Planner(cat)
        geometry=planner._geometry(cat.ra[0],cat.dec[0],state)
        c=planner._controls({})
        # Locate the actual cell independently of arbitrary fixture orientation.
        cell=int(geometry['cells'][np.flatnonzero(geometry['indices']==0)[0]])
        below=planner._evaluate(geometry,150,state,c,forced={str(cell):'a'})
        above=planner._evaluate(geometry,600,state,c,forced={str(cell):'a'})
        self.assertLess(below['factors'][0],.5);self.assertEqual(below['required_gain'],0)
        self.assertGreaterEqual(above['factors'][0],.5);self.assertEqual(above['required_gain'],50)
        after=planner.apply_candidate(state,below);after=planner.apply_candidate(after,below)
        self.assertAlmostEqual(after['best_factor']['a'],below['factors'][0])

    def test_repeated_identical_score_has_no_marginal_gain(self):
        cat,state=fixture();planner=Planner(cat)
        candidates=planner.propose(state,{},max_candidates=8)
        self.assertTrue(candidates)
        item=candidates[0];recorded=planner.apply_candidate(state,item)
        recorded['now_utc']=state['now_utc']
        repeated=planner.evaluate_action(item['action'],recorded)
        self.assertIsNotNone(repeated);self.assertAlmostEqual(repeated['est_gain'],0.,places=8)
        self.assertEqual(item['maps'].shape,(12,4,4));self.assertEqual(item['scalars'].shape,(12,))

    def test_control_weights_do_not_change_fixed_action_gain(self):
        cat,state=fixture();planner=Planner(cat)
        item=planner.propose(state,{},max_candidates=1)[0]
        geom=planner._geometry(item['pointing_ra_deg'],item['pointing_dec_deg'],state)
        other=planner._evaluate(geom,item['duration_seconds'],state,planner._controls(dict(required_weight=2,science_weight=.5)),
                                forced=item['action']['assignments'],program=item['action']['program'])
        self.assertAlmostEqual(item['est_gain'],other['est_gain'])

    def test_teacher_shared_budget_and_no_state_mutation(self):
        cat,state=fixture();planner=Planner(cat);items=planner.propose(state,{},max_candidates=3)
        labels=planner.teacher_targets(items,state,dict(horizon=1))
        np.testing.assert_allclose(labels,np.asarray([x['est_gain']/7200 for x in items]),rtol=1e-6)
        self.assertEqual(state['best_score'],{});self.assertEqual(state['best_factor'],{})
        self.assertTrue(np.isfinite(labels).all())

    def test_outer_boundary_and_fibre_centres(self):
        import math
        width=math.sqrt(.4);alt=[];az=[]
        for row in range(4):
            for column in range(4):
                a,z=offset_horizontal(50.,355.,(column-1.5)*width,(row-1.5)*width)
                alt.append(a);az.append(z)
        cells,_,_=project_fibres(alt,az,50.,355.)
        np.testing.assert_array_equal(cells,np.arange(16))
        a,z=offset_horizontal(50.,355.,2*width,2*width)
        cells,_,_=project_fibres([a],[z],50.,355.)
        self.assertEqual(cells[0],15)
        a,z=offset_horizontal(50.,355.,2*width+.001,2*width)
        self.assertEqual(project_fibres([a],[z],50.,355.)[0][0],-1)

    def test_q_can_exceed_one_and_program_b_is_independent(self):
        cat,state=fixture();planner=Planner(cat)
        high=dict(state,quality_estimate=2.,program_quality_estimate=.3)
        self.assertGreater(planner._quality(high,np.asarray([90.]))[0],1.)
        geom=planner._geometry(cat.ra[0],cat.dec[0],high)
        cell=int(geom['cells'][np.flatnonzero(geom['indices']==0)[0]])
        dark=planner._evaluate(geom,600,high,planner._controls({}),forced={str(cell):'a'},program='DARK')
        backup=planner._evaluate(geom,600,high,planner._controls({}),forced={str(cell):'a'},program='BACKUP')
        self.assertGreater(dark['qualities'][0],1.)
        self.assertLess(dark['program_qualities'][0],.4)
        self.assertAlmostEqual(backup['scores'][0]/dark['scores'][0],1.06)
        self.assertAlmostEqual(float(normalized_airmass(90)),1.)

    def test_request_uses_window_membership_and_minimum(self):
        cat,state=fixture();planner=Planner(cat)
        # All-time completion before issuance must not satisfy a new request.
        state['best_factor']={'a':1.,'b':1.,'c':1.}
        state['active_requests']=[dict(target_ids=['a','b','c'],minimum_completed=2,completion_reward=100.,
                                      completion_factor_threshold=.5,completed_target_ids=['b'],
                                      issued_at_utc=state['now_utc'],deadline_utc=state['end_utc'])]
        geom=planner._geometry(cat.ra[0],cat.dec[0],state)
        cell=int(geom['cells'][np.flatnonzero(geom['indices']==0)[0]])
        item=planner._evaluate(geom,600,state,planner._controls({}),forced={str(cell):'a'})
        self.assertEqual(item['request_gain'],100.)
        after=planner.apply_candidate(state,item)
        self.assertEqual(after['active_requests'][0]['completed_target_ids'],['a','b'])
        self.assertEqual(state['active_requests'][0]['completed_target_ids'],['b'])

    def test_teacher_indices_share_full_successor_pool(self):
        cat,state=fixture();planner=Planner(cat);items=planner.propose(state,{},max_candidates=3)
        all_labels=planner.teacher_targets(items,state,dict(horizon=2))
        subset=planner.teacher_targets(items,state,dict(horizon=2),indices=[1])
        np.testing.assert_allclose(subset,all_labels[[1]],rtol=1e-6)

    def test_opportunity_never_credits_same_observed_targets_again(self):
        cat,state=fixture();planner=Planner(cat);item=planner.propose(state,{},max_candidates=1)[0]
        planner.teacher_targets([item],state,dict(horizon=2))
        detail=planner.last_teacher_details[0]
        self.assertEqual(detail['opportunity_science_value'],0.)
        self.assertEqual(detail['opportunity_science_capacity'],0.)

    def test_fully_saturated_catalogue_does_not_generate_repeats(self):
        cat,state=fixture();planner=Planner(cat)
        state['best_factor']={str(t):1. for t in cat.ids}
        state['best_score']={str(t):float(w*1.2) for t,w in zip(cat.ids,cat.weight)}
        self.assertEqual(planner.propose(state,{},max_candidates=8),[])

    def test_continuous_altitude_minimum_includes_lower_culmination(self):
        when='2026-10-05T02:00:00Z';duration=3600.;lat=-24.6157;lon=-70.3976
        span=360.98564736629*duration/86400
        ra=(local_sidereal_deg(when,lon)-180+span/2)%360
        minimum=float(minimum_altitude_over_exposure(ra,-80.,when,duration,lat,lon))
        middle=utc_datetime(when)+timedelta(seconds=duration/2)
        expected=float(equatorial_to_horizontal(ra,-80.,middle,lat,lon)[0])
        start=float(equatorial_to_horizontal(ra,-80.,when,lat,lon)[0])
        self.assertAlmostEqual(minimum,expected,places=8)
        self.assertLess(minimum,start)

    def test_planning_simpson_agrees_with_smooth_120_second_integral(self):
        cat,state=fixture();planner=Planner(cat);geometry=planner._geometry(cat.ra[0],cat.dec[0],state)
        duration=3600;valid,q,b,_=planner._astronomy(geometry,duration,state)
        ids=geometry['indices'];now=utc_datetime(state['now_utc']);reference=np.zeros(len(ids))
        for start in range(0,duration,120):
            moment=now+timedelta(seconds=start+60)
            alt,_=planner._horizontal(cat.ra[ids],cat.dec[ids],moment)
            reference+=planner._quality(state,alt,cat.ra[ids],cat.dec[ids],moment)/30
        np.testing.assert_allclose(q,reference,atol=5e-4,rtol=1e-3)
        self.assertTrue(valid.any())

    def test_actual_candidate_cap_limits_pointing_work(self):
        cat,state=fixture();planner=Planner(cat)
        with patch.object(planner,'_duration_options',wraps=planner._duration_options) as options:
            result=planner.propose(state,dict(candidate_budget=96),max_candidates=4)
        self.assertLessEqual(len(result),4)
        self.assertLessEqual(options.call_count,1)

    def test_astronomy_cache_does_not_freeze_weather_prior(self):
        cat,state=fixture();planner=Planner(cat);geometry=planner._geometry(cat.ra[0],cat.dec[0],state)
        _,q1,b1,_=planner._astronomy(geometry,600,state)
        changed=dict(state,quality_estimate=state['quality_estimate']*2)
        _,q2,b2,_=planner._astronomy(geometry,600,changed)
        np.testing.assert_allclose(q2,2*q1)
        np.testing.assert_array_equal(b2,b1)

if __name__=='__main__':unittest.main()
