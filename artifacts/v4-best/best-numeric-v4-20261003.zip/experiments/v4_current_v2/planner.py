"""Public-information numerical planning for the current four v4 practice cards.

This is an APPROXIMATE planning model, not the official simulator or scorer.
The published guide defines a tracked horizontal gnomonic square, row-major
fibres, normalized airmass and an approximate lunar ephemeris, implemented here.
Unknown weather/instrument/directional effects remain public-state estimates.
Supplied Q and B are separate, q0-normalized zenith estimates, not probabilities.
No hidden weather, future bulletins or truth files are read.
Uniformity, reporting and unannounced events are not predicted here.
"""
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
import csv
import json
import math
from pathlib import Path
from functools import lru_cache

import numpy as np

APPROXIMATION = 'documented geometry/astronomy with estimated Q/B weather; not verified official scoring'
PLANNING_BUDGET = dict(astronomy_integration='three-point Simpson; exact altitude extrema',
                       proposal_durations=6,successor_pointings=3,successor_durations=3,
                       time_budget_seconds=7200)
MAP_CHANNELS = (
    'log_target_count', 'log_remaining_science', 'log_required_unfinished',
    'log_request_unfinished', 'mean_log_flux', 'max_log_flux',
    'mean_quality_estimate', 'quality_uncertainty', 'closing_window_fraction',
    'mean_best_factor', 'log_required_threshold_rate', 'log_science_gain_at_duration',
)
SCALAR_NAMES = (
    'duration_fraction', 'mean_quality', 'quality_uncertainty',
    'required_remaining_fraction', 'night_time_remaining_fraction',
    'remaining_nights_fraction', 'pointing_altitude_fraction',
    'sin_pointing_ra', 'cos_pointing_ra', 'pointing_declination_fraction',
    'science_gain_per_fibre', 'new_required_fraction',
)


def utc_datetime(value):
    if isinstance(value, datetime):
        result = value
    else:
        result = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('UTC times must include a timezone')
    return result.astimezone(timezone.utc)


def iso_utc(value):
    return utc_datetime(value).isoformat().replace('+00:00', 'Z')


def local_sidereal_deg(when, longitude_deg):
    """Exactly the low-order LST expression in public guide equation (1)."""
    jd = utc_datetime(when).timestamp() / 86400. + 2440587.5
    d = jd - 2451545.
    return (280.46061837 + 360.98564736629 * d + longitude_deg) % 360.


def equatorial_to_horizontal(ra_deg, dec_deg, when, latitude_deg, longitude_deg):
    """Altitude and azimuth (north=0, east=90), broadcasting numpy inputs."""
    h = np.deg2rad(local_sidereal_deg(when, longitude_deg) - np.asarray(ra_deg))
    d, p = np.deg2rad(dec_deg), np.deg2rad(latitude_deg)
    east = -np.cos(d) * np.sin(h)
    north = np.sin(d)*np.cos(p) - np.cos(d)*np.cos(h)*np.sin(p)
    up = np.sin(d)*np.sin(p) + np.cos(d)*np.cos(h)*np.cos(p)
    return np.rad2deg(np.arcsin(np.clip(up, -1, 1))), np.rad2deg(np.arctan2(east, north)) % 360.


def horizontal_to_equatorial(alt_deg, az_deg, when, latitude_deg, longitude_deg):
    a, z, p = np.deg2rad(alt_deg), np.deg2rad(az_deg), np.deg2rad(latitude_deg)
    east, north, up = np.cos(a)*np.sin(z), np.cos(a)*np.cos(z), np.sin(a)
    sd = north*np.cos(p) + up*np.sin(p)
    chcd = up*np.cos(p) - north*np.sin(p)
    hour_angle = np.arctan2(-east, chcd)
    return (local_sidereal_deg(when, longitude_deg) - np.rad2deg(hour_angle)) % 360., np.rad2deg(np.arcsin(np.clip(sd, -1, 1)))


def horizontal_vectors(alt_deg, az_deg):
    a, z = np.deg2rad(alt_deg), np.deg2rad(az_deg)
    return np.column_stack((np.cos(a)*np.sin(z), np.cos(a)*np.cos(z), np.sin(a)))


def normalized_airmass(altitude_deg):
    z = 90.-np.asarray(altitude_deg)
    denominator = np.cos(np.deg2rad(z)) + .50572*np.maximum(96.07995-z, .01)**-1.6364
    return (1.+.50572*96.07995**-1.6364)/np.maximum(denominator, 1e-9)


@lru_cache(maxsize=4096)
def sun_moon_equatorial(when):
    """Public guide equations (5)-(11), deliberately not a new ephemeris."""
    d=utc_datetime(when).timestamp()/86400.+2440587.5-2451545.
    g=np.deg2rad((357.528+.9856003*d)%360)
    longitude=np.deg2rad(((280.460+.9856474*d)+1.915*np.sin(g)+.020*np.sin(2*g))%360)
    obliquity=np.deg2rad(23.439-.0000004*d)
    sun_ra=np.arctan2(np.cos(obliquity)*np.sin(longitude),np.cos(longitude))
    sun_dec=np.arcsin(np.sin(obliquity)*np.sin(longitude))
    moon_longitude=np.deg2rad((218.316+13.176396*d)%360+6.289*np.sin(np.deg2rad((134.963+13.064993*d)%360)))
    moon_latitude=np.deg2rad(5.128*np.sin(np.deg2rad((93.272+13.229350*d)%360)))
    x=np.cos(moon_longitude)*np.cos(moon_latitude)
    y=np.sin(moon_longitude)*np.cos(moon_latitude)*np.cos(obliquity)-np.sin(moon_latitude)*np.sin(obliquity)
    z=np.sin(moon_longitude)*np.cos(moon_latitude)*np.sin(obliquity)+np.sin(moon_latitude)*np.cos(obliquity)
    return (float(np.rad2deg(sun_ra)%360),float(np.rad2deg(sun_dec)),
            float(np.rad2deg(np.arctan2(y,x))%360),float(np.rad2deg(np.arcsin(np.clip(z,-1,1)))))


def lunar_factor(ra_deg,dec_deg,when,latitude_deg,longitude_deg,config):
    config=config.get('lunar_model',config)
    sr,sd,mr,md=sun_moon_equatorial(when)
    moon_alt,_=equatorial_to_horizontal(mr,md,when,latitude_deg,longitude_deg)
    if moon_alt<=0:return np.ones_like(np.asarray(ra_deg),dtype=float)
    def cosine_distance(ar,ad,br,bd):
        ad,bd=np.deg2rad(ad),np.deg2rad(bd)
        return np.clip(np.sin(ad)*np.sin(bd)+np.cos(ad)*np.cos(bd)*np.cos(np.deg2rad(np.asarray(ar)-br)),-1,1)
    illumination=(1-cosine_distance(sr,sd,mr,md))/2
    distance=np.rad2deg(np.arccos(cosine_distance(ra_deg,dec_deg,mr,md)))
    return 1-float(config.get('maximum_penalty',.75))*illumination*np.sin(np.deg2rad(moon_alt))**float(config.get('altitude_exponent',1.))*np.exp(-distance/float(config.get('angular_decay_scale_deg',35.)))


def project_fibres(alt_deg, az_deg, pointing_alt_deg, pointing_az_deg, side=4, cell_width_deg=math.sqrt(.4)):
    """Horizontal gnomonic square following guide equation (16).

    Returns cell ids (-1 outside), x/y normalized to [-1,1) inside the field.
    Outer boundaries are included. Internal boundaries use floor/right-or-top;
    the guide does not specify their backend tie rule, so avoid exact boundaries.
    """
    if side < 1 or not 0 < cell_width_deg * side < 90:
        raise ValueError('invalid fibre field')
    vectors = horizontal_vectors(np.atleast_1d(alt_deg), np.atleast_1d(az_deg))
    a, z = np.deg2rad([pointing_alt_deg, pointing_az_deg])
    centre = np.array([np.cos(a)*np.sin(z), np.cos(a)*np.cos(z), np.sin(a)])
    right = np.array([np.cos(z), -np.sin(z), 0.])
    up = np.array([-np.sin(a)*np.sin(z), -np.sin(a)*np.cos(z), np.cos(a)])
    denominator = vectors @ centre
    half = np.deg2rad(side*cell_width_deg/2)
    safe = np.where(denominator > 0, denominator, 1.)
    x, y = (vectors @ right)/safe/half, (vectors @ up)/safe/half
    cells = np.full(len(vectors), -1, dtype=np.int64)
    inside = (denominator > 0) & (x >= -1-1e-12) & (x <= 1+1e-12) & (y >= -1-1e-12) & (y <= 1+1e-12)
    rows=np.clip(np.floor((y[inside]+1)*side/2).astype(int),0,side-1)
    columns=np.clip(np.floor((x[inside]+1)*side/2).astype(int),0,side-1)
    cells[inside] = rows*side+columns
    return cells, x, y


def fibre_indices(target_alt,target_az,pointing_alt,pointing_az,side=4,cell_width_deg=math.sqrt(.4)):
    return project_fibres(target_alt,target_az,pointing_alt,pointing_az,side,cell_width_deg)[0]


def offset_horizontal(alt_deg,az_deg,x_deg,y_deg):
    """Inverse tangent-plane offset, used to keep anchor targets off boundaries."""
    a,z=np.deg2rad([alt_deg,az_deg])
    centre=np.array([np.cos(a)*np.sin(z),np.cos(a)*np.cos(z),np.sin(a)])
    right=np.array([np.cos(z),-np.sin(z),0.])
    up=np.array([-np.sin(a)*np.sin(z),-np.sin(a)*np.cos(z),np.cos(a)])
    v=centre+np.deg2rad(x_deg)*right+np.deg2rad(y_deg)*up;v/=np.linalg.norm(v)
    return float(np.rad2deg(np.arcsin(v[2]))),float(np.rad2deg(np.arctan2(v[0],v[1]))%360)


def minimum_altitude_over_exposure(ra_deg,dec_deg,when,duration_seconds,latitude_deg,longitude_deg):
    """Exact extrema for the guide's linear sidereal rotation and fixed RA/Dec.

    Endpoints alone miss a lower culmination inside the interval. Include every
    crossing of hour angle pi modulo 2pi; upper culmination cannot be a minimum
    for geographic latitudes and declinations in their physical ranges.
    """
    h0=np.deg2rad(local_sidereal_deg(when,longitude_deg)-np.asarray(ra_deg))
    h1=h0+np.deg2rad(360.98564736629*float(duration_seconds)/86400.)
    dec=np.deg2rad(dec_deg);lat=np.deg2rad(latitude_deg)
    baseline=np.sin(lat)*np.sin(dec);amplitude=np.cos(lat)*np.cos(dec)
    min_cos=np.minimum(np.cos(h0),np.cos(h1))
    next_lower=np.pi+2*np.pi*np.ceil((h0-np.pi)/(2*np.pi))
    min_cos=np.where(next_lower<=h1+1e-14,-1.,min_cos)
    return np.rad2deg(np.arcsin(np.clip(baseline+amplitude*min_cos,-1,1)))


@dataclass
class Catalogue:
    ids: np.ndarray
    ra: np.ndarray
    dec: np.ndarray
    flux: np.ndarray
    weight: np.ndarray
    required: np.ndarray
    scenario: dict
    score_config: dict
    fiber_config: dict
    calendar: list
    footprint: list
    target_classes: np.ndarray = None

    def __post_init__(self):
        self.ids = np.asarray(self.ids, dtype=str)
        for name in ('ra', 'dec', 'flux', 'weight'):
            setattr(self, name, np.asarray(getattr(self, name), dtype=np.float64))
        self.required = np.asarray(self.required, dtype=bool)
        if self.target_classes is not None:
            self.target_classes=np.asarray(self.target_classes,dtype=str)
        n = len(self.ids)
        if not n or any(getattr(self, name).shape != (n,) for name in ('ra', 'dec', 'flux', 'weight', 'required')):
            raise ValueError('catalogue arrays must be nonempty matching vectors')
        if len(set(self.ids)) != n or any(not np.isfinite(getattr(self, name)).all() for name in ('ra', 'dec', 'flux', 'weight')):
            raise ValueError('duplicate identifiers or nonfinite catalogue data')
        if np.any(self.flux < 0) or np.any(self.weight < 0) or np.any(abs(self.dec) > 90):
            raise ValueError('invalid flux, weight or declination')
        self.ra %= 360.
        self.index = {str(tid): i for i, tid in enumerate(self.ids)}
        self.latitude = float(self.scenario['site']['latitude_deg'])
        self.longitude = float(self.scenario['site']['longitude_deg'])
        self.minimum_altitude = float(self.scenario.get('minimum_altitude_deg', 30.))
        field = self.fiber_config['field']
        self.side = math.isqrt(int(field['n_fibers']))
        if self.side*self.side != field['n_fibers'] or float(field.get('gap_deg', 0)) != 0:
            raise ValueError('planner supports square grids with no gaps')
        self.cell_width = math.sqrt(float(field['fiber_area_deg2']))
        self.norm = float(self.score_config['flux_zero_point'])*float(self.score_config['exposure_zero_point_seconds'])
        if self.norm <= 0 or self.side != 4:
            raise ValueError('current 12x4x4 feature contract requires the current four-card 4x4 grid')

    @classmethod
    def from_directory(cls, directory):
        root = Path(directory)
        def read_csv(name):
            with (root/'public'/name).open() as stream:
                return list(csv.DictReader(stream))
        rows = read_csv('targets.csv')
        config = [json.loads((root/'config'/name).read_text()) for name in
                  ('v4_scenario.json', 'v4_score_config.json', 'v4_fiber_config.json')]
        return cls(np.asarray([r['target_id'] for r in rows]),
                   *[np.asarray([float(r[key]) for r in rows]) for key in ('ra_deg','dec_deg','feature_flux','science_weight')],
                   np.asarray([r['required'].strip().lower() in ('true','1','yes') for r in rows]),
                   *config, read_csv('v4_night_calendar.csv'), read_csv('footprint.csv'),
                   np.asarray([r.get('target_class','') for r in rows]))


class Planner:
    def __init__(self, catalogue):
        self.catalogue = catalogue
        self.last_teacher_details = []
        self.planning_budget=dict(PLANNING_BUDGET)
        self._geometry_cache={};self._horizontal_cache={};self._astronomy_cache={}

    def _clear_cache(self):
        self._geometry_cache.clear();self._horizontal_cache.clear();self._astronomy_cache.clear()

    def _controls(self, supplied):
        c = dict(supplied or {})
        for name, low, high, default in (('required_weight',.5,2.,1.), ('science_weight',.5,2.,1.),
                                        ('exposure_margin',1.,1.4,1.1), ('candidate_budget',16,96,64),
                                        ('horizon',1,2,2), ('wait_seconds',0,900,0)):
            value = float(c.get(name, default))
            c[name] = float(np.clip(value, low, high)) if math.isfinite(value) else default
        c['priority_targets'] = [str(t) for t in c.get('priority_targets', [])[:8] if str(t) in self.catalogue.index]
        sectors = c.get('sector_weights', {})
        c['sector_weights'] = {int(k): float(np.clip(float(v), .5, 2.)) for k,v in sectors.items()
                               if str(k).lstrip('-').isdigit() and 0 <= int(k) < 36 and math.isfinite(float(v))}
        if c.get('focus_ra_deg') is not None:
            focus = float(c['focus_ra_deg'])
            c['focus_ra_deg'] = focus % 360 if math.isfinite(focus) else None
        return c

    def _progress(self, state):
        if '_planner_progress_arrays' in state:
            return state['_planner_progress_arrays']
        cat = self.catalogue
        factor = np.asarray([float(state.get('best_factor', {}).get(t, 0.)) for t in cat.ids])
        score = np.asarray([float(state.get('best_score', {}).get(t, 0.)) for t in cat.ids])
        if not np.isfinite(factor).all() or not np.isfinite(score).all():
            raise ValueError('nonfinite progress')
        return np.clip(factor, 0, 1), np.maximum(score, 0)

    def _requests(self, state):
        """Only published active requests. Completion needs every listed target.

        Request completion is specific to its time window, not all-time factors.
        """
        result = []
        now = utc_datetime(state['now_utc'])
        for r in state.get('active_requests', []):
            if r.get('completed', False):
                continue
            deadline = r.get('deadline_utc', r.get('expires_utc'))
            if deadline and utc_datetime(deadline) < now:
                continue
            issued=r.get('issued_at_utc')
            if issued and utc_datetime(issued)>now:continue
            ids = r.get('target_ids', [r['target_id']] if 'target_id' in r else [])
            indices = [self.catalogue.index[str(t)] for t in ids if str(t) in self.catalogue.index]
            if len(indices) == len(ids) and indices:
                completed=set(map(str,r.get('completed_target_ids',[])))
                minimum=int(r.get('minimum_completed',len(indices)))
                if len(completed)>=minimum:continue
                result.append(dict(indices=np.asarray(indices,dtype=int),reward=max(0.,float(r.get('reward',r.get('completion_reward',0.)))),
                                   deadline=deadline,minimum=minimum,completed=completed,
                                   threshold=float(r.get('completion_factor_threshold',self.catalogue.score_config.get('observation_requests',{}).get('completion_factor_threshold',.5)))))
        return result

    def _quality(self, state, altitude, ra=None, dec=None, when=None, program=False):
        # B excludes instrument efficiency/directional events. Its independent
        # prior must never be inferred from Q after an instrument failure.
        name='program_quality_estimate' if program else 'quality_estimate'
        q = float(state.get(name,1.0))
        uncertainty = float(state.get('quality_uncertainty', 0.))
        if not math.isfinite(q) or not math.isfinite(uncertainty):
            raise ValueError('nonfinite public quality estimate')
        q = max(0.,q - .5*max(0., uncertainty))
        value=q/normalized_airmass(altitude)**float(self.catalogue.score_config.get('airmass_exponent', .6))
        if ra is not None:
            cat=self.catalogue
            value=value*lunar_factor(ra,dec,when,cat.latitude,cat.longitude,cat.score_config.get('lunar_model',{}))
        return value

    def _horizontal(self, ra, dec, when):
        cat = self.catalogue
        return equatorial_to_horizontal(ra, dec, when, cat.latitude, cat.longitude)

    def _geometry(self, ra, dec, state, horizontal=None, pointing=None):
        cat = self.catalogue
        cache_key=(str(state['now_utc']),float(ra),float(dec),None if pointing is None else (float(pointing['alt_deg']),float(pointing['az_deg'])))
        if cache_key in self._geometry_cache:return self._geometry_cache[cache_key]
        pointing_alt, pointing_az = self._horizontal(ra, dec, state['now_utc'])
        if pointing is not None:
            pointing_alt,pointing_az=float(pointing['alt_deg']),float(pointing['az_deg'])
        if not math.isfinite(pointing_alt) or not math.isfinite(pointing_az) or pointing_alt < 0 or pointing_alt > 90 or not 0<=pointing_az<360:
            return None
        if horizontal is None:
            time_key=str(state['now_utc'])
            if time_key not in self._horizontal_cache:
                self._horizontal_cache[time_key]=self._horizontal(cat.ra,cat.dec,state['now_utc'])
            horizontal=self._horizontal_cache[time_key]
        alt, az = horizontal
        # Dec/RA spherical neighbourhood check before projecting; this only
        # reduces work and never limits to a preferred RA region.
        radius = cat.side*cat.cell_width
        near = np.flatnonzero((abs(alt-pointing_alt) <= radius) & (alt >= cat.minimum_altitude))
        cells, x, y = project_fibres(alt[near], az[near], pointing_alt, pointing_az, cat.side, cat.cell_width)
        inside = cells >= 0
        if not inside.any():
            return None
        result=dict(indices=near[inside], cells=cells[inside], x=x[inside], y=y[inside],
                    alt=alt[near[inside]], pointing_alt=float(pointing_alt), pointing_az=float(pointing_az),
                    ra=float(ra)%360, dec=float(dec))
        self._geometry_cache[cache_key]=result
        return result

    def _astronomy(self,geometry,duration,state):
        """Planning integral only; the independent proxy environment keeps 120s.

        Weather priors are constant over a proposal, so integrate the smooth
        public astronomy with Simpson rather than repeating identical weather
        assumptions at every 120s. Altitude validity uses analytic extrema.
        """
        cat=self.catalogue;ids=geometry['indices'];now=utc_datetime(state['now_utc'])
        key=(now,float(geometry['ra']),float(geometry['dec']),geometry['pointing_az'],int(duration))
        if key not in self._astronomy_cache:
            times=[now,now+timedelta(seconds=duration/2),now+timedelta(seconds=duration)]
            h0=np.deg2rad(local_sidereal_deg(now,cat.longitude)-cat.ra[ids])
            h=h0[None,:]+np.deg2rad(360.98564736629*np.asarray([0.,duration/2,duration])/86400.)[:,None]
            d=np.deg2rad(cat.dec[ids]);p=np.deg2rad(cat.latitude)
            alt=np.rad2deg(np.arcsin(np.clip(np.sin(p)*np.sin(d)[None,:]+np.cos(p)*np.cos(d)[None,:]*np.cos(h),-1,1)))
            moon=np.asarray([lunar_factor(cat.ra[ids],cat.dec[ids],t,cat.latitude,cat.longitude,cat.score_config) for t in times])
            values=moon/normalized_airmass(alt)**float(cat.score_config.get('airmass_exponent',.6))
            mean=(values[0]+4*values[1]+values[2])/6
            minimum=minimum_altitude_over_exposure(cat.ra[ids],cat.dec[ids],now,duration,cat.latitude,cat.longitude)
            self._astronomy_cache[key]=(minimum>=cat.minimum_altitude,mean,alt[-1])
        valid,mean,alt_end=self._astronomy_cache[key]
        uncertainty=max(0.,float(state.get('quality_uncertainty',0.)))
        q=max(0.,float(state.get('quality_estimate',1.))-.5*uncertainty)
        b=max(0.,float(state.get('program_quality_estimate',1.))-.5*uncertainty)
        if not math.isfinite(q) or not math.isfinite(b):raise ValueError('nonfinite public quality estimate')
        return valid,mean*q,mean*b,alt_end

    def _select_durations(self,geometry,durations,state,controls,limit):
        """Cheap vectorized duration screen; final candidates use Simpson Q/B.

        Evaluate ALL threshold proposals under the start-time quality, then
        retain their strongest predicted gain/time and high-total-gain options.
        This keeps meaningful threshold durations instead of uniform sampling.
        """
        if len(durations)<=limit:return durations
        cat=self.catalogue;ids=geometry['indices'];cells=geometry['cells']
        ds=np.asarray(durations,dtype=float);factor,score=self._progress(state)
        q=self._quality(state,geometry['alt'],cat.ra[ids],cat.dec[ids],state['now_utc'])
        b=self._quality(state,geometry['alt'],cat.ra[ids],cat.dec[ids],state['now_utc'],program=True)
        factors=np.minimum(ds[:,None]*cat.flux[ids][None,:]*q[None,:]/cat.norm,1.)
        threshold=float(cat.score_config['required']['observed_factor_threshold'])
        required=(cat.required[ids]&(factor[ids]<threshold))[None,:] & (factors>=threshold)
        required=required*float(cat.score_config['required']['penalty_per_missing'])
        request_gain=np.zeros_like(factors);now=utc_datetime(state['now_utc'])
        for request in self._requests(state):
            unfinished=[i for i in request['indices'] if str(cat.ids[i]) not in request['completed']]
            time_left=float('inf') if not request['deadline'] else (utc_datetime(request['deadline'])-now).total_seconds()
            request_gain+=(np.isin(ids,unfinished)[None,:]&(factors>=request['threshold'])&(ds[:,None]<=time_left))*request['reward']/max(1,request['minimum']-len(request['completed']))
        bands=cat.score_config['program']['bands'];band=np.where(b>=bands['DARK'],'DARK',np.where(b>=bands['BRIGHT'],'BRIGHT','BACKUP'))
        priority=self._priority(ids,controls)[None,:];best=np.zeros(len(ds))
        # A program absent from every target's actual band gives no bonus to
        # anyone, and is dominated by any present band under positive weights.
        for program in np.unique(band):
            multiplier=cat.score_config['program']['multipliers'][str(program)]
            scores=cat.weight[ids][None,:]*factors*np.where(band==program,multiplier,cat.score_config['program']['mismatch_multiplier'])[None,:]
            gains=(controls['science_weight']*np.maximum(0,scores-score[ids][None,:])+controls['required_weight']*required+request_gain)*priority
            totals=np.zeros(len(ds))
            for cell in np.unique(cells):totals+=gains[:,cells==cell].max(axis=1)
            best=np.maximum(best,totals)
        ranked=np.argsort(-best/ds,kind='stable')
        # First retain high rate; include the strongest total-gain duration as a
        # two-step alternative if the rate leaders all favour tiny exposures.
        selected=list(map(int,ranked[:max(1,limit-1)]));total=int(np.argmax(best))
        if total not in selected:selected.append(total)
        for index in ranked:
            if len(selected)>=limit:break
            if int(index) not in selected:selected.append(int(index))
        return sorted(int(ds[i]) for i in selected)

    def _priority(self, ids, controls):
        cat = self.catalogue
        result = np.ones(len(ids))
        if controls['priority_targets']:
            result *= np.where(np.isin(cat.ids[ids], controls['priority_targets']), 2., 1.)
        for band, weight in controls['sector_weights'].items():
            result *= np.where((cat.ra[ids]//10).astype(int) == band, weight, 1.)
        if controls.get('focus_ra_deg') is not None:
            distance = abs((cat.ra[ids]-controls['focus_ra_deg']+180)%360-180)
            result *= 1 + .5*np.exp(-.5*(distance/15.)**2)
        return result

    def _duration_options(self, geometry, state, controls, maximum):
        cat = self.catalogue
        minimum = int(cat.fiber_config['exposure']['min_duration_seconds'])
        minimum = max(minimum, min(600, int(state.get('min_planning_duration', minimum))))
        maximum = int(min(maximum, cat.fiber_config['exposure']['max_duration_seconds']))
        if maximum < minimum:
            return []
        ids = geometry['indices']; q = self._quality(state, geometry['alt'],cat.ra[ids],cat.dec[ids],state['now_utc'])
        factor, score = self._progress(state)
        threshold = float(cat.score_config['required']['observed_factor_threshold'])
        missing = cat.required[ids] & (factor[ids] < threshold)
        request_levels={}
        deadlines=[]
        for request in self._requests(state):
            for target in request['indices']:
                if str(cat.ids[target]) not in request['completed']:
                    request_levels.setdefault(int(target),set()).add(request['threshold'])
            if request['deadline']:
                deadlines.append(int((utc_datetime(request['deadline'])-utc_datetime(state['now_utc'])).total_seconds()))
        # Include every required target's breakpoint; remaining targets are
        # chosen by expected scientific rate rather than catalogue order.
        rate = cat.flux[ids]*q/cat.norm
        desired = np.maximum(0, cat.weight[ids]-score[ids])*rate*self._priority(ids, controls)
        chosen = np.unique(np.r_[np.flatnonzero(missing),np.flatnonzero(np.isin(ids,list(request_levels))),np.argsort(-desired, kind='stable')[:16]])
        values = {minimum, maximum}
        values.update(d for d in (120,300,600,900,1800) if minimum <= d <= maximum)
        values.update(d for d in deadlines if minimum<=d<=maximum)
        # A usable interval ending before a threshold or before the nominal
        # maximum is a real exposure breakpoint too, not an automatic wait.
        now=utc_datetime(state['now_utc'])
        final_alt,_=self._horizontal(cat.ra[ids],cat.dec[ids],now+timedelta(seconds=maximum))
        setting=np.flatnonzero((geometry['alt']>=cat.minimum_altitude)&(final_alt<cat.minimum_altitude))
        if len(setting):
            lo=np.zeros(len(setting));hi=np.full(len(setting),float(maximum))
            for _ in range(12):
                mid=(lo+hi)/2
                # Different targets can set at different times; sidereal time
                # advances linearly so calculate vector hour angles directly.
                hour=np.deg2rad(local_sidereal_deg(now,cat.longitude)+360.98564736629*mid/86400-cat.ra[ids[setting]])
                dec=np.deg2rad(cat.dec[ids[setting]]);lat=np.deg2rad(cat.latitude)
                alt=np.rad2deg(np.arcsin(np.sin(lat)*np.sin(dec)+np.cos(lat)*np.cos(dec)*np.cos(hour)))
                visible=alt>=cat.minimum_altitude
                lo=np.where(visible,mid,lo);hi=np.where(visible,hi,mid)
            values.update(int(v) for v in np.floor(lo) if minimum<=v<=maximum)
        for i in chosen:
            if rate[i] <= 0:
                continue
            levels=set((threshold,1.) if missing[i] else (1.,))|request_levels.get(int(ids[i]),set())
            for level in levels:
                for margin in (1., controls['exposure_margin']):
                    value = int(math.ceil(math.nextafter(level/rate[i]*margin, -math.inf)))
                    if minimum <= value <= maximum:
                        values.add(value)
        # Keep all economically relevant threshold classes without exploding
        # into hundreds of durations in an unusually dense pointing.
        ordered = sorted(values)
        if len(ordered) > 32:
            keep = np.unique(np.r_[np.linspace(0,len(ordered)-1,28,dtype=int),
                                   [ordered.index(v) for v in (minimum,maximum)]])
            ordered = [ordered[i] for i in keep]
        return ordered

    def _evaluate(self, geometry, duration, state, controls, forced=None, program=None, build_features=True):
        cat = self.catalogue
        duration = int(duration)
        now = utc_datetime(state['now_utc']); end = utc_datetime(state['end_utc'])
        limits = cat.fiber_config['exposure']
        if not limits['min_duration_seconds'] <= duration <= limits['max_duration_seconds'] or now+timedelta(seconds=duration) > end:
            return None
        ids, cells = geometry['indices'], geometry['cells']
        finish = now+timedelta(seconds=duration)
        valid,quality,program_quality,alt_end=self._astronomy(geometry,duration,state)
        factors = np.clip(cat.flux[ids]*duration*quality/cat.norm, 0, 1)
        best_factor, best_score = self._progress(state)
        required_threshold = float(cat.score_config['required']['observed_factor_threshold'])
        required_gain = (cat.required[ids] & (best_factor[ids] < required_threshold) &
                         (factors >= required_threshold)) * float(cat.score_config['required']['penalty_per_missing'])
        request_hint = np.zeros(len(ids)); requests = self._requests(state)
        for request in requests:
            if request['deadline'] and finish > utc_datetime(request['deadline']):
                continue
            unfinished=np.asarray([i for i in request['indices'] if str(cat.ids[i]) not in request['completed']],dtype=int)
            if len(unfinished):
                request_hint += (np.isin(ids,unfinished)&(factors>=request['threshold']))*request['reward']/max(1,request['minimum']-len(request['completed']))
        bands = cat.score_config['program']['bands']; multipliers = cat.score_config['program']['multipliers']
        actual_band = np.where(program_quality >= bands['DARK'], 'DARK', np.where(program_quality >= bands['BRIGHT'], 'BRIGHT','BACKUP'))
        programs = [program] if program is not None else [str(p) for p in np.unique(actual_band)]
        priority=self._priority(ids,controls)
        best = None
        for chosen_program in programs:
            if chosen_program not in multipliers:
                raise ValueError('unknown observation program')
            multiplier = np.where(actual_band == chosen_program, float(multipliers[chosen_program]),
                                  float(cat.score_config['program']['mismatch_multiplier']))
            scores = cat.weight[ids]*factors*multiplier
            science_gain = np.maximum(0, scores-best_score[ids])
            raw_gain = science_gain+required_gain+request_hint
            search_gain = (controls['science_weight']*science_gain + controls['required_weight']*required_gain + request_hint)*priority
            if forced is None:
                options=np.flatnonzero(valid&(raw_gain>1e-12))
                order=np.lexsort((options,-search_gain[options],cells[options]))
                sorted_options=options[order]
                selected=sorted_options[np.r_[True,np.diff(cells[sorted_options])!=0]] if len(sorted_options) else np.asarray([],dtype=int)
            else:
                selected = []
                for cell, target in forced.items():
                    matching = np.flatnonzero((ids == cat.index.get(str(target), -1)) & (cells == int(cell)) & valid)
                    if len(matching) != 1:
                        return None
                    selected.append(int(matching[0]))
                selected = np.asarray(selected, dtype=int)
                if len(set(ids[selected])) != len(selected):
                    return None
            if not len(selected):
                continue
            chosen_ids = ids[selected]
            request_gain = 0.
            for request in requests:
                gained={str(cat.ids[i]) for i,f in zip(chosen_ids,factors[selected]) if i in request['indices'] and f>=request['threshold']}
                if (not request['deadline'] or finish<=utc_datetime(request['deadline'])) and len(request['completed']|gained)>=request['minimum']:
                    request_gain+=request['reward']
            science = float(science_gain[selected].sum()); required = float(required_gain[selected].sum())
            gain = science+required+request_gain
            if forced is None and gain <= 1e-12 and request_hint[selected].sum()<=0:
                continue
            search_total = float(search_gain[selected].sum())
            if best is not None and search_total <= best[0]:
                continue
            # Closing-window preference changes search order, not gain/labels.
            closing = np.clip((geometry['alt'][selected]-alt_end[selected])/np.maximum(geometry['alt'][selected]-cat.minimum_altitude, 1.), 0, 1)
            search_rate = search_total/duration*(1+.2*float(closing.mean()))
            candidate = dict(action=dict(action='observe',pointing=dict(alt_deg=geometry['pointing_alt'],az_deg=geometry['pointing_az']),
                                         assignments={str(int(cells[i])):str(cat.ids[ids[i]]) for i in selected},
                                         duration_seconds=duration,program=chosen_program),
                             est_gain=gain, rate=gain/duration, science_gain=science, required_gain=required,
                             request_gain=float(request_gain), search_priority=search_rate,
                             pointing_ra_deg=geometry['ra'],pointing_dec_deg=geometry['dec'],
                             target_indices=chosen_ids.copy(),factors=factors[selected].copy(),scores=scores[selected].copy(),
                             qualities=quality[selected].copy(),duration_seconds=duration,
                             program_qualities=program_quality[selected].copy(),
                             approximation=APPROXIMATION)
            if build_features:
                candidate['maps'], candidate['scalars'] = self._features(geometry, duration, state, best_factor, best_score,
                                                                        quality, science_gain, required_gain, request_hint, alt_end, candidate)
            best = search_total,candidate
        return None if best is None else best[1]

    def _features(self, geometry, duration, state, best_factor, best_score, quality, science_gain, required_gain, request_hint, alt_end, candidate):
        cat=self.catalogue; ids=geometry['indices']; cells=geometry['cells']; n=cat.side*cat.side
        count=np.bincount(cells,minlength=n); divisor=np.maximum(count,1)
        threshold=float(cat.score_config['required']['observed_factor_threshold'])
        unfinished=cat.required[ids] & (best_factor[ids]<threshold)
        remaining=np.maximum(0,cat.weight[ids]*max(cat.score_config['program']['multipliers'].values())-best_score[ids])
        closing=np.clip((geometry['alt']-alt_end)/np.maximum(geometry['alt']-cat.minimum_altitude,1.),0,1)
        def sums(values): return np.bincount(cells,weights=values,minlength=n)
        max_flux=np.zeros(n);np.maximum.at(max_flux,cells,np.log1p(cat.flux[ids]))
        uncertain=max(0.,float(state.get('quality_uncertainty',0.)))
        maps=np.asarray([np.log1p(count),np.log1p(sums(remaining)),np.log1p(sums(unfinished)),
                         np.log1p(sums(request_hint>0)),sums(np.log1p(cat.flux[ids]))/divisor,max_flux,
                         sums(quality)/divisor,np.where(count>0,uncertain,0),sums(closing)/divisor,
                         sums(best_factor[ids])/divisor,
                         np.log1p(sums(unfinished*cat.flux[ids]*quality/cat.norm/threshold)),
                         np.log1p(sums(science_gain))],dtype=np.float32).reshape(12,cat.side,cat.side)
        now=utc_datetime(state['now_utc']);end=utc_datetime(state['end_utc'])
        ra=math.radians(geometry['ra'])
        scalars=np.asarray([duration/3600,float(np.mean(candidate['qualities'])),uncertain,
                            np.count_nonzero(cat.required & (best_factor<threshold))/max(1,np.count_nonzero(cat.required)),
                            max(0,(end-now).total_seconds())/32400,float(state.get('remaining_nights',1))/38,
                            geometry['pointing_alt']/90,math.sin(ra),math.cos(ra),geometry['dec']/90,
                            candidate['science_gain']/n,candidate['required_gain']/max(1,float(cat.score_config['required']['penalty_per_missing']))/n],dtype=np.float32)
        return maps,scalars

    def propose(self, state, controls=None, max_candidates=64):
        self._clear_cache()
        state=dict(state);state['_planner_progress_arrays']=self._progress(state)
        cat=self.catalogue;c=self._controls(controls);now=utc_datetime(state['now_utc'])
        max_candidates=min(int(max_candidates),int(c['candidate_budget']))
        remaining=(utc_datetime(state['end_utc'])-now).total_seconds()
        if remaining < cat.fiber_config['exposure']['min_duration_seconds'] or max_candidates < 1:
            return []
        factor,score=self._progress(state)
        alt,az=self._horizontal(cat.ra,cat.dec,now)
        visible=np.flatnonzero(alt>=cat.minimum_altitude+.05)
        if not len(visible): return []
        q=self._quality(state,alt[visible],cat.ra[visible],cat.dec[visible],now);rate=cat.flux[visible]*q/cat.norm
        threshold=float(cat.score_config['required']['observed_factor_threshold'])
        need=cat.required[visible] & (factor[visible]<threshold)
        feasible=rate*min(remaining,cat.fiber_config['exposure']['max_duration_seconds'])>=threshold
        potential=np.maximum(0,cat.weight[visible]*max(cat.score_config['program']['multipliers'].values())-score[visible])
        urgency=1+.5/max(1.,float(state.get('remaining_nights',1)))
        hint=(c['science_weight']*potential*rate + c['required_weight']*need*feasible*urgency*float(cat.score_config['required']['penalty_per_missing'])*np.minimum(rate/threshold,1/60))*self._priority(visible,c)
        request_origins=[]
        visible_position={int(target):i for i,target in enumerate(visible)}
        for request in self._requests(state):
            available=remaining if not request['deadline'] else min(remaining,(utc_datetime(request['deadline'])-now).total_seconds())
            for target in request['indices']:
                position=visible_position.get(int(target))
                if position is not None and str(cat.ids[target]) not in request['completed'] and rate[position]*min(available,3600)>=request['threshold']:
                    hint[position]+=request['reward']*rate[position]/request['threshold']/max(1,request['minimum']-len(request['completed']))
                    request_origins.append(int(target))
        # Candidate origins include easy-to-finish required objects, closing
        # required windows, science-rate leaders and explicit agent priorities.
        alt_later,_=self._horizontal(cat.ra[visible],cat.dec[visible],now+timedelta(seconds=min(1800,remaining)))
        closing=need & feasible & (alt_later<cat.minimum_altitude+2)
        priority_ids=[cat.index[t] for t in c['priority_targets'] if alt[cat.index[t]]>=cat.minimum_altitude]
        order=np.argsort(-hint,kind='stable')
        npoint=min(24,max(1,int(max_candidates)//4))
        origins=priority_ids + request_origins[:max(2,npoint//3)] + list(visible[np.argsort(-np.where(closing,hint,0),kind='stable')[:max(1,npoint//4)]])
        origins+=list(visible[np.argsort(-np.where(need & feasible,hint,0),kind='stable')[:max(2,npoint//3)]])
        origins+=list(visible[order[:min(len(order),int(c['candidate_budget'])*4)]])
        pointings=[]
        for target in origins:
            # An anchor exactly at the field centre lies on four cell edges.
            # Shift by half a cell so it lies safely inside an assignable cell.
            centre_alt,centre_az=offset_horizontal(float(alt[target]),float(az[target]),cat.cell_width*.5,cat.cell_width*.5)
            ra,dec=horizontal_to_equatorial(centre_alt,centre_az,now,cat.latitude,cat.longitude)
            ra,dec=float(ra),float(dec)
            # Preserve distinct fibre alignments while avoiding repeated tiny
            # jitter of the same field; RA distance wraps around zero.
            if any(abs((ra-r+180)%360-180)*max(.1,math.cos(math.radians(dec)))<cat.cell_width*.55 and abs(dec-d)<cat.cell_width*.55 for r,d in pointings):
                continue
            pointings.append((ra,dec))
            if len(pointings)>=npoint: break
        all_candidates=[]; per_point=[]
        for ra,dec in pointings:
            geometry=self._geometry(ra,dec,state,(alt,az))
            if geometry is None: continue
            options=[]
            durations=self._duration_options(geometry,state,c,remaining)
            durations=self._select_durations(geometry,durations,state,c,self.planning_budget['proposal_durations'])
            for duration in durations:
                result=self._evaluate(geometry,duration,state,c,build_features=False)
                if result is not None: options.append(result)
            options.sort(key=lambda x:(-x['search_priority'],-x['est_gain'],x['duration_seconds']))
            if options: per_point.append(options[0])
            all_candidates.extend(options)
        # Keep a best duration for each pointing, then fill with alternatives.
        ranked=sorted(all_candidates,key=lambda x:(-x['search_priority'],-x['est_gain'],x['duration_seconds']))
        selected=[];seen=set()
        for candidate in sorted(per_point,key=lambda x:-x['search_priority'])+ranked:
            key=(candidate['pointing_ra_deg'],candidate['pointing_dec_deg'],candidate['duration_seconds'],candidate['action']['program'])
            if key not in seen:
                selected.append(candidate);seen.add(key)
            if len(selected)>=int(max_candidates):break
        result=[]
        for candidate in selected:
            geometry=self._geometry(candidate['pointing_ra_deg'],candidate['pointing_dec_deg'],state,(alt,az))
            item=self._evaluate(geometry,candidate['duration_seconds'],state,c,forced=candidate['action']['assignments'],program=candidate['action']['program'])
            if item is not None:result.append(item)
        return sorted(result,key=lambda x:(-x['search_priority'],-x['est_gain']))

    def evaluate_action(self, action, state):
        """Recompute a fixed observe action using supplied public/proxy quality.

        Useful for an explicitly synthetic proxy environment. Never validates an
        action against the official simulator. Returns None for invalid geometry.
        """
        if action.get('action')!='observe':return None
        p=action['pointing'];cat=self.catalogue
        ra,dec=horizontal_to_equatorial(p['alt_deg'],p['az_deg'],state['now_utc'],cat.latitude,cat.longitude)
        geometry=self._geometry(float(ra),float(dec),state,pointing=p)
        if geometry is None:return None
        return self._evaluate(geometry,int(action['duration_seconds']),state,self._controls({}),
                              forced=action['assignments'],program=action['program'])

    def apply_candidate(self, state, candidate):
        """Pure proxy state update: maxima, never cumulative exposure factors."""
        result=dict(state);result['best_factor']=dict(state.get('best_factor',{}));result['best_score']=dict(state.get('best_score',{}))
        result.pop('_planner_progress_arrays',None)
        for i,f,s in zip(candidate['target_indices'],candidate['factors'],candidate['scores']):
            tid=str(self.catalogue.ids[int(i)])
            result['best_factor'][tid]=max(float(result['best_factor'].get(tid,0.)),float(f))
            result['best_score'][tid]=max(float(result['best_score'].get(tid,0.)),float(s))
        result['now_utc']=iso_utc(utc_datetime(state['now_utc'])+timedelta(seconds=candidate['duration_seconds']))
        result['active_requests']=[]
        for original in state.get('active_requests',[]):
            request=dict(original);completed=set(map(str,request.get('completed_target_ids',[])))
            start=request.get('issued_at_utc');deadline=request.get('deadline_utc',request.get('expires_utc'))
            if (not start or utc_datetime(state['now_utc'])>=utc_datetime(start)) and (not deadline or utc_datetime(result['now_utc'])<=utc_datetime(deadline)):
                members=set(map(str,request.get('target_ids',[request['target_id']] if 'target_id' in request else [])))
                threshold=float(request.get('completion_factor_threshold',.5))
                completed|={str(self.catalogue.ids[int(i)]) for i,f in zip(candidate['target_indices'],candidate['factors']) if str(self.catalogue.ids[int(i)]) in members and f>=threshold}
            request['completed_target_ids']=sorted(completed);request['completed_count']=len(completed)
            result['active_requests'].append(request)
        return result

    def teacher_targets(self, candidates, state, controls=None, indices=None):
        """Same-budget, at-most-two-observation public-model marginal gain rate.

        Every first candidate gets the same time budget (up to two hours).
        Unused time receives an approximate science opportunity value from
        candidates excluding both steps' target ids (never repeated required
        rewards). This is not a rollout or an attainable terminal-score bound.
        The second candidate is reallocated
        after maxima update and reprojected at its future astronomical time;
        weather quality remains the supplied estimate. This is a short-horizon
        approximation, not an official reward label or an exhaustive optimum.
        """
        c=self._controls(controls);cat=self.catalogue
        budget=max(1.,min(7200.,(utc_datetime(state['end_utc'])-utc_datetime(state['now_utc'])).total_seconds()))
        shortlist=[];seen=set()
        # Keep request-progress/agent-directed alternatives eligible even when
        # the immediate all-or-nothing request reward is still zero.
        for candidate in sorted(candidates,key=lambda x:-x['search_priority']):
            key=(candidate['pointing_ra_deg'],candidate['pointing_dec_deg'])
            if key not in seen:shortlist.append(candidate);seen.add(key)
            if len(shortlist)>=self.planning_budget['successor_pointings']:break
        # Vectorized sparse candidate pool for a shared opportunity estimate.
        # Exclusion is stricter than maxima update: no selected target can
        # generate tail reward, even if a later improvement might be possible.
        old_factor,old_scores=self._progress(state)
        pool_ids=np.concatenate([np.asarray(x['target_indices'],dtype=int) for x in candidates]) if candidates else np.asarray([],dtype=int)
        pool_groups=np.concatenate([np.full(len(x['target_indices']),i,dtype=int) for i,x in enumerate(candidates)]) if candidates else np.asarray([],dtype=int)
        pool_gains=np.concatenate([np.maximum(0,np.asarray(x['scores'])-old_scores[x['target_indices']]) for x in candidates]) if candidates else np.asarray([])
        pool_durations=np.asarray([x['duration_seconds'] for x in candidates],dtype=float)
        pool_unique_gain=np.zeros(len(cat.ids));np.maximum.at(pool_unique_gain,pool_ids,pool_gains)
        pool_capacity=float(pool_unique_gain.sum())
        def opportunity(excluded):
            if not len(pool_ids):return 0.,0.
            excluded=np.asarray(list(excluded),dtype=int)
            available=~np.isin(pool_ids,excluded)
            gains=np.bincount(pool_groups,weights=pool_gains*available,minlength=len(candidates))
            return float(np.max(gains/pool_durations)),max(0.,pool_capacity-float(pool_unique_gain[excluded].sum()))
        labels=[];details=[]
        first_indices=list(range(len(candidates))) if indices is None else [int(i) for i in indices]
        if any(i<0 or i>=len(candidates) for i in first_indices):raise ValueError('teacher candidate index outside pool')
        for first_index in first_indices:
            first=candidates[first_index]
            if first['duration_seconds']>budget:
                labels.append(0.);details.append(dict(total_gain=0.,budget_seconds=budget,invalid=True));continue
            after=self.apply_candidate(state,first);left=budget-first['duration_seconds'];second=None
            next_factor=old_factor.copy();next_score=old_scores.copy();first_targets=first['target_indices']
            next_factor[first_targets]=np.maximum(next_factor[first_targets],first['factors'])
            next_score[first_targets]=np.maximum(next_score[first_targets],first['scores'])
            after['_planner_progress_arrays']=(next_factor,next_score)
            first_ids=set(map(int,first['target_indices']))
            tail_rate,tail_capacity=opportunity(first_ids)
            best_continuation=min(left*tail_rate,tail_capacity)
            if c['horizon']>=2 and left>=cat.fiber_config['exposure']['min_duration_seconds']:
                # Identical shortlist/budget for all first actions. Re-evaluate
                # duration thresholds as progress and geometry have changed.
                for proposal in shortlist:
                    geometry=self._geometry(proposal['pointing_ra_deg'],proposal['pointing_dec_deg'],after)
                    if geometry is None:continue
                    durations=self._duration_options(geometry,after,c,left)
                    durations=self._select_durations(geometry,durations,after,c,self.planning_budget['successor_durations'])
                    for duration in durations:
                        evaluated=self._evaluate(geometry,duration,after,c,build_features=False)
                        if evaluated is not None:
                            remaining_rate,remaining_capacity=opportunity(first_ids|set(map(int,evaluated['target_indices'])))
                            value=evaluated['est_gain']+min((left-duration)*remaining_rate,remaining_capacity)
                            if value>best_continuation:
                                second=evaluated;best_continuation=value;tail_rate=remaining_rate;tail_capacity=remaining_capacity
            total=first['est_gain']+(second['est_gain'] if second is not None else 0.)
            unused=budget-first['duration_seconds']-(second['duration_seconds'] if second is not None else 0)
            tail_value=min(unused*tail_rate,tail_capacity) if c['horizon']>=2 else 0.
            labels.append((total+tail_value)/budget)
            details.append(dict(total_gain=float(total),budget_seconds=budget,first_gain=first['est_gain'],
                                second_gain=second['est_gain'] if second is not None else 0.,
                                second_action=second['action'] if second is not None else None,
                                unused_seconds=unused,opportunity_science_rate=tail_rate,
                                opportunity_science_value=tail_value,opportunity_science_capacity=tail_capacity,
                                planning_budget=dict(self.planning_budget),
                                label_definition='two-step gain plus deduplicated science opportunity value, divided by shared time budget; not terminal score'))
        self.last_teacher_details=details
        return np.asarray(labels,dtype=np.float32)
