# Current v4 development experiment

This implementation uses the current alpha/beta/gamma/delta public catalogues,
38-night calendars and 16-fibre configuration. It does not reuse the old a/b/c/d
training cards. All server artifacts remain below `/home/jovyan/huangzy183`.

## Decisions behind this experiment

1. A missed required target costs 50 points; a required target's single-exposure
   factor must reach 0.5. Required exposure feasibility and closing windows are
   more useful planning signals than increasing an arbitrary science weight.
   Targets too faint to reach the threshold in current conditions should share
   favourable windows, rather than repeatedly consume an ineffective hour.
2. Every target retains its best score and its best completion factor separately.
   They can come from different exposures. Live feedback exposes only scores;
   the policy maintains conservative factor bounds and observation history.
   A data-loss notice invalidates an interval of observe indices and triggers
   reconstruction, rather than merging obsolete completion states.
3. Numerical tools handle documented horizontal gnomonic geometry, fibre
   assignment, exposure thresholds, program choice and bounded joint replanning.
   The public formulas distinguish exposure quality Q from program quality B.
4. Qwen27B participates through an API in two stages: interpreting bulletins and
   observed outcomes, then choosing target groups, RA regions and search controls.
   Its actual prompts, responses, rejected proposals and revisions are saved.
   A changed explanation is not counted as a changed plan.
5. The 12-channel 4x4 local fibre map and 12 public-state scalars train a small
   candidate ranker. Candidate labels are finite two-step search values with
   an approximate remaining-time science opportunity value, not static density
   or final competition scores. CNN and heuristic candidates share a small
   numerical verification budget. Torch training exports NumPy-only inference.

## What is and is not measured

The development environment generates its own time-indexed weather, requests,
instrument faults and data-loss events. Policies only receive messages with
the published v4 shape; no true completion factors, numerical hidden weather or
future events are passed to them. Weather draws are paired across policies.
Directional closures and hidden pointing offsets are not yet simulated.
The geometry/scoring implementation follows public documentation but has not
been compared with the official implementation. Every resulting score is
explicitly a **development proxy score**, not an official practice score.

The training seed is 17. Collection runs one complete season per current card,
using cheap greedy actions between densely labelled planning states. Online
evaluation uses up to 32 proposals and eight first-action lookahead evaluations;
collection labels up to 48 alternatives at selected states. Runtime pressure
reduces the live pool to 16 and switches to immediate-value selection. Measured
decision cost and remaining season/wall time adapt the minimum planned exposure
granularity between 60 and 600 seconds; collection uses a fixed 180-second floor.
This avoids exhausting the runtime on many minute-long, low-value revisits.
Entire nights 0–23 train, 24–30 validate and 31–37 test. All cards are known at
training time; this is not evidence of unseen-catalogue generalization. The
checkpoint is selected on validation shortlist regret. Test prediction happens
once after checkpoint selection. Subsequent closed-loop policy runs use another
synthetic weather realization, with an identical realization for all policies.

Greedy, bounded search, search plus hybrid learned proposals, and API Agent plus
hybrid search are evaluated. LLM-directed replanning or waiting can use extra
proposal work; that work and API latency are included in wall time and recorded.
This is a competition development comparison, not a strict equal-total-compute
causal ablation. Runtime expiry is reported, never silently treated as a full
season result. No score improvement is assumed in advance.

## Running and artifacts

`queue.py` performs tests, a one-night timing pilot, collection, one-seed GPU
training, paired policy evaluation, Qwen API evaluation and packaging. It
selects idle GPUs and terminates only its own children. New runs use immutable
source/data snapshots with SHA256 manifests. Failures produce `failed.json`
and update `RESULTS.md`.

The server run's `RESULTS.md` includes scores, remaining required targets,
timings, actual model participation and output locations. Every episode has
`trajectory.csv`, `actions.jsonl`, and `result.json`. Agent runs additionally
have `api_trace.jsonl`. These CSV files are diagnostics, not v3 submissions.

`live_agent.py` uses the real JSONL-v4 protocol and the catalogue delivered in
initialize. The eventual `participant-agent.zip` includes source and NumPy
weights, but no catalogue, training data, credentials or local model weights.
It remains pending official cloud validation. The server experiment's Qwen API
is authenticated and loopback-only; it is not a platform-reachable HTTPS service.
