"""Event-driven public-information agents with executable group/tool choices.

The LLM chooses a search tool and references numerical candidate groups by ID.
Selected groups enter the expensive search shortlist, so a sound but lower-rate
model proposal is not silently discarded by the original top-rate gate. Values
and action legality are always calculated by the numerical planner.
"""
from datetime import timedelta
import hashlib
import json
import math

import numpy as np

from .agent import GroupAgent, DEFAULT_CONTROLS, validate_controls
from .planner import equatorial_to_horizontal, utc_datetime


TOOLS = {
    'fast_science': dict(science_weight=1.6, required_weight=.75,
                         candidate_budget=24, horizon=1, exposure_margin=1.1),
    'joint_search': dict(science_weight=1., required_weight=1.,
                         candidate_budget=48, horizon=2, exposure_margin=1.2),
    'secure_completion': dict(science_weight=.8, required_weight=1.8,
                              candidate_budget=48, horizon=2, exposure_margin=1.35),
}
CONDITIONS = ('good', 'uncertain', 'poor', 'possible_fault', 'possible_pointing_error')
PRIORITIES = ('required_windows', 'science_windows', 'requests', 'recover_state')
AGENT_VARIANTS = ('baseline', 'event_director', 'counterfactual_director', 'compact_skill_director')

SURVEY_SKILL = (
    'Maximize final points under a real wall-clock budget. Only the best single-exposure score '
    'survives for each target; short exposures do not accumulate. Completion uses an unbonused '
    'factor, not the program-multiplied score. Missing required penalties are given in '
    'rules.missing_penalty; prefer reachable thresholds and closing windows. Science gain '
    'means improvement over surviving best score. A request pays only after its minimum count '
    'is reached by complete exposures inside its public time window; failure is not penalized. '
    'Score-derived quality is uncertain. Q and program B are different; instrument faults affect '
    'Q but not B. Low score alone does not establish a fault; low hit fraction may instead mean '
    'pointing or geometry. A directional notice has uncertain boundaries, never an exact mask. '
    'Data-loss resync invalidates affected history. Do not hallucinate future requests or weather. '
    'Choose an actionable group, tool, and concise reason from this public context. '
)


def _compact_message(message):
    """Explicit allowlist: never serialize giant resync tables or unknown fields."""
    if not isinstance(message, dict):
        return {}
    keys = ('record_type', 'event_kind', 'direction', 'issued_at_utc', 'deadline_utc',
            'coverage_start_utc', 'coverage_end_utc',
            'night_id', 'request_id', 'trigger_event_id', 'invalidated_window',
            'status', 'correct', 'repaired', 'reward', 'penalty', 'initial')
    result = {key: message[key] for key in keys if key in message}
    if 'notices' in message:
        result['notices'] = [
            {k: n[k] for k in ('event_kind', 'direction', 'nights', 'affected_nights', 'night_ids') if k in n}
            for n in message.get('notices', [])[:12] if isinstance(n, dict)]
    return result


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:16]


def _finite_round(value, digits=3):
    value = float(value)
    return round(value, digits) if math.isfinite(value) else None


class EventGroupAgent(GroupAgent):
    variant = 'event_director'

    def __init__(self, catalogue, trace_path, client=None, max_calls=8):
        super().__init__(catalogue, trace_path, client=client, max_calls=max_calls)
        self._last_call_night = -100
        self._last_call_observation = -100
        self._last_notice = None
        self._last_request_ids = set()
        self._seen_resync = set()
        self._seen_forecasts = set()
        self._persistent_notices = []
        self._poor_feedback_seen = False
        self._night_calls = {}
        self._selected_targets = []
        self._selected_groups = []
        self._selected_target_groups = []
        self._group_menu = {}
        self._events = {}
        self._shortlist_forced = 0
        self._tool_choices = {}
        self._last_context_chars = 0
        initial_calls = 1 if self.variant == 'compact_skill_director' else 2
        self._emergency_capacity = min(4, max(0, max_calls-initial_calls))
        self._ordinary_capacity = max_calls-self._emergency_capacity
        self._ordinary_calls = self._emergency_calls = 0
        self._event_ordinary_remaining = self._event_emergency_remaining = None
        self._budget_deferrals = 0

    def _available_call_budget(self, state, trigger, needed):
        """Release routine calls through the season; protect a resync reserve.

        A new request can borrow the unprotected emergency half. At least two
        calls remain exclusively for a real state_resync, even after repeated
        early requests/notices. Small total budgets still allow the first plan.
        """
        night = max(0, int(state['night_index']))
        total = max(1, night+int(state.get('remaining_nights', 1)))
        released = min(self._ordinary_capacity, max(needed+1,
            int(math.ceil(self._ordinary_capacity*min(1., (night+1)/total)))))
        ordinary = max(0, released-self._ordinary_calls)
        reserve = max(0, self._emergency_capacity-self._emergency_calls)
        if trigger == 'state_resync':
            emergency = reserve
        elif trigger == 'new_request':
            emergency = max(0, reserve-min(2, self._emergency_capacity))
        else:
            emergency = 0
        return ordinary, emergency

    def _call(self, stage, system, context):
        # Every attempted call, including a failed diagnostic or JSON repair,
        # consumes its event allocation. Repairs never raid a protected reserve.
        ordinary = self._event_ordinary_remaining
        emergency = self._event_emergency_remaining
        if ordinary is not None and ordinary + emergency <= 0:
            return None
        before = self.calls
        result = super()._call(stage, system, context)
        consumed = self.calls-before
        if consumed and ordinary is not None:
            normal = min(ordinary, consumed)
            urgent = consumed-normal
            self._ordinary_calls += normal
            self._emergency_calls += urgent
            self._event_ordinary_remaining -= normal
            self._event_emergency_remaining -= urgent
        return result

    def observe_feedback(self, before_state, candidate, result):
        super().observe_feedback(before_state, candidate, result)
        if result.get('action') != 'observe' or not self.feedback:
            return
        row = self.feedback[-1]
        prior = before_state.get('best_score', {})
        row['marginal_science'] = _finite_round(sum(max(0., float(h['score']) -
            float(prior.get(str(h.get('target_id')), 0.))) for h in result.get('hits', [])))
        row['hit_fraction'] = _finite_round(row['hit_count'] / max(1, row['assigned_count']))
        expected = row['expected_science']
        row['measured_to_predicted'] = _finite_round(row['measured_exposure_science'] / expected) if expected > 1e-9 else None

    def _trigger(self, state):
        night = int(state['night_index'])
        observation = int(state.get('observe_action_index') or 0)
        if self.calls == 0:
            return 'initial_plan'
        # Replans spend real API time. Bound repeated bad-weather events while
        # allowing an immediate new resync/request to reach the model.
        messages = state.get('new_messages', [])
        for message in messages:
            if message.get('record_type') == 'state_resync':
                key = _fingerprint(_compact_message(message))
                if key not in self._seen_resync:
                    return 'state_resync'
            if message.get('record_type') == 'forecast' and message.get('notices'):
                if _fingerprint(_compact_message(message)) not in self._seen_forecasts:
                    return 'new_event_forecast'
        requests = {str(x.get('request_id')) for x in state.get('active_requests', [])}
        if requests - self._last_request_ids:
            return 'new_request'
        if observation - self._last_call_observation < 3 or self._night_calls.get(night, 0) >= 2:
            return None
        notice = _fingerprint(_compact_message(state.get('latest_bulletin') or {}).get('notices', []))
        if notice != self._last_notice and (state.get('latest_bulletin') or {}).get('notices'):
            return 'changed_directional_or_weather_notice'
        recent = self.feedback[-3:]
        poor = len(recent) == 3 and all(
            (x.get('hit_fraction', 1.) < .75 or
             (x.get('measured_to_predicted') is not None and x['measured_to_predicted'] < .45))
            for x in recent)
        if poor and not self._poor_feedback_seen:
            return 'persistent_execution_discrepancy'
        if not poor:
            self._poor_feedback_seen = False
        if night - self._last_call_night >= 5:
            return 'season_progress'
        return None

    def _mark_trigger(self, state, trigger):
        night = int(state['night_index'])
        self._last_call_night = night
        self._last_call_observation = int(state.get('observe_action_index') or 0)
        self._night_calls[night] = self._night_calls.get(night, 0) + 1
        self._last_request_ids = {str(x.get('request_id')) for x in state.get('active_requests', [])}
        self._last_notice = _fingerprint(_compact_message(state.get('latest_bulletin') or {}).get('notices', []))
        self._seen_resync.update(_fingerprint(_compact_message(m)) for m in state.get('new_messages', [])
                                if m.get('record_type') == 'state_resync')
        self._seen_forecasts.update(_fingerprint(_compact_message(m)) for m in state.get('new_messages', [])
                                   if m.get('record_type') == 'forecast')
        if trigger == 'persistent_execution_discrepancy':
            self._poor_feedback_seen = True
        self._events[trigger] = self._events.get(trigger, 0) + 1

    def _sky_table(self, state):
        """All occupied RA bands, rather than only bands in the proposal top-k."""
        cat = self.cat
        now = utc_datetime(state['now_utc'])
        site = cat.scenario['site']
        alt, _ = equatorial_to_horizontal(cat.ra, cat.dec, now, site['latitude_deg'], site['longitude_deg'])
        later, _ = equatorial_to_horizontal(cat.ra, cat.dec, now + timedelta(seconds=1800),
                                          site['latitude_deg'], site['longitude_deg'])
        minimum = cat.scenario.get('minimum_altitude_deg', 30.)
        visible = alt >= minimum
        closing = visible & (later < minimum + 2.)
        factors = np.asarray([state.get('best_factor', {}).get(str(t), 0.) for t in cat.ids])
        scores = np.asarray([state.get('best_score', {}).get(str(t), 0.) for t in cat.ids])
        unfinished = cat.required & (factors < cat.score_config['required']['observed_factor_threshold'])
        remaining = np.maximum(0., cat.weight * max(cat.score_config['program']['multipliers'].values()) - scores)
        bands = np.floor(cat.ra / 10).astype(int)
        rows = []
        for band in np.unique(bands):
            where = bands == band
            rows.append([int(band), int(np.sum(unfinished & where)),
                         int(np.sum(unfinished & where & visible)),
                         int(np.sum(unfinished & where & closing)),
                         _finite_round(np.sum(remaining[where & visible]), 1)])
        return dict(columns=['RA10', 'required_left', 'visible_required', 'closing30m_required',
                             'visible_science_upper_bound'], rows=rows,
                    uncertainty='Completion lower bounds; science upper bounds ignore weather. Not hidden truth.')

    def _groups(self, state, candidates):
        # Deliberately retain science/required/request specialists and at least
        # one non-leading sky region, rather than duplicate top-rate exposures.
        rankings = [sorted(range(len(candidates)), key=lambda i: -float(candidates[i].get(field, 0.)))
                    for field in ('request_gain', 'required_gain', 'science_gain', 'rate')]
        # Start with one specialist per objective, then distinct assignment
        # groups. Otherwise four duration variants can consume the whole menu.
        leaders = [ranking[0] for ranking in rankings if ranking]
        order = list(leaders)
        seen_targets = {tuple(sorted(candidates[i]['action']['assignments'].values())) for i in leaders}
        for i in rankings[-1] if rankings else []:
            signature = tuple(sorted(candidates[i]['action']['assignments'].values()))
            if signature not in seen_targets:
                order.append(i); seen_targets.add(signature)
        for round_index in range(max((len(x) for x in rankings), default=0)):
            for ranking in rankings:
                if round_index < len(ranking):
                    order.append(ranking[round_index])
        selected, signatures = [], set()
        for index in order:
            item = candidates[index]
            signature = (tuple(sorted(item['action']['assignments'].values())),
                         int(item['action']['duration_seconds']) // 300)
            if signature not in signatures:
                selected.append(item); signatures.add(signature)
            if len(selected) == 8:
                break
        self._group_menu = {}
        rows = []
        for index, item in enumerate(selected):
            gid = 'G' + str(index)
            self._group_menu[gid] = item
            ids = list(item['action']['assignments'].values())
            rows.append(dict(id=gid, RA=_finite_round(item['pointing_ra_deg'], 1),
                Dec=_finite_round(item['pointing_dec_deg'], 1),
                alt=_finite_round(item['action']['pointing']['alt_deg'], 1),
                az=_finite_round(item['action']['pointing']['az_deg'], 1),
                seconds=item['action']['duration_seconds'], n=len(ids), examples=ids[:3],
                science=_finite_round(item.get('science_gain', 0.)),
                required=_finite_round(item.get('required_gain', 0.)),
                request=_finite_round(item.get('request_gain', 0.)),
                gain_per_second=_finite_round(item['rate'], 5)))
        return rows

    def _context(self, state, candidates, trigger):
        requests = []
        for row in sorted(state.get('active_requests', []), key=lambda x: x.get('deadline_utc', ''))[:6]:
            completed = set(row.get('completed_target_ids', []))
            requests.append(dict(id=row.get('request_id'), deadline=row.get('deadline_utc'),
                reward=row.get('completion_reward'), need=max(0, int(row.get('minimum_completed', 1)) - len(completed)),
                unfinished_targets=[str(t) for t in row.get('target_ids', []) if t not in completed][:12]))
        context = dict(trigger=trigger, time=state['now_utc'], night=state['night_index'],
            nights_left=state['remaining_nights'], end_of_night=state['end_utc'],
            required_left=state.get('required_missing'), quality_estimate=state.get('quality_estimate'),
            quality_uncertainty=state.get('quality_uncertainty'),
            wallclock={k: v for k, v in (state.get('wallclock') or {}).items()
                       if k in ('elapsed_seconds', 'remaining_seconds', 'global_wallclock_seconds')},
            API_calls_left=self.max_calls-self.calls,
            new_messages=[_compact_message(m) for m in state.get('new_messages', [])[-5:]],
            bulletin=_compact_message(state.get('latest_bulletin') or {}),
            forecast=_compact_message(state.get('latest_forecast') or {}),
            persistent_initial_notices=self._persistent_notices,
            requests=requests, feedback=self.feedback[-3:],
            whole_sky=self._sky_table(state), groups=self._groups(state, candidates),
            tools=TOOLS, previous_controls=self.controls,
            rules=dict(required_threshold=self.cat.score_config['required']['observed_factor_threshold'],
                missing_penalty=self.cat.score_config['required']['penalty_per_missing'],
                maximum_exposure=self.cat.fiber_config['exposure']['max_duration_seconds'],
                estimates_are_not_truth=True))
        # Bound serialized context independently of catalogue/notice size. The
        # normal context is ~5-7k ASCII chars, comfortably below 6k tokens.
        encoded = json.dumps(context, ensure_ascii=False, separators=(',', ':'))
        if len(encoded) > 11000:
            context['feedback'] = self.feedback[-1:]
            context['requests'] = requests[:3]
            context['new_messages'] = context['new_messages'][-2:]
        self._last_context_chars = len(json.dumps(context, ensure_ascii=False, separators=(',', ':')))
        return context

    @staticmethod
    def _diagnosis(value):
        if not isinstance(value, dict) or value.get('condition') not in CONDITIONS or value.get('priority') not in PRIORITIES:
            raise ValueError('condition and priority must use their documented enums')
        return {key: value[key] for key in ('condition', 'priority')}

    def _decode(self, proposal, state):
        if not isinstance(proposal, dict):
            raise ValueError('Return a JSON object')
        allowed = {'condition', 'priority', 'tool', 'groups', 'exposure_margin', 'wait_seconds', 'ra_band', 'reason'}
        if set(proposal) - allowed:
            raise ValueError('Unknown fields: ' + ','.join(sorted(set(proposal) - allowed)))
        diagnosis = self._diagnosis(proposal)
        tool = proposal.get('tool')
        if tool not in TOOLS:
            raise ValueError('tool must be one of ' + ','.join(TOOLS))
        groups = proposal.get('groups')
        if not isinstance(groups, list) or len(groups) > 2 or not groups or any(not isinstance(g, str) or g not in self._group_menu for g in groups) or len(set(groups)) != len(groups):
            raise ValueError('groups must name 1 or 2 distinct available G identifiers')
        controls = dict(TOOLS[tool])
        priorities = []
        active = {str(t) for r in state.get('active_requests', []) for t in r.get('target_ids', [])
                  if t not in set(r.get('completed_target_ids', []))}
        # Interleave groups so both model choices reach the proposal origins.
        targets = []
        for group in groups:
            ids = list(self._group_menu[group]['action']['assignments'].values())
            ids.sort(key=lambda t: (t not in active, not bool(self.cat.required[self.cat.index[t]])))
            targets.append(ids)
        for position in range(max(map(len, targets), default=0)):
            for ids in targets:
                if position < len(ids) and ids[position] not in priorities:
                    priorities.append(ids[position])
        # A model may redirect search to an occupied whole-sky band that the
        # current numeric menu omitted. Public geometry supplies real anchors.
        if 'ra_band' in proposal:
            band = proposal['ra_band']
            occupied = np.floor(self.cat.ra / 10).astype(int)
            if type(band) is not int or not 0 <= band < 36 or not np.any(occupied == band):
                raise ValueError('ra_band must be an occupied whole_sky RA10 integer')
            site = self.cat.scenario['site']
            alt, _ = equatorial_to_horizontal(self.cat.ra, self.cat.dec, state['now_utc'],
                                             site['latitude_deg'], site['longitude_deg'])
            available = np.flatnonzero((occupied == band) & (alt >= self.cat.scenario.get('minimum_altitude_deg', 30.)))
            threshold = self.cat.score_config['required']['observed_factor_threshold']
            def value(i):
                tid = str(self.cat.ids[i])
                missing = bool(self.cat.required[i]) and state.get('best_factor', {}).get(tid, 0.) < threshold
                science = max(0., float(self.cat.weight[i]) - state.get('best_score', {}).get(tid, 0.))
                return (not missing, -science, tid)
            anchors = [str(self.cat.ids[i]) for i in sorted(available, key=value)[:4]]
            priorities = list(dict.fromkeys(anchors + priorities))
            controls['focus_ra_deg'] = band * 10. + 5.
        controls['priority_targets'] = priorities[:8]
        sectors = {str(int(self._group_menu[g]['pointing_ra_deg']) // 10): 1.7 for g in groups}
        if 'ra_band' in proposal:
            sectors[str(proposal['ra_band'])] = 2.
        controls['sector_weights'] = sectors
        for field in ('exposure_margin', 'wait_seconds', 'reason'):
            if field in proposal:
                controls[field] = proposal[field]
        return validate_controls(controls, self.cat), diagnosis, tool, groups, priorities

    def _proposal_prompt(self):
        return (SURVEY_SKILL +
            'Return JSON only: {"condition":"uncertain","priority":"required_windows",'
            '"tool":"joint_search","groups":["G0"],"reason":"brief"}. '
            'Conditions: good,uncertain,poor,possible_fault,possible_pointing_error. Priorities: '
            'required_windows,science_windows,requests,recover_state. Tools are listed in context. '
            'Choose 1-2 group IDs. Optional ra_band integer from whole_sky RA10 redirects to another '
            'real sky group outside the menu; exposure_margin 1..1.4; wait_seconds integer0..900. '
            'The tool validates all actions; wait is only a suggestion checked by lookahead. '
            'Keep output below 110 tokens, reason below 8 words. Never return target IDs or prose.')

    def maybe_replan(self, state, candidates):
        bulletin = state.get('latest_bulletin') or {}
        if bulletin.get('initial'):
            for notice in _compact_message(bulletin).get('notices', []):
                if notice.get('event_kind') == 'terrain_obstruction' and notice not in self._persistent_notices:
                    self._persistent_notices.append(notice)
        if not candidates or self.calls >= self.max_calls:
            return False
        trigger = self._trigger(state)
        if trigger is None:
            return False
        calls_needed = 1 if self.variant == 'compact_skill_director' else 2
        if self.calls + calls_needed > self.max_calls:
            return False
        ordinary, emergency = self._available_call_budget(state, trigger, calls_needed)
        if ordinary+emergency < calls_needed:
            self._budget_deferrals += 1
            return False
        self._event_ordinary_remaining = ordinary
        self._event_emergency_remaining = emergency
        self._mark_trigger(state, trigger)
        context = self._context(state, candidates, trigger)
        prompt = self._proposal_prompt()
        if self.variant == 'event_director':
            diagnosis = self._call('interpret_event_and_execution', SURVEY_SKILL +
                'Diagnose this public event and feedback. Return only condition and priority using '
                'the enums: condition good/uncertain/poor/possible_fault/possible_pointing_error; '
                'priority required_windows/science_windows/requests/recover_state.', context)
            try:
                context['diagnosis'] = self._diagnosis(diagnosis)
            except ValueError:
                if diagnosis is not None:
                    self.errors += 1
                context['diagnosis_error'] = 'No valid diagnosis returned; reason from public evidence.'
        proposal = self._call('propose_executable_group_tool', prompt, context)
        if self.variant == 'counterfactual_director' and proposal is not None:
            # The first output is a genuine proposal; the second call must use
            # measured feedback to keep or replace it, never a canned fallback.
            context['proposed_plan'] = proposal
            context['challenge'] = ('Compare the selected group with the best unselected science/required/request '
                'group. Account for closing windows, repeated-score waste, uncertain quality, and API time. '
                'Keep or revise the plan. A larger required weight is not automatically better.')
            revised = self._call('criticise_and_revise_tool_plan', prompt, context)
            if revised is not None:
                proposal = revised
        for attempt in range(2):
            if proposal is None:
                return False
            try:
                controls, diagnosis, tool, groups, priorities = self._decode(proposal, state)
                break
            except (ValueError, TypeError, KeyError) as exc:
                self.errors += 1
                error = dict(tool_error=str(exc), rejected_proposal=proposal)
                self.tool_errors = (self.tool_errors + [error])[-3:]
                self._log(dict(stage='tool_rejection', **error))
                context['tool_error'] = error
                if attempt == 1:
                    return False
                proposal = self._call('repair_invalid_tool_plan', prompt, context)
        effective = lambda d: {k: v for k, v in d.items() if k != 'reason'}
        changed = effective(controls) != effective(self.controls) or priorities != self._selected_targets
        if self.valid_plans and changed and self.feedback:
            self.revisions += 1
        self.changed_plans += int(changed)
        self.controls = controls
        self.last_diagnosis = diagnosis
        self.interpretations += 1
        self.valid_plans += 1
        self._selected_targets = priorities
        self._selected_groups = groups
        self._selected_target_groups = [list(self._group_menu[g]['action']['assignments'].values()) for g in groups]
        if 'ra_band' in proposal:
            band_targets = [t for t in priorities if int(self.cat.ra[self.cat.index[t]] // 10) == proposal['ra_band']]
            if band_targets:
                self._selected_target_groups.insert(0, band_targets)
        self._tool_choices[tool] = self._tool_choices.get(tool, 0) + 1
        self.tool_errors.clear()
        self._log(dict(stage='accepted_plan', variant=self.variant, trigger=trigger, controls=controls,
                       selected_groups=groups, selected_targets=priorities, changed=changed,
                       feedback_records=len(self.feedback)))
        return changed

    def shortlist_indices(self, candidates, k=8):
        """Reserve at most half the exact-search budget for model-selected groups.

        Returning the full shortlist permits direct use without a learned model;
        when combining with a neural shortlist, callers should keep its leading
        half and merge the leading half returned here, then deduplicate/refill.
        """
        k = min(max(0, int(k)), len(candidates))
        if not k:
            return np.asarray([], dtype=int)
        base = sorted(range(len(candidates)), key=lambda i: (-float(candidates[i]['rate']), i))
        chosen = set(self._selected_targets)
        forced = []
        limit = max(1, k // 2)
        # Preserve each selected group before filling with duration alternatives
        # from a denser group; one large field must not swallow both LLM choices.
        for targets in self._selected_target_groups:
            group = set(targets)
            options = [i for i in base if i not in forced and group.intersection(candidates[i]['action']['assignments'].values())]
            if options:
                forced.append(min(options, key=lambda i: (
                    -len(group.intersection(candidates[i]['action']['assignments'].values())),
                    -float(candidates[i]['rate']), i)))
            if len(forced) >= limit:
                break
        extras = sorted((i for i in base if i not in forced and chosen.intersection(candidates[i]['action']['assignments'].values())),
            key=lambda i: (-len(chosen.intersection(candidates[i]['action']['assignments'].values())),
                           -float(candidates[i]['rate']), i))
        forced += extras[:max(0, limit-len(forced))]
        output = list(dict.fromkeys(forced + base))[:k]
        self._shortlist_forced += len(set(forced) - set(base[:k]))
        return np.asarray(output, dtype=int)

    def summary(self):
        return dict(super().summary(), variant=self.variant, replan_triggers=dict(self._events),
                    selected_tools=dict(self._tool_choices),
                    outside_top_rate_candidates_admitted=self._shortlist_forced,
                    last_context_characters=self._last_context_chars,
                    ordinary_api_calls=self._ordinary_calls, emergency_api_calls=self._emergency_calls,
                    protected_emergency_capacity=self._emergency_capacity,
                    deferred_for_call_budget=self._budget_deferrals)


class CounterfactualGroupAgent(EventGroupAgent):
    variant = 'counterfactual_director'


class CompactSkillGroupAgent(EventGroupAgent):
    variant = 'compact_skill_director'


def make_agent(catalogue, trace_path, variant='baseline', client=None, max_calls=8):
    classes = {'baseline': GroupAgent, 'event_director': EventGroupAgent,
               'counterfactual_director': CounterfactualGroupAgent,
               'compact_skill_director': CompactSkillGroupAgent}
    if variant not in classes:
        raise ValueError('Unknown agent variant: ' + str(variant))
    return classes[variant](catalogue, trace_path, client=client, max_calls=max_calls)
