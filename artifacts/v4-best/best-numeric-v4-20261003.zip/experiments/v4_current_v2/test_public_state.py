import copy
import unittest

from .public_state import PublicState


def initialize():
    return {'targets': {'columns': ['target_id', 'feature_flux', 'science_weight', 'required'],
                        'rows': [['a', .5, 1., True], ['b', 1., 2., False], ['zero', .5, 0., True]]},
            'scoring': {'q0': .68, 'flux_zero_point': .5, 'exposure_zero_point_seconds': 900.,
                        'airmass_exponent': .6,
                        'program': {'multipliers': {'DARK': 1.2, 'BRIGHT': 1.12, 'BACKUP': 1.06},
                                    'mismatch_multiplier': 1.},
                        'required': {'observed_factor_threshold': .5}},
            'survey': {'end_utc': '2026-10-03T08:00:00Z', 'nights': [
                {'night_id': 'n0', 'observing_start_utc': '2026-10-02T00:00:00Z', 'observing_end_utc': '2026-10-02T08:00:00Z'},
                {'night_id': 'n1', 'observing_start_utc': '2026-10-03T00:00:00Z', 'observing_end_utc': '2026-10-03T08:00:00Z'}]}}


def snapshot(index=0, result=None, now='2026-10-02T00:15:00Z', messages=None):
    return {'now_utc': now, 'observe_action_index': index, 'last_result': result,
            'new_messages': messages or [], 'active_requests': [], 'running_total': 999999.,
            'wallclock': {'remaining_seconds': 800.}}


def action(program='BACKUP', duration=900, target='a'):
    return {'action': 'observe', 'program': program, 'duration_seconds': duration,
            'pointing': {'alt_deg': 90., 'az_deg': 0.}, 'assignments': {'0': target}}


class PublicStateTests(unittest.TestCase):
    def setUp(self):
        self.memory = PublicState(initialize())
        self.memory.update(snapshot(now='2026-10-02T00:00:00Z'))

    def observe(self, score, index=0, program='BACKUP', target='a', prediction=None, messages=None):
        self.memory.record_action(action(program, target=target), prediction)
        return self.memory.update(snapshot(index+1, {'action': 'observe', 'observe_index': index,
                                  'hits': [{'target_id': target, 'score': score, 'factor': .999999,
                                            'quality': 12345.}]}, messages=messages))

    def test_selected_bonus_lower_bound_and_no_hidden_factor_leak(self):
        state = self.observe(.53)
        self.assertAlmostEqual(state['best_factor']['a'], .5)
        self.assertAlmostEqual(state['best_factor_upper']['a'], .53)
        self.assertEqual(state['required_missing'], 1)  # only unobservable zero-weight target
        self.assertEqual(state['best_score']['a'], .53)
        self.assertNotEqual(sum(state['best_score'].values()), state['running_science_score'])

    def test_two_maxima_and_no_exposure_accumulation(self):
        first = self.observe(.576, program='DARK')  # factor .48-.576
        second = self.observe(.53, index=1, program='BACKUP')  # guaranteed .50
        self.assertAlmostEqual(first['best_factor']['a'], .48)
        self.assertAlmostEqual(second['best_score']['a'], .576)
        self.assertAlmostEqual(second['best_factor']['a'], .5)
        self.assertAlmostEqual(second['best_factor_upper']['a'], .576)

    def test_same_score_does_not_reveal_program_match(self):
        state = self.observe(.55, program='DARK')
        self.assertLess(state['best_factor']['a'], .5)
        self.assertGreater(state['best_factor_upper']['a'], .5)
        self.assertEqual(state['required_missing'], 2)
        self.assertEqual(state['required_definitely_missing'], 1)

    def test_saturation_is_not_exact_quality(self):
        state = self.observe(1.2, program='DARK')
        self.assertEqual(state['best_factor']['a'], 1.)
        self.assertEqual(len(self.memory._quality_samples), 0)
        self.assertAlmostEqual(state['quality_estimate'], .68)
        self.assertGreaterEqual(state['quality_uncertainty'], .2)

    def test_unsaturated_prediction_calibration_can_exceed_one(self):
        state = self.observe(.9, prediction={'target_indices': [0], 'factors': [.3]})
        self.assertGreater(state['quality_estimate'], 1.)
        self.assertLess(state['quality_estimate'], 3.)

    def test_zero_science_weight_cannot_reveal_completion(self):
        state = self.observe(0, target='zero')
        self.assertEqual(state['best_factor']['zero'], 0.)
        self.assertEqual(state['best_factor_upper']['zero'], 1.)

    def test_resync_invalidates_observe_indices_and_uses_authoritative_scores(self):
        self.observe(.576, index=0, program='DARK')
        self.memory.record_action({'action': 'wait', 'duration_seconds': 60})
        self.memory.update(snapshot(1, {'action': 'wait'}))
        resync = {'record_type': 'state_resync', 'trigger_event_id': 'loss',
                  'issued_at_utc': '2026-10-02T00:15:00Z',
                  'invalidated_window': {'action_index_start': 1, 'action_index_end_exclusive': 2},
                  'observed_target_ids': ['a'], 'best_scores': [{'target_id': 'a', 'best_score': .575}]}
        state = self.observe(.53, index=1, messages=[resync])
        self.assertAlmostEqual(state['best_score']['a'], .575)
        self.assertAlmostEqual(state['best_factor']['a'], .48)
        self.assertNotIn(1, self.memory.history)
        # Identical public feedback must not restore invalidated data or replace
        # the authoritative score with our old local maximum on the next update.
        state = self.memory.update(snapshot(2, {'action': 'observe', 'observe_index': 1,
                                      'hits': [{'target_id': 'a', 'score': .53}]}, messages=[resync]))
        self.assertAlmostEqual(state['best_score']['a'], .575)
        self.assertAlmostEqual(state['best_factor']['a'], .48)
        state = self.observe(.54, index=2)
        self.assertAlmostEqual(state['best_score']['a'], .575)
        self.assertAlmostEqual(state['best_factor']['a'], .54/1.06)

    def test_resync_removes_target_then_new_valid_exposure_restores_it(self):
        self.observe(.6, index=0)
        resync = {'record_type': 'state_resync', 'trigger_event_id': 'loss',
                  'issued_at_utc': '2026-10-02T00:15:00Z',
                  'invalidated_window': {'action_index_start': 0, 'action_index_end_exclusive': 1},
                  'observed_target_ids': [], 'best_scores': []}
        state = self.memory.update(snapshot(1, messages=[resync]))
        self.assertEqual(state['best_factor'], {})
        self.assertEqual(state['best_score'], {})
        state = self.observe(.6, index=1)
        self.assertIn('a', state['best_score'])

    def test_resync_unknown_history_never_invents_factor(self):
        resync = {'record_type': 'state_resync', 'trigger_event_id': 'loss',
                  'issued_at_utc': '2026-10-02T00:15:00Z',
                  'invalidated_window': {'action_index_start': 0, 'action_index_end_exclusive': 1},
                  'best_scores': [{'target_id': 'a', 'best_score': .9}]}
        state = self.memory.update(snapshot(1, messages=[resync]))
        self.assertEqual(state['best_factor']['a'], 0.)
        self.assertEqual(state['best_factor_upper']['a'], 1.)
        self.assertIn('lack local exposure history', state['note'])
        state = self.observe(.1, index=1)
        self.assertEqual(state['best_factor_upper']['a'], 1.)
        self.assertAlmostEqual(state['best_factor']['a'], .1/1.06)

    def test_current_night_and_daytime_do_not_confuse_calendar(self):
        state = self.memory.update(snapshot(now='2026-10-02T12:00:00Z'))
        self.assertFalse(state['in_observing_window'])
        self.assertEqual(state['night_index'], 1)
        self.assertEqual(state['remaining_nights'], 1)
        self.assertEqual(state['end_utc'], '2026-10-03T08:00:00Z')
        state = self.memory.update(snapshot(now='2026-10-03T08:00:00Z'))
        self.assertEqual(state['remaining_nights'], 0)

    def test_semantic_messages_are_retained_without_reading_fake_numeric_weather(self):
        bulletin = {'record_type': 'bulletin', 'notices': [{'event_kind': 'rain', 'direction': 'ALL'}],
                    'quality': 99.}
        forecast = {'record_type': 'forecast', 'notices': [{'event_kind': 'haze', 'direction': 'NE', 'nights': ['2026-10-03']}]}
        state = self.memory.update(snapshot(messages=[bulletin, forecast]))
        self.assertLess(state['quality_estimate'], .68)
        self.assertEqual(state['latest_forecast'], forecast)
        self.assertEqual(state['latest_bulletin'], bulletin)
        self.assertGreaterEqual(state['quality_uncertainty'], .25)

    def test_short_night_end_uses_actual_elapsed_time_for_quality(self):
        self.memory.update(snapshot(now='2026-10-02T07:59:00Z'))
        self.memory.record_action(action(duration=900))
        state = self.memory.update(snapshot(1, {'action': 'observe', 'observe_index': 0,
                                 'hits': [{'target_id': 'a', 'score': .05}]}, now='2026-10-02T08:00:00Z'))
        self.assertGreater(state['quality_estimate'], .5)
        self.assertLess(state['quality_estimate'], 1.)

    def test_returned_mutations_do_not_corrupt_memory(self):
        state = self.observe(.53)
        state['best_factor']['a'] = 99.
        self.assertLess(self.memory.best_factor['a'], 1.)


if __name__ == '__main__':
    unittest.main()
