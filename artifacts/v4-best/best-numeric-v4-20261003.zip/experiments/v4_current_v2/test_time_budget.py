import unittest
from .common import planning_duration_floor


class TimeBudgetTests(unittest.TestCase):
    def test_more_computational_pressure_coarsens_actions(self):
        nights=[dict(observing_start_utc='2026-10-04T00:00:00Z',observing_end_utc='2026-10-04T09:00:00Z'),
                dict(observing_start_utc='2026-10-05T00:00:00Z',observing_end_utc='2026-10-05T09:00:00Z')]
        s=dict(now_utc='2026-10-04T00:00:00Z')
        cheap=planning_duration_floor(s,nights,.03,300)
        costly=planning_duration_floor(s,nights,.3,300)
        urgent=planning_duration_floor(s,nights,.3,30)
        self.assertLess(cheap,costly)
        self.assertLessEqual(costly,urgent)
        self.assertTrue(60<=cheap<=urgent<=600)

    def test_daylight_is_not_charged_as_observing_time(self):
        n=dict(observing_start_utc='2026-10-05T00:00:00Z',observing_end_utc='2026-10-05T09:00:00Z')
        before=planning_duration_floor(dict(now_utc='2026-10-04T10:00:00Z'),[n],.1,100)
        start=planning_duration_floor(dict(now_utc='2026-10-05T00:00:00Z'),[n],.1,100)
        self.assertEqual(before,start)


if __name__=='__main__':unittest.main()
