# Event-driven group and tool directors

These are development policies for the current public v4 protocol. Their scores
are proxy measurements until evaluated by the official platform. No policy reads
hidden weather, future requests, simulator factors, or truth files.

## Why change the director

The prior model received sparse fixed-night opportunities and its target choice
could vanish at the immediate-rate top-eight gate. The new director sees every
occupied RA band, a diverse menu of real candidate groups, public notices,
deadline requests, and actual hit/score discrepancies. It selects a **group and
an executable search tool**, rather than merely writing a narrative explanation.
An optional `ra_band` also redirects search to a publicly occupied sky region
outside the current menu; the numerical adapter creates known visible target
anchors in that band. Initial terrain notices persist after the first bulletin,
and new event forecasts can trigger a replan before the next progress checkpoint.
At most half the exact-search shortlist is reserved for its selected groups; the
other half retains numeric or neural leading candidates. The exact planner still
determines assignments, timing, program, legality, and score estimates.

## Variants

* `event_director`: interpret public events/feedback, then propose an executable
  group/tool policy. Replan on new requests, state resync, meaningful notices,
  persistent discrepancies, or five-night progress checkpoints.
* `counterfactual_director`: propose a plan, then ask an independent second pass
  to compare it against unselected science/required/request groups and revise
  it using the same actual feedback. This pays more API time for self-critique.
* `compact_skill_director`: combine interpretation and planning in one compact
  response with the same rule skill. This spends fewer calls and permits more
  event responses under the same global wall-clock limit.

`baseline` preserves the original interface. `make_agent(...)` builds all four.
Every API call, including corrections, counts against `max_calls`. Responses are
limited to 160 model tokens; the normal compact context is below 11,000 chars.

The tools map to transparent, validated numerical controls: `fast_science` uses
one-step search and a smaller candidate pool; `joint_search` uses balanced
two-step search; `secure_completion` uses conservative exposure margins and a
larger required-target weight. The model may override exposure margin or propose
a wait; a wait only executes after numerical lookahead checks its opportunity
cost. These controls change search ordering and allocation, never the scoring
formula. The plan log records chosen groups, controls, event trigger, feedback,
and whether execution-affecting values changed.

## Rule skill

Use marginal best-score improvement, not repeated exposure score. Required
completion uses a single unbonused factor. Request rewards require the published
minimum number of targets within the entire request window; expired requests
have no failure penalty. Weather quality and program-band quality differ.
Missing hits suggest geometry or pointing before a generic throughput failure;
low scores alone do not prove a repairable fault. Direction labels are coarse
evidence and must not become exact hard masks. Resync invalidates affected
history. Keep estimated quality and completion uncertainty explicit.

No prompt variant fixes a wrong simulator. Compare across cards and episodes,
and inspect how many model-chosen candidates actually reached numerical search.
