"""Packaged JSONL-v4 entry point; prepared locally, NOT cloud validated.

The catalogue comes exclusively from initialize.payload. No cards, simulator,
Torch runtime, or hidden truth are loaded. NumPy is needed by the real planner;
the protocol/validation unit tests use dependency-injected lightweight tools.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json
import math
import os
from pathlib import Path
import sys
import time

from .public_state import PublicState

PROTOCOL = 'participant-agent-protocol-v4'


def _stamp(value):
    parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('UTC time needs a timezone')
    return parsed.timestamp()


def _utc(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')


def catalogue_from_initialize(payload):
    from .planner import Catalogue
    table = payload['targets']
    rows = [dict(zip(table['columns'], values)) for values in table['rows']]
    if any(len(values) != len(table['columns']) for values in table['rows']):
        raise ValueError('Malformed public target table')
    instrument = payload['instrument']
    scenario = {'name': payload.get('task_card', {}).get('scenario_slug', 'live-v4'),
                'site': dict(payload['site']),
                'minimum_altitude_deg': payload['site'].get('minimum_altitude_deg', 30.)}
    fibers = {'field': {k: instrument[k] for k in ('n_fibers', 'fiber_area_deg2', 'gap_deg')},
              'exposure': dict(instrument['exposure'])}
    return Catalogue([str(row['target_id']) for row in rows],
                     *[[float(row[k]) for row in rows] for k in ('ra_deg', 'dec_deg', 'feature_flux', 'science_weight')],
                     [row['required'] is True or str(row['required']).lower() in ('1', 'true') for row in rows],
                     scenario, deepcopy(payload['scoring']), fibers, deepcopy(payload['survey']['nights']),
                     deepcopy(payload.get('footprint', [])),
                     target_classes=[row.get('target_class', '') for row in rows])


def validate_action(action, state, payload):
    """Return canonical protocol action, refusing unknown or ambiguous fields."""
    item = dict(action)
    if 'type' in item:
        if 'action' in item and item['action'] != item['type']:
            raise ValueError('Conflicting action names')
        item['action'] = item.pop('type')
    kind = item.get('action')
    common = {'action', 'reason', 'decision_source'}
    fields = {'observe': {'pointing', 'assignments', 'duration_seconds', 'program'},
              'wait': {'duration_seconds', 'until_utc'}, 'report': set(), 'finish': set()}
    if kind not in fields or set(item) - common - fields[kind]:
        raise ValueError('Unknown action or action fields')
    for key in ('reason', 'decision_source'):
        if key in item and not isinstance(item[key], str):
            raise ValueError('Action annotations must be strings')
    minimum = payload['instrument']['exposure']['min_duration_seconds']
    maximum = payload['instrument']['exposure']['max_duration_seconds']
    if kind == 'observe' or (kind == 'wait' and 'duration_seconds' in item):
        duration = item.get('duration_seconds')
        if type(duration) is not int or not minimum <= duration <= maximum:
            raise ValueError('Duration must be an integer in the published range')
    if kind == 'wait':
        if ('duration_seconds' in item) == ('until_utc' in item):
            raise ValueError('Wait must use exactly one time field')
        if 'until_utc' in item:
            until = item['until_utc']
            if not isinstance(until, str) or not until.endswith('Z') or _stamp(until) <= _stamp(state['now_utc']):
                raise ValueError('Wait time must be a future UTC Z time')
    if kind == 'observe':
        pointing = item.get('pointing')
        if not isinstance(pointing, dict) or set(pointing) != {'alt_deg', 'az_deg'}:
            raise ValueError('Pointing requires altitude and azimuth only')
        for key, low, high, closed in (('alt_deg', 0., 90., True), ('az_deg', 0., 360., False)):
            value = pointing[key]
            if type(value) not in (int, float) or not math.isfinite(value) or value < low or (value > high if closed else value >= high):
                raise ValueError('Invalid pointing angle')
        if item.get('program', 'BACKUP') not in ('DARK', 'BRIGHT', 'BACKUP'):
            raise ValueError('Invalid observing program')
        assignments = item.get('assignments')
        if not isinstance(assignments, dict):
            raise ValueError('Observe requires explicit assignments')
        count = int(payload['instrument']['n_fibers'])
        targets = payload['targets']
        id_column = targets['columns'].index('target_id')
        known = {str(row[id_column]) for row in targets['rows']}
        cells, used = set(), set()
        for cell, target in assignments.items():
            if not isinstance(cell, str) or not cell.isdigit() or not 0 <= int(cell) < count or int(cell) in cells:
                raise ValueError('Invalid or repeated fiber')
            if not isinstance(target, str) or target not in known or target in used:
                raise ValueError('Unknown or repeated target')
            cells.add(int(cell)); used.add(target)
    return item


def _hybrid_indices(prediction, baseline, k):
    n = len(baseline)
    greedy = sorted(range(n), key=lambda i: (-float(baseline[i]), i))
    if prediction is None:
        return greedy[:k]
    if len(prediction) != n or any(not math.isfinite(float(x)) for x in prediction):
        raise ValueError('Invalid neural shortlist prediction')
    learned = sorted(range(n), key=lambda i: (-float(prediction[i]), i))
    order = greedy[:(k+1)//2] + learned[:k//2]
    order += [i for pair in zip(greedy, learned) for i in pair]
    result = []
    for index in order:
        if index not in result:
            result.append(index)
        if len(result) >= min(k, n):
            break
    return result


class LiveAgent:
    def __init__(self, environment=None, stderr=None, catalogue_factory=None, planner_factory=None,
                 director_factory=None, predictor_loader=None):
        self.env = dict(os.environ if environment is None else environment)
        self.stderr = stderr or sys.stderr
        self.catalogue_factory = catalogue_factory or catalogue_from_initialize
        self.planner_factory = planner_factory
        self.director_factory = director_factory
        self.predictor_loader = predictor_loader
        self.payload = self.memory = self.planner = self.director = self.predictor = None
        self.previous = None
        self.last_sequence = -1
        self.decisions = self.teacher_evaluations = self.learned_uses = 0
        self.tool_errors = self.wait_evaluations = self.wait_accepted = 0
        self.report_attempts = self.report_false_count = self.low_feedback = 0
        self.quality_peak = None
        self.start = None
        self.numeric_seconds = 0.
        self.request_started = None
        self.finished = False

    def log(self, message):
        print(message, file=self.stderr, flush=True)

    def initialize(self, payload):
        if self.payload is not None:
            raise ValueError('Duplicate initialization')
        self.payload = deepcopy(payload)
        from .memory_variants import make_memory
        self.memory = make_memory(payload, self.env.get('BELIEF_VARIANT','legacy'))
        self.cat = self.catalogue_factory(payload)
        if self.planner_factory is None:
            from .strategy import make_planner
            self.planner_factory = lambda cat: make_planner(cat,self.env.get('PLANNING_STRATEGY','baseline'))
        self.planner = self.planner_factory(self.cat)
        disabled = self.env.get('NUMERIC_NO_LLM', '').lower() in ('1', 'true', 'yes') or self.env.get('USE_LLM', '1').lower() in ('0', 'false', 'no')
        has_key = bool(self.env.get('OPENAI_API_KEY') or self.env.get('OPENAI_API_KEY_FILE'))
        if not disabled and (has_key or self.director_factory is not None):
            log_dir = Path(self.env.get('RUN_LOG_DIR', str(Path(__file__).resolve().parent / 'run_logs')))
            try:
                log_dir.mkdir(parents=True, exist_ok=True)
                if self.director_factory is None:
                    from .agent_variants import make_agent
                    self.director_factory = lambda cat,path,max_calls: make_agent(cat,path,
                        self.env.get('AGENT_VARIANT','baseline'),max_calls=max_calls)
                self.director = self.director_factory(self.cat, log_dir / 'live_agent_trace.jsonl',
                    max_calls=int(self.env.get('MAX_API_CALLS','8')))
            except (ValueError, OSError):
                self.log('LLM initialization failed; numerical fallback enabled (credentials not logged).')
        else:
            self.log('LLM disabled by configuration; numerical fallback enabled.' if disabled else
                     'No model API credential available; numerical fallback enabled. Award-stage LLM requirement is not satisfied by this fallback alone.')
        weights = self.env.get('SKY_WEIGHTS')
        if weights:
            try:
                if not str(weights).endswith('.npz'):
                    raise ValueError('Runtime supports exported NPZ weights only')
                if self.predictor_loader is None:
                    if self.env.get('LEARNING_VARIANT')=='1':
                        from .learning_variants import load_variant
                        self.predictor_loader = lambda path,backend: load_variant(path)
                    else:
                        from .learning import load_predictor
                        self.predictor_loader = load_predictor
                self.predictor = self.predictor_loader(weights, backend='numpy')
            except (OSError, ValueError, KeyError):
                self.log('Neural weights unavailable or invalid; numerical shortlist fallback enabled.')
        self.log('Initialized JSONL-v4 public-state agent; local proxy tools have not been cloud validated.')

    def _wait(self, state):
        now = _stamp(state['now_utc'])
        if not state['in_observing_window'] and state.get('next_night_start_utc') and _stamp(state['next_night_start_utc']) > now:
            return {'action': 'wait', 'until_utc': state['next_night_start_utc']}
        end = _stamp(state['end_utc'])
        if end > now:
            return {'action': 'wait', 'until_utc': _utc(min(end, now + 900))}
        return {'action': 'finish'}

    def _remaining(self, state):
        public = float(state.get('wallclock', {}).get('remaining_seconds', 900))
        public -= max(0., time.monotonic() - self.request_started)
        elapsed = time.monotonic() - self.start
        global_limit = float(self.payload.get('limits', {}).get('global_wallclock_seconds', 900))
        return max(0., min(public, global_limit - elapsed))

    def _report_if_needed(self, state):
        """Bounded fault probe from repeated public feedback, never one bad hit."""
        result = state.get('last_result') or {}
        if result.get('action') == 'report':
            self.report_false_count = 0 if result.get('correct') else self.report_false_count + 1
            self.low_feedback = 0
            if result.get('correct'):
                self.quality_peak = None
            return False
        if result.get('action') != 'observe':
            return False
        q = float(state['quality_estimate'])
        peak = self.quality_peak
        self.quality_peak = max(q, peak or 0.)
        previous_candidate = self.previous[1] if self.previous else None
        assigned = len(previous_candidate['action']['assignments']) if previous_candidate else 0
        hit_fraction = len(result.get('hits', [])) / max(1, assigned)
        weather_warning = any(n.get('direction') == 'ALL' and n.get('event_kind') in
                              ('rain', 'snow', 'overcast', 'haze', 'cold_snap')
                              for n in (state.get('latest_bulletin') or {}).get('notices', []))
        if peak and q < .35 * peak and hit_fraction >= .75 and not weather_warning:
            self.low_feedback += 1
        else:
            self.low_feedback = 0
        allowance = int(self.payload['scoring'].get('reporting', {}).get('false_report_free_allowance', 0))
        if self.low_feedback >= 3 and self.report_attempts < 3 and self.report_false_count < allowance:
            self.report_attempts += 1
            self.low_feedback = 0
            self.log('Repeated unexplained quality loss: bounded fault report probe.')
            return True
        return False

    def choose(self, state):
        if state['remaining_nights'] <= 0:
            return {'action': 'finish'}, None
        if not state['in_observing_window']:
            return self._wait(state), None
        remaining = self._remaining(state)
        if remaining < 1.:
            return {'action': 'finish'}, None
        from .agent import DEFAULT_CONTROLS
        controls = deepcopy(DEFAULT_CONTROLS)
        if self.director:
            controls.update(self.director.controls)
        # Reserve time for every unvisited night, rather than waiting until the
        # last minute to discover that half the season remains unplanned.
        low_budget = remaining < max(60., 15. * state['remaining_nights'])
        budget = min(16 if low_budget else 32,int(controls.get('candidate_budget',48)))
        controls['candidate_budget'] = budget
        if low_budget:
            controls['horizon'] = 1
        candidates = self.planner.propose(state, controls, max_candidates=budget)
        if self.director and not low_budget and remaining > 110 and self.director.maybe_replan(state, candidates):
            controls = dict(self.director.controls)
            budget = min(16 if low_budget else 32,int(controls.get('candidate_budget',48)))
            controls['candidate_budget']=budget
            candidates = self.planner.propose(state, controls, max_candidates=budget)
        remaining = self._remaining(state)  # model calls consumed real wall time
        if not candidates:
            return self._wait(state), None
        baseline = [float(c['rate']) for c in candidates]
        selection = list(self.planner.selection_values(candidates,state)) if hasattr(self.planner,'selection_values') else baseline
        if remaining < max(60., 12. * state['remaining_nights']):
            chosen = candidates[max(range(len(candidates)), key=lambda i: selection[i])]
            return chosen['action'], chosen
        prediction = None
        if self.predictor:
            try:
                maps,scalars=[c['maps'] for c in candidates],[c['scalars'] for c in candidates]
                prediction = self.predictor.score_candidates(maps,scalars,baseline) if hasattr(self.predictor,'score_candidates') else self.predictor.predict(maps,scalars)
                self.learned_uses += 1
            except (ValueError, TypeError, KeyError):
                self.tool_errors += 1
                self.log('Neural shortlist rejected; using numerical ranking.')
        k=min(8,len(candidates))
        indices = _hybrid_indices(prediction, selection, k)
        if self.director and hasattr(self.director,'shortlist_indices'):
            directed=self.director.shortlist_indices(candidates,k=min(4,k))
            indices=list(dict.fromkeys(list(indices[:4])+list(directed)+list(indices)))[:k]
        values = self.planner.teacher_targets(candidates, state, controls, indices=indices)
        self.teacher_evaluations += len(indices)
        if len(values) != len(indices) or any(not math.isfinite(float(v)) for v in values):
            raise ValueError('Invalid numerical tool values')
        chosen = candidates[indices[max(range(len(indices)), key=lambda i: float(values[i]))]]
        if self.cat is not None and int(controls.get('wait_seconds',0))>=60:
            from .decision_tools import checked_wait
            checked,accepted=checked_wait(self.planner,self.cat,state,chosen,controls,self.decisions,self._remaining(state))
            self.teacher_evaluations+=int(checked);self.wait_evaluations+=int(checked)
            if accepted:
                self.wait_accepted+=1
                return {'action':'wait','duration_seconds':int(controls['wait_seconds'])},None
        return chosen['action'], chosen

    def handle(self, message):
        if message.get('protocol_version') != PROTOCOL:
            raise ValueError('Incorrect protocol version')
        kind = message.get('message_type')
        if kind == 'finish':
            self.finished = True
            self.log(json.dumps({'event': 'finish', 'decisions': self.decisions,
                                 'teacher_evaluations': self.teacher_evaluations,
                                 'learned_uses': self.learned_uses, 'tool_errors': self.tool_errors,
                                 'agent': self.director.summary() if self.director else None}, ensure_ascii=False))
            return None
        if kind == 'initialize':
            self.initialize(message['payload'])
            return None
        if kind != 'decision_request' or self.payload is None:
            raise ValueError('Expected initialize then decision_request')
        sequence = message.get('decision_sequence')
        if type(sequence) is not int or sequence < 0 or sequence <= self.last_sequence:
            raise ValueError('Decision sequence must be a new nonnegative integer')
        if self.start is None:
            self.start = time.monotonic()
        payload = message['payload']
        self.request_started = time.monotonic()
        if self.director and self.previous and payload.get('last_result'):
            previous_state, candidate = self.previous
            if candidate:
                self.director.observe_feedback(previous_state, candidate, payload['last_result'])
        state = self.memory.update(payload)
        from .common import planning_duration_floor
        cost=self.numeric_seconds/max(1,self.decisions) if self.decisions else .10
        state['min_planning_duration']=planning_duration_floor(state,self.payload['survey']['nights'],cost,self._remaining(state))
        api_before=getattr(self.director,'seconds',0.)
        numeric_started=time.monotonic()
        try:
            if self._report_if_needed(state):
                command, chosen = {'action': 'report'}, None
            else:
                command, chosen = self.choose(state)
            command = validate_action(command, state, self.payload)
        except (ValueError, TypeError, KeyError, ArithmeticError) as exc:
            self.tool_errors += 1
            # Do not echo model response or credentials; bounded class only.
            self.log('Planning tool rejected; safe wait fallback: ' + type(exc).__name__)
            if self.director:
                self.director.feedback.append({'tool_error': 'Planner returned an invalid or failed proposal; revise the group plan.'})
            command, chosen = validate_action(self._wait(state), state, self.payload), None
        api_after=getattr(self.director,'seconds',0.)
        self.numeric_seconds+=max(0.,time.monotonic()-numeric_started-(api_after-api_before))
        response = {'protocol_version': PROTOCOL, 'message_type': 'decision_response',
                    'decision_sequence': sequence, **command}
        encoded = json.dumps(response, allow_nan=False, ensure_ascii=False)
        if len(encoded.encode()) > int(self.payload.get('limits', {}).get('response_max_bytes', 524288)):
            raise ValueError('Response exceeds published byte limit')
        self.memory.record_action(command, prediction=chosen)
        self.previous = (state, chosen)
        self.last_sequence = sequence
        self.decisions += 1
        return response


def run(stdin=None, stdout=None, stderr=None, session=None):
    stdin, stdout, stderr = stdin or sys.stdin, stdout or sys.stdout, stderr or sys.stderr
    agent = session or LiveAgent(stderr=stderr)
    try:
        for line in stdin:
            if not line.strip():
                continue
            message = json.loads(line, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))
            if not isinstance(message, dict):
                raise ValueError('Protocol message must be an object')
            response = agent.handle(message)
            if response is not None:
                stdout.write(json.dumps(response, ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n')
                stdout.flush()
            if agent.finished:
                break
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print('Fatal protocol/IO error: ' + type(exc).__name__, file=stderr, flush=True)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(run())
