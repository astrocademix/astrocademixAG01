"""Two real API planning rounds on current public data and actual proxy feedback."""
import argparse
import json
from pathlib import Path

from .agent import GroupAgent, DEFAULT_CONTROLS
from .common import atomic_json
from .environment import DevelopmentSurvey
from .planner import Catalogue, Planner
from .public_state import PublicState


def main():
    p=argparse.ArgumentParser();p.add_argument('--cards',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    cat=Catalogue.from_directory(Path(a.cards)/'alpha')
    env=DevelopmentSurvey(cat,episode=2,max_nights=1)
    memory=PublicState(env.initialize_payload());planner=Planner(cat)
    director=GroupAgent(cat,out/'api_trace.jsonl',max_calls=6)
    state=memory.update(env.public_payload())
    candidates=planner.propose(state,DEFAULT_CONTROLS,max_candidates=16)
    director.maybe_replan(state,candidates)
    candidates=planner.propose(state,director.controls,max_candidates=16)
    chosen=max(candidates,key=lambda c:c['rate'])
    memory.record_action(chosen['action'],prediction=chosen)
    result=env.step(chosen['action'])
    director.observe_feedback(state,chosen,result)
    next_state=memory.update(env.public_payload())
    # This acceptance probe explicitly requests an immediate feedback review;
    # the full-season experiment retains sparse night/event triggers.
    director.last_trigger=-1
    candidates=planner.propose(next_state,director.controls,max_candidates=16)
    director.maybe_replan(next_state,candidates)
    report=dict(director.summary(),purpose='real API integration acceptance; not an official scored episode',
        actual_public_feedback=result,official_score=None)
    atomic_json(out/'result.json',report)
    print(json.dumps(report))
    if report['valid_group_plans']<1 or report['interpretations']<1:
        raise RuntimeError('No valid model interpretation-and-planning cycle')


if __name__=='__main__':main()
