"""Sparse API-driven interpretation and group planning with scored feedback.

The model controls target groups/sky regions and search allocation, never the
score formula or action validator. Failed proposals are returned as tool errors.
The same interface accepts a platform-injected API or our server-local Qwen API.
"""
import json
import math
from pathlib import Path
import time
import numpy as np

from experiments.v4_online_v1.api_client import APIClient, ClientError

DEFAULT_CONTROLS = dict(required_weight=1., science_weight=1., exposure_margin=1.20,
    candidate_budget=48, horizon=2, wait_seconds=0, priority_targets=[], sector_weights={})


def validate_controls(proposal, catalogue):
    if not isinstance(proposal, dict):
        raise ValueError('proposal must be an object')
    allowed = set(DEFAULT_CONTROLS) | {'focus_ra_deg', 'reason'}
    if set(proposal) - allowed:
        raise ValueError('unknown proposal fields: ' + ','.join(sorted(set(proposal) - allowed)))
    result = dict(DEFAULT_CONTROLS)
    for k, low, high in [('required_weight', .5, 2.), ('science_weight', .5, 2.),
                         ('exposure_margin', 1., 1.4), ('focus_ra_deg', 0., 359.999999)]:
        if k in proposal:
            v = proposal[k]
            if type(v) not in (int, float) or not math.isfinite(v) or not low <= v <= high:
                raise ValueError(f'{k} outside [{low},{high}]')
            result[k] = float(v)
    for k, low, high in [('candidate_budget', 16, 48), ('horizon', 1, 2), ('wait_seconds', 0, 900)]:
        if k in proposal:
            v = proposal[k]
            if type(v) is not int or not low <= v <= high:
                raise ValueError(f'{k} requires integer [{low},{high}]')
            result[k] = v
    tids = proposal.get('priority_targets', [])
    if (not isinstance(tids, list) or len(tids) > 8 or any(not isinstance(t, str) for t in tids)
            or len(tids) != len(set(tids)) or any(t not in catalogue.index for t in tids)):
        raise ValueError('priority_targets must be <=8 unique known target IDs')
    result['priority_targets'] = tids
    sectors = proposal.get('sector_weights', {})
    if not isinstance(sectors, dict) or len(sectors) > 8:
        raise ValueError('sector_weights must contain <=8 RA bands')
    for k, v in sectors.items():
        if not isinstance(k, str) or not k.isdigit() or not 0 <= int(k) < 36 or type(v) not in (int, float) or not math.isfinite(v) or not .5 <= v <= 2:
            raise ValueError('sector_weights use RA/10 integer keys 0..35 and values .5..2')
    result['sector_weights'] = sectors
    if 'reason' in proposal:
        if not isinstance(proposal['reason'], str) or len(proposal['reason']) > 500:
            raise ValueError('reason must be a short string')
        result['reason'] = proposal['reason']
    return result


class GroupAgent:
    def __init__(self, catalogue, trace_path, client=None, max_calls=8):
        self.cat = catalogue
        self.client = client or APIClient.from_env(timeout=32)
        self.trace_path = Path(trace_path)
        self.trace_path.parent.mkdir(parents=True, exist_ok=True)
        self.controls = dict(DEFAULT_CONTROLS)
        self.max_calls = max_calls
        self.calls = self.valid_plans = self.errors = self.revisions = 0
        self.changed_plans = 0
        self.interpretations = 0
        self.seconds = 0.
        self.last_trigger = -1
        self.feedback = []
        self.last_diagnosis = None
        self.tool_errors = []

    def _log(self, value):
        with self.trace_path.open('a') as f:
            f.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n')

    def observe_feedback(self, before_state, candidate, result):
        if result.get('action') != 'observe':
            return
        actual = sum(float(h['score']) for h in result.get('hits', []))
        self.feedback.append(dict(now_utc=before_state['now_utc'],
            requested_seconds=candidate['action']['duration_seconds'],
            pointing_ra_deg=round(float(candidate.get('pointing_ra_deg', 0.)), 2),
            expected_science=sum(float(x) for x in candidate.get('scores', [])),
            measured_exposure_science=actual, hit_count=len(result.get('hits', [])),
            assigned_count=len(candidate['action']['assignments'])))
        self.feedback = self.feedback[-12:]

    def _call(self, stage, system, context):
        if self.calls >= self.max_calls:
            return None
        self.calls += 1
        start = time.monotonic()
        messages = [dict(role='system', content=system),
                    dict(role='user', content=json.dumps(context, ensure_ascii=False, separators=(',', ':')))]
        try:
            response = self.client.plan(messages, max_tokens=160)
            self._log(dict(stage=stage, messages=messages, response=response))
            return response['plan']
        except ClientError as exc:
            self.errors += 1
            self._log(dict(stage=stage, messages=messages, error=exc.code, elapsed_seconds=exc.elapsed_seconds))
            return None
        finally:
            self.seconds += time.monotonic() - start

    def _sky_summary(self, state):
        """Whole-catalogue opportunities, independently of the top-six proposals.

        All quantities come from public targets, geometry and conservative
        score-derived completion bounds. Required Q is an intrinsic zenith
        estimate before lunar/airmass losses, never hidden measured weather.
        """
        from datetime import timedelta
        from .planner import equatorial_to_horizontal, utc_datetime
        cat = self.cat
        factors = np.asarray([state.get('best_factor', {}).get(str(t), 0.) for t in cat.ids])
        scores = np.asarray([state.get('best_score', {}).get(str(t), 0.) for t in cat.ids])
        threshold = cat.score_config['required']['observed_factor_threshold']
        unfinished = cat.required & (factors < threshold)
        max_bonus = max(cat.score_config['program']['multipliers'].values())
        science = np.maximum(0., cat.weight * max_bonus - scores)
        now = utc_datetime(state['now_utc'])
        site = cat.scenario['site']
        alt, _ = equatorial_to_horizontal(cat.ra, cat.dec, now,
            site['latitude_deg'], site['longitude_deg'])
        later_alt, _ = equatorial_to_horizontal(cat.ra, cat.dec, now + timedelta(seconds=1800),
            site['latitude_deg'], site['longitude_deg'])
        visible = alt >= cat.scenario.get('minimum_altitude_deg', 30.)
        closing = visible & (later_alt < cat.scenario.get('minimum_altitude_deg', 30.) + 2.)
        norm = cat.score_config['flux_zero_point'] * cat.score_config['exposure_zero_point_seconds']
        maximum = cat.fiber_config['exposure']['max_duration_seconds']
        needed_q = threshold * norm / np.maximum(cat.flux * maximum, 1e-12)
        band_ids = np.floor(cat.ra / 10).astype(int)
        rows = []
        for band in sorted(set(band_ids.tolist())):
            indices = np.flatnonzero(band_ids == band)
            required_ids = indices[unfinished[indices]]
            if len(required_ids):
                order = np.lexsort((needed_q[required_ids], ~visible[required_ids], ~closing[required_ids]))
                urgent = required_ids[order[:2]]
            else:
                urgent = indices[np.argsort(-science[indices], kind='stable')[:2]]
            rows.append(dict(ra_band=int(band), required_remaining=len(required_ids),
                remaining_science=round(float(science[indices].sum()), 3),
                required_Q_over_1=int(np.sum(unfinished[indices] & (needed_q[indices] > 1.))),
                visible_required=int(np.sum(unfinished[indices] & visible[indices])),
                closing_required_30min=int(np.sum(unfinished[indices] & closing[indices])),
                urgent_known_ids=[str(cat.ids[i]) for i in urgent]))
        rows.sort(key=lambda row: (-row['required_remaining'], -row['remaining_science'], row['ra_band']))
        return dict(band_width_deg=10, occupied_bands=len(rows), displayed_bands=rows[:12],
            Q_definition='Intrinsic zenith Q needed to reach required threshold in one maximum exposure; ignores geometric/lunar losses.',
            completion_definition='Public score-derived conservative factor lower bound, not hidden completion truth.')

    def maybe_replan(self, state, candidates):
        night = int(state['night_index'])
        # Four planning opportunities per 38-night season. Interpretation and
        # proposal need two calls; one bounded repair may use a third, always
        # within the same total eight-call cap.
        trigger = max((x for x in (0, 10, 23, 31) if night >= x), default=-1)
        if trigger <= self.last_trigger or self.calls + 2 > self.max_calls or not candidates:
            return False
        self.last_trigger = trigger
        top = sorted(candidates, key=lambda c: c['rate'], reverse=True)[:6]
        summaries = [dict(ra=round(float(c['pointing_ra_deg']), 2), dec=round(float(c['pointing_dec_deg']), 2),
            duration=c['action']['duration_seconds'], estimated_gain=round(float(c['est_gain']), 3),
            targets=list(c['action']['assignments'].values())[:8]) for c in top]
        context = dict(now_utc=state['now_utc'], night_index=night,
            remaining_nights=state['remaining_nights'], required_missing=state.get('required_missing'),
            quality_estimate=state['quality_estimate'], quality_uncertainty=state['quality_uncertainty'],
            bulletin=state.get('latest_bulletin'), forecast=state.get('latest_forecast'),
            notices=[{k: v for k, v in m.items() if k not in ('best_scores', 'observed_target_ids')}
                     for m in state.get('new_messages', [])][-3:],
            active_requests=state.get('active_requests', [])[:3],
            recent_feedback=self.feedback[-4:], unresolved_tool_errors=self.tool_errors[-3:], candidate_groups=summaries,
            whole_sky=self._sky_summary(state),
            previous_controls=self.controls,
            rules=dict(required_threshold=self.cat.score_config['required']['observed_factor_threshold'],
                missing_penalty=self.cat.score_config['required']['penalty_per_missing'],
                single_exposure_max=self.cat.fiber_config['exposure']['max_duration_seconds'],
                exposures_accumulate=False, program_bonus_does_not_complete_required=True))
        diagnosis = self._call('interpret_feedback',
            'Interpret survey bulletins and actual exposure feedback using only the provided public information; '
            'quality is uncertain, and low scores alone do not prove an instrument fault. '
            'Return JSON only: {"condition":"good|uncertain|poor|possible_fault",'
            '"replan_reason":"short string","priority":"required_windows|science_windows|requests|recover_state"}. '
            'Use precisely one value from each enum.', context)
        if diagnosis is not None:
            valid = (set(diagnosis) == {'condition', 'replan_reason', 'priority'} and
                diagnosis.get('condition') in ('good', 'uncertain', 'poor', 'possible_fault') and
                diagnosis.get('priority') in ('required_windows', 'science_windows', 'requests', 'recover_state') and
                isinstance(diagnosis.get('replan_reason'), str))
            if valid:
                self.last_diagnosis = diagnosis
                self.interpretations += 1
                context['interpretation'] = diagnosis
            else:
                self.errors += 1
                context['tool_error'] = 'Your diagnostic object was invalid; use supported enums.'
        proposal_system = ('You direct a numerical sky survey planner. Use the real candidate groups and measured feedback '
            'to choose target groups, RA sector priorities, exposure safety, and search effort. '
            'Output one JSON object. Allowed optional fields: priority_targets (<=8 known target IDs), '
            'focus_ra_deg (0..<360), sector_weights ({"0".."35":0.5..2}, <=8 entries, RA bands of10deg), '
            'required_weight/science_weight (0.5..2), exposure_margin (1..1.4), candidate_budget (16..48), '
            'horizon (1 or2), wait_seconds (0..900), reason (short). '
            'Never invent targets. Weights affect proposal ordering only, not the fixed scoring rule. '
            'A wait is considered only if numerical lookahead validates its benefit. '
            'Do not spend long exposures on a required target that cannot reach its completion threshold in current quality.')
        proposal_system += (' Keep the answer under 100 tokens: choose at most 3 control fields plus a reason of at most 8 words. '
                            'Use at most 4 priority targets and at most 3 sector entries. Omitted controls use defaults.')
        for attempt in range(2):
            proposal = self._call('propose_group_plan' if attempt == 0 else 'revise_rejected_group_plan',
                                  proposal_system, context)
            if proposal is None:
                return False
            try:
                new = validate_controls(proposal, self.cat)
                break
            except (ValueError, TypeError) as exc:
                self.errors += 1
                error = dict(tool_error=str(exc), rejected_proposal=proposal)
                self._log(dict(stage='tool_rejection', **error))
                self.tool_errors.append(error)
                self.tool_errors = self.tool_errors[-3:]
                context['tool_error'] = error
        else:
            return False
        # A changed explanation alone does not change the numerical policy.
        effective = lambda value: {k: v for k, v in value.items() if k != 'reason'}
        changed = effective(new) != effective(self.controls)
        real_feedback = any('measured_exposure_science' in row for row in self.feedback)
        if self.valid_plans and changed and real_feedback:
            self.revisions += 1
        if changed:
            self.changed_plans += 1
        self.controls = new
        self.valid_plans += 1
        self.tool_errors.clear()
        self._log(dict(stage='accepted_plan', controls=new, changed=changed,
            feedback_records=len(self.feedback)))
        return changed

    def summary(self):
        return dict(api_calls=self.calls, valid_group_plans=self.valid_plans,
            feedback_revisions=self.revisions, changed_group_plans=self.changed_plans, interpretations=self.interpretations,
            errors=self.errors, api_seconds=self.seconds)
