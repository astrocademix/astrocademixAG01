"""Integrity and inference checks; the small Torch round-trip runs if installed."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from . import learning


def fixture():
    rng = np.random.default_rng(7)
    n = 3 * 3 * 12
    scalars = rng.normal(size=(n, 12)).astype(np.float32)
    return dict(maps=rng.normal(size=(n, 12, 4, 4)).astype(np.float32), scalars=scalars,
                target=(scalars[:, 0] + scalars[:, 1] ** 2).astype(np.float32),
                baseline=scalars[:, 0], group_id=np.repeat([f"g{i}" for i in range(9)], 12),
                split=np.repeat(["train", "validation", "test"], 36))


META = dict(label_definition="Two-step synthetic planner gain for a unit test; not an official score",
            teacher_is_official=False, cards=["alpha", "beta", "gamma", "delta"])


class IntegrityTests(unittest.TestCase):
    def test_reject_group_leakage_missing_split_nonfinite(self):
        data = fixture()
        data["group_id"][36] = data["group_id"][0]
        with self.assertRaisesRegex(ValueError, "crosses"):
            learning.validate_dataset(data, META)
        data = fixture()
        data["split"][data["split"] == "test"] = "train"
        with self.assertRaisesRegex(ValueError, "exactly"):
            learning.validate_dataset(data, META)
        data = fixture()
        data["target"][5] = np.nan
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            learning.validate_dataset(data, META)

    def test_normalization_is_train_only(self):
        data = learning.validate_dataset(fixture(), META)
        before = learning.fit_normalization(data)
        take = data["split"] != "train"
        data["maps"][take] = 1e8
        data["scalars"][take] = -1e8
        data["target"][take] = 2e8
        self.assertEqual(before, learning.fit_normalization(data))

    def test_hybrid_has_identical_budget_and_no_duplicates(self):
        scores = np.arange(16, dtype=float)
        baseline = scores[::-1].copy()
        target = np.zeros(16)
        target[-1] = 10
        for k in (4, 8):
            selected = learning.shortlist(scores, baseline, k, "hybrid")
            self.assertEqual(len(selected), k)
            self.assertEqual(len(set(selected.tolist())), k)
            overlapping = learning.shortlist(scores, scores, k, "hybrid")
            self.assertEqual(len(overlapping), k)
        report = learning.evaluate_shortlists(target, scores, baseline, np.repeat("g", 16))
        self.assertEqual(report["budgets"]["4"]["baseline"]["mean_regret"], 10)
        self.assertEqual(report["budgets"]["4"]["learned"]["mean_regret"], 0)
        self.assertEqual(report["budgets"]["4"]["hybrid"]["mean_regret"], 0)

    def test_numpy_zero_network_and_empty_input(self):
        weights = {key: np.zeros(shape, dtype=np.float32) for key, shape in learning.NumpyPredictor.SHAPES.items()}
        data = learning.validate_dataset(fixture(), META)
        norm = learning.fit_normalization(data)
        predictor = learning.NumpyPredictor(weights, norm)
        prediction = predictor(data["maps"][:2], data["scalars"][:2])
        np.testing.assert_allclose(prediction, norm["target_mean"])
        self.assertEqual(predictor(data["maps"][:0], data["scalars"][:0]).shape, (0,))

    @unittest.skipUnless(importlib.util.find_spec("torch"), "Torch unavailable locally; run on training server")
    def test_train_export_equivalence_and_immutable_artifacts(self):
        import torch
        torch.set_num_threads(min(2, torch.get_num_threads()))
        # Keep test writes alongside this package, including on the server
        # where the user limits all artifacts to the huangzy183 directory.
        root = Path(tempfile.mkdtemp(prefix='test-learning-', dir=Path(__file__).resolve().parent))
        try:
            dataset = root / "dataset.npz"
            np.savez_compressed(dataset, **fixture(), metadata_json=np.asarray(json.dumps(META)))
            result = learning.train(dataset, root / "train", device="cpu", epochs=2)
            self.assertEqual(result["test_evaluations"], 1)
            self.assertEqual(result["status"], "complete")
            data = fixture()
            p_numpy = learning.load_predictor(root / "train")
            p_torch = learning.load_predictor(root / "train", backend="torch")
            np.testing.assert_allclose(p_numpy(data["maps"], data["scalars"]),
                                       p_torch(data["maps"], data["scalars"]), rtol=2e-4, atol=1e-4)
            with self.assertRaises(FileExistsError):
                learning.train(dataset, root / "train", device="cpu", epochs=1)
        finally:
            # Explicit known paths avoid NFS readdir lag during rmtree cleanup.
            for name in ('run.started.json', 'config.json', 'progress.jsonl', 'best.pt', 'weights.npz',
                         'heldout_predictions.npz', 'training.json'):
                (root/'train'/name).unlink(missing_ok=True)
            if (root/'train').exists():
                (root/'train').rmdir()
            (root/'dataset.npz').unlink(missing_ok=True)
            root.rmdir()


if __name__ == "__main__":
    unittest.main()
