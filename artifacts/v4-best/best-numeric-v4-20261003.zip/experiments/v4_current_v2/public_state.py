"""Memory built only from the public participant-agent-protocol-v4 messages.

The protocol deliberately exposes score, not completion factor or sky quality.
``best_factor`` is therefore a *lower bound*, never hidden simulator state.
Quality estimates are heuristic beliefs; they are not official weather values.
"""
from copy import deepcopy
from datetime import datetime, timezone
import math
import statistics


def _time(value):
    parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Public UTC times require an explicit timezone')
    return parsed.timestamp()


def _finite(value, default=None):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


class PublicState:
    """Adapt initialize.payload and decision_request.payload to planner inputs.

    Call update(snapshot), choose an action, then record_action(action, candidate).
    The optional candidate may contain the planner's target_indices/factors arrays;
    it is used only to calibrate a quality belief, never completion or reward.
    """

    def __init__(self, initialize_payload):
        self.initialize = deepcopy(initialize_payload)
        self.scoring = deepcopy(initialize_payload['scoring'])
        table = initialize_payload['targets']
        if not isinstance(table, dict) or not isinstance(table.get('columns'), list):
            raise ValueError('v4 targets must contain columns and rows')
        self.targets = {}
        self.target_order = []
        for values in table['rows']:
            if len(values) != len(table['columns']):
                raise ValueError('Target row does not match columns')
            row = dict(zip(table['columns'], values))
            tid = str(row['target_id'])
            if tid in self.targets:
                raise ValueError('Duplicate target identifier')
            row['feature_flux'] = _finite(row['feature_flux'])
            row['science_weight'] = _finite(row['science_weight'])
            if row['feature_flux'] is None or row['science_weight'] is None or min(row['feature_flux'], row['science_weight']) < 0:
                raise ValueError('Invalid target flux or weight')
            row['required'] = row.get('required') is True or str(row.get('required', '')).lower() in ('1', 'true')
            self.targets[tid] = row
            self.target_order.append(tid)
        self.nights = sorted(deepcopy(initialize_payload['survey']['nights']),
                             key=lambda n: _time(n['observing_start_utc']))
        self.survey_end = initialize_payload['survey']['end_utc']
        self.norm = float(self.scoring['flux_zero_point']) * float(self.scoring['exposure_zero_point_seconds'])
        if self.norm <= 0:
            raise ValueError('Invalid exposure normalization')
        self.history = {}  # observe index -> only public observations plus our prediction
        self.invalidated_indices = set()
        self.pending = None
        self.best_score, self.best_factor, self.best_factor_upper = {}, {}, {}
        self.latest_bulletin = self.latest_forecast = None
        self._last_state = None
        self._resync_seen = set()
        self._processed_observations = set()
        self._quality_samples = []
        self._score_checkpoint = {}
        self._score_checkpoint_after = -1
        self._unknown_factor_targets = set()

    def record_action(self, action, prediction=None):
        if self.pending is not None:
            raise ValueError('Previous action has not received public feedback')
        item = deepcopy(action)
        # ``type`` is an internal planner field; the actual protocol uses action.
        kind = item.get('action', item.get('type'))
        self.pending = {'action': item, 'kind': kind, 'prediction': deepcopy(prediction),
                        'quality_prior': (self._last_state or {}).get('quality_estimate', self.scoring.get('q0', .68)),
                        'now_utc': (self._last_state or {}).get('now_utc'),
                        'end_utc': (self._last_state or {}).get('end_utc')}

    def _bounds(self, tid, score, program):
        """Unknown actual program band gives a finite set of possible bonuses."""
        weight = self.targets[tid]['science_weight']
        if weight <= 0:
            return 0., 1.
        cfg = self.scoring['program']
        selected = float(cfg['multipliers'].get(program, cfg['multipliers']['BACKUP']))
        mismatch = float(cfg.get('mismatch_multiplier', 1.))
        lo_multiplier, hi_multiplier = min(selected, mismatch), max(selected, mismatch)
        if lo_multiplier <= 0:
            raise ValueError('Program multipliers must be positive')
        lower = min(1., max(0., score / weight / hi_multiplier))
        upper = min(1., max(lower, score / weight / lo_multiplier))
        return lower, upper

    def _predicted_factor(self, prediction, tid):
        if not prediction:
            return None
        factors = prediction.get('factors', {})
        if isinstance(factors, dict):
            return _finite(factors.get(tid))
        indices = prediction.get('target_indices', [])
        for index, factor in zip(indices, factors):
            if 0 <= int(index) < len(self.target_order) and self.target_order[int(index)] == tid:
                return _finite(factor)
        return None

    def _observation(self, result, payload, notes):
        raw_index = result.get('observe_index')
        if raw_index is None:
            count = payload.get('observe_action_index')
            raw_index = count - 1 if isinstance(count, int) and count > 0 else None
        if not isinstance(raw_index, int) or isinstance(raw_index, bool) or raw_index < 0:
            notes.append('Observation lacks a valid public observe_index; progress not guessed.')
            self.pending = None
            return
        if raw_index in self._processed_observations:
            return
        self._processed_observations.add(raw_index)
        pending, self.pending = self.pending, None
        if pending is None or pending['kind'] != 'observe':
            notes.append('Observation has no recorded action; factor bounds use all possible program bonuses.')
            pending = {'action': {}, 'prediction': None, 'quality_prior': self.scoring.get('q0', .68),
                       'now_utc': None, 'end_utc': None}
        action = pending['action']
        program = action.get('program', 'BACKUP')
        assigned = action.get('assignments')
        duration = _finite(action.get('duration_seconds'), 0.)
        if duration and pending['now_utc'] and pending['end_utc']:
            duration = max(0., min(duration, _time(pending['end_utc']) - _time(pending['now_utc'])))
        hits, quality_bands = {}, []
        for hit in result.get('hits', []):
            tid, score = str(hit.get('target_id')), _finite(hit.get('score'))
            if tid not in self.targets or score is None or score < 0:
                notes.append('Ignored malformed public hit.')
                continue
            if assigned is not None and tid not in {str(t) for t in assigned.values()}:
                notes.append('Ignored a hit absent from the recorded assignments.')
                continue
            lower, upper = self._bounds(tid, score, program)
            if not action:
                possibilities = [self._bounds(tid, score, p) for p in self.scoring['program']['multipliers']]
                lower, upper = min(x[0] for x in possibilities), max(x[1] for x in possibilities)
            # Extra fields such as a synthetic `factor` or `quality` are ignored.
            hits[tid] = {'score': score, 'factor_lower': lower, 'factor_upper': upper}
            # A saturated or possibly saturated score provides no upper q bound.
            if upper >= 1. - 1e-9 or self.targets[tid]['science_weight'] <= 0:
                continue
            expected = self._predicted_factor(pending['prediction'], tid)
            if expected is not None and 1e-9 < expected < 1. - 1e-9:
                baseline = float(pending['quality_prior'])
                quality_bands.append((baseline * lower / expected, baseline * upper / expected))
            elif duration > 0 and self.targets[tid]['feature_flux'] > 0:
                # Without a candidate prediction, use a labelled approximate
                # zenith correction from our commanded pointing, never truth.
                altitude = _finite(action.get('pointing', {}).get('alt_deg'), 90.)
                geometric = max(.05, math.sin(math.radians(altitude))) ** float(self.scoring.get('airmass_exponent', .6))
                scale = self.norm / (self.targets[tid]['feature_flux'] * duration * geometric)
                quality_bands.append((scale * lower, scale * upper))
        quality = None
        if quality_bands:
            qlo = statistics.median(q[0] for q in quality_bands)
            qhi = statistics.median(q[1] for q in quality_bands)
            quality = {'lower': qlo, 'upper': qhi, 'time': payload['now_utc'], 'observe_index': raw_index}
            self._quality_samples.append(quality)
        self.history[raw_index] = {'hits': hits, 'quality': quality, 'program': program}
        if raw_index in self.invalidated_indices:
            self.history.pop(raw_index, None)
        else:
            self._merge_record(raw_index, self.history[raw_index])

    def _merge_record(self, index, record):
        for tid, hit in record['hits'].items():
            if index > self._score_checkpoint_after:
                self.best_score[tid] = max(self.best_score.get(tid, 0.), hit['score'])
            self.best_factor[tid] = max(self.best_factor.get(tid, 0.), hit['factor_lower'])
            self.best_factor_upper[tid] = max(self.best_factor_upper.get(tid, 0.), hit['factor_upper'])

    def _rebuild(self):
        self.best_score = dict(self._score_checkpoint)
        self.best_factor = {tid: 0. for tid in self._unknown_factor_targets}
        self.best_factor_upper = {tid: 1. for tid in self._unknown_factor_targets}
        for index, record in self.history.items():
            self._merge_record(index, record)

    def _resync(self, message, notes):
        window = message.get('invalidated_window', {})
        start, end = window.get('action_index_start'), window.get('action_index_end_exclusive')
        if isinstance(start, int) and isinstance(end, int) and 0 <= start <= end:
            self.invalidated_indices.update(range(start, end))
            for index in range(start, end):
                self.history.pop(index, None)
        else:
            # We cannot identify surviving exposure factors safely.
            self.history.clear()
            self._quality_samples.clear()
            notes.append('Resync lacks a valid invalidated_window; factor memory cleared conservatively.')
        self._rebuild()
        authoritative = {}
        for row in message.get('best_scores', []):
            tid, score = str(row.get('target_id')), _finite(row.get('best_score'))
            if tid in self.targets and score is not None and score >= 0:
                authoritative[tid] = score
        # Official surviving scores replace our maxima, rather than merge them.
        self.best_score = authoritative
        self._score_checkpoint = dict(authoritative)
        self._score_checkpoint_after = max(self._processed_observations, default=-1)
        self.best_factor = {tid: self.best_factor.get(tid, 0.) for tid in authoritative}
        self.best_factor_upper = {tid: self.best_factor_upper.get(tid, 1.) for tid in authoritative}
        for record in self.history.values():
            record['hits'] = {tid: h for tid, h in record['hits'].items() if tid in authoritative}
        known_targets = {t for r in self.history.values() for t in r['hits']}
        self._unknown_factor_targets = set(authoritative) - known_targets
        if self._unknown_factor_targets:
            notes.append('Some resynced targets lack local exposure history; their completion remains unknown.')
        notes.append('Applied authoritative score resync; completion uses surviving exposure bounds only.')

    def _quality(self, now):
        prior = max(0., float(self.scoring.get('q0', .68)))
        uncertainty = max(.2, .4 * prior)
        valid = [s for s in self._quality_samples if s['observe_index'] not in self.invalidated_indices]
        if valid:
            sample = valid[-1]
            age = max(0., _time(now) - _time(sample['time']))
            confidence = math.exp(-age / 3600.)
            observed = (sample['lower'] + sample['upper']) / 2
            prior = confidence * observed + (1 - confidence) * prior
            uncertainty = max(.1, (sample['upper'] - sample['lower']) / 2 + (1 - confidence) * .3)
        # Only ALL-direction notices affect the global scalar. Directional
        # semantics remain visible to the LLM/planner without pretending a
        # guessed angular mask or a quantitative official weather report.
        penalties = {'rain': .25, 'snow': .25, 'overcast': .7, 'haze': .8, 'cold_snap': .75}
        for notice in (self.latest_bulletin or {}).get('notices', []):
            if notice.get('direction') == 'ALL' and notice.get('event_kind') in penalties:
                if not valid:
                    prior *= penalties[notice['event_kind']]
                uncertainty = max(uncertainty, .25)
        return max(0., prior), uncertainty

    def update(self, decision_payload):
        payload = deepcopy(decision_payload)
        now = payload['now_utc']
        moment = _time(now)
        notes = ['Completion factors are conservative bounds inferred from public scores.',
                 'Quality is an estimated belief, not published weather truth.']
        result = payload.get('last_result')
        if result and result.get('action') == 'observe':
            self._observation(result, payload, notes)
        elif result is not None:
            self.pending = None
        if 'latest_bulletin' in payload:
            self.latest_bulletin = deepcopy(payload['latest_bulletin'])
        if 'latest_forecast' in payload:
            self.latest_forecast = deepcopy(payload['latest_forecast'])
        for message in payload.get('new_messages', []):
            record = message.get('record_type')
            if record == 'bulletin':
                self.latest_bulletin = deepcopy(message)
            elif record == 'forecast':
                self.latest_forecast = deepcopy(message)
            elif record == 'state_resync':
                key = (message.get('trigger_event_id'), message.get('issued_at_utc'))
                if key not in self._resync_seen:
                    self._resync(message, notes)
                    self._resync_seen.add(key)
        index = next((i for i, n in enumerate(self.nights) if moment < _time(n['observing_end_utc'])), len(self.nights))
        night = self.nights[index] if index < len(self.nights) else None
        quality, uncertainty = self._quality(now)
        threshold = float(self.scoring['required']['observed_factor_threshold'])
        missing = sum(t['required'] and self.best_factor.get(tid, 0.) + 1e-12 < threshold for tid, t in self.targets.items())
        possibly_missing = sum(t['required'] and self.best_factor_upper.get(tid, 0.) + 1e-12 < threshold for tid, t in self.targets.items())
        state = dict(now_utc=now, end_utc=night['observing_end_utc'] if night else self.survey_end,
                     night_id=night.get('night_id') if night else None, night_index=index,
                     remaining_nights=max(0, len(self.nights) - index),
                     in_observing_window=bool(night and _time(night['observing_start_utc']) <= moment < _time(night['observing_end_utc'])),
                     next_night_start_utc=night['observing_start_utc'] if night else None,
                     best_score=dict(self.best_score), best_factor=dict(self.best_factor),
                     best_factor_upper=dict(self.best_factor_upper),
                     quality_estimate=quality, quality_uncertainty=uncertainty,
                     active_requests=deepcopy(payload.get('active_requests', [])),
                     last_result=deepcopy(result), new_messages=deepcopy(payload.get('new_messages', [])),
                     latest_bulletin=deepcopy(self.latest_bulletin), latest_forecast=deepcopy(self.latest_forecast),
                     required_missing=missing, required_definitely_missing=possibly_missing,
                     running_science_score=payload.get('running_total'), wallclock=deepcopy(payload.get('wallclock', {})),
                     observe_action_index=payload.get('observe_action_index'),
                     note=' '.join(notes), diagnostics=notes)
        self._last_state = {key: state[key] for key in ('quality_estimate', 'quality_uncertainty', 'now_utc', 'end_utc')}
        return state
