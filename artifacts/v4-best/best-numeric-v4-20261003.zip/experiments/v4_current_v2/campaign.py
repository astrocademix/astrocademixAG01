"""Deadline-bounded adaptive development campaign, one training seed.

Each job has its own immutable configuration and output directory. Failed or
partial seasons never win promotion. Weather episodes used for final confirmation
are not used to choose the strategy, prompt, or checkpoint.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time
import zipfile

from .common import CARDS, SCOPE, atomic_json
from .queue import Queue, idle_gpus


def case_key(row):
    return row['card'], int(row['episode']), row.get('weather_profile', 'nominal')


def rankings(rows, baseline_id='reference'):
    """Paired deltas only; no comparing averages across different task mixes."""
    rows=list({(r['config_id'],case_key(r)):r for r in rows}.values())
    reference = {case_key(r): r for r in rows if r['config_id'] == baseline_id
                 and r.get('survey_complete') and not r.get('invalid_assignments')}
    groups = {}
    for row in rows:
        groups.setdefault(row['config_id'], []).append(row)
    output = []
    for name, group in groups.items():
        # Deduplicate a repeated case by job id; caller uses distinct phases.
        deltas = []
        failures = 0
        for row in group:
            if not row.get('survey_complete') or row.get('invalid_assignments'):
                failures += 1
                continue
            baseline = reference.get(case_key(row))
            if baseline is not None:
                deltas.append(float(row['proxy_total'])-float(baseline['proxy_total']))
        if deltas:
            mean = statistics.mean(deltas)
            deviation = statistics.pstdev(deltas)
            output.append(dict(config_id=name, pairs=len(deltas), mean_delta=mean,
                worst_delta=min(deltas), variation=deviation, failures=failures,
                promotion_value=mean-.25*deviation-10000*failures))
    return sorted(output, key=lambda r: (-r['promotion_value'], r['config_id']))


def viable_agent(row):
    a = row.get('agent') or {}
    return (row.get('survey_complete') and not row.get('invalid_assignments')
            and a.get('valid_group_plans', 0) > 0 and a.get('interpretations', 0) > 0
            and a.get('changed_group_plans', 0) > 0)


class Campaign(Queue):
    def __init__(self, args):
        self.deadline = datetime.fromisoformat(args.deadline.replace('Z', '+00:00')).timestamp()
        if self.deadline <= time.time()+300:
            raise ValueError('Campaign deadline must leave at least five minutes')
        self.selection_cutoff = self.deadline - 2*3600
        self.finalizing_cutoff = self.deadline - 10*60
        self.jobs = []; self.failures = []; self.configs = {}; self.counter = 0
        self.current_jobs = {}; self.decision_log = []; self.frozen = None
        super().__init__(args)
        self.eta = datetime.fromtimestamp(self.deadline, timezone.utc).isoformat()
        atomic_json(self.run/'plan.json', dict(deadline_utc=self.eta,
            training_seed=17, previous_run=args.previous_run, scope=SCOPE,
            stages=['wait_previous','tests','calibration_and_planning_screen',
                    'original_data_learning','multi_domain_collection','multi_domain_learning',
                    'robust_numeric_selection','agent_prompt_screen','agent_full_card_selection',
                    'additional_paired_weather_cases_until_selection_cutoff',
                    'freeze_selection','unseen_episode_confirmation','package_and_report'],
            selection_cutoff_utc=datetime.fromtimestamp(self.selection_cutoff, timezone.utc).isoformat(),
            max_concurrent_numeric_jobs=2,max_concurrent_api_jobs=1,
            final_confirmation_episodes=[100,101], official_score=None))

    def remaining(self, final=False):
        return (self.finalizing_cutoff if final else self.selection_cutoff)-time.time()

    def status(self, stage):
        self.stage=stage
        atomic_json(self.run/'status.json', dict(stage=stage,pid=os.getpid(),
            elapsed_seconds=time.monotonic()-self.start,completed=len(self.results),
            failures=len(self.failures),running=self.current_jobs,deadline_utc=self.eta,
            official_score=None))
        self.report()
        print(json.dumps(dict(stage=stage,completed=len(self.results),failures=len(self.failures))),flush=True)

    def decision(self, text, **data):
        entry=dict(utc=datetime.now(timezone.utc).isoformat(),decision=text,**data)
        self.decision_log.append(entry)
        atomic_json(self.run/'selection_decisions.json',self.decision_log)

    def report(self):
        lines=['# 10月3日18:00 截止的 v4 改进实验','',
            '**以下全部是开发代理分；未用官方运行器或云端评分验证。**','',
            f'- 阶段：`{self.stage}`',f'- 截止 UTC：{self.eta}',
            f'- 完成运行：{len(self.results)}；失败：{len(self.failures)}',
            '- 单训练种子17；天气情景变化用于配对评估，不是多训练种子。',
            '- 旧队列完整保留；只管理此队列启动的进程。',
            '- 16:00 北京时间冻结方案，预留两小时独立情景确认与打包。','',
            '|阶段|方案|卡|天气/episode|代理总分|必做缺失|科学含加成|全季|秒|',
            '|---|---|---|---|---:|---:|---:|---|---:|']
        for r in self.results:
            lines.append(f"|{r['phase']}|{r['config_id']}|{r['card']}|{r.get('weather_profile')}/{r['episode']}|{r['proxy_total']:.2f}|{r['required_missing']}|{r['science_with_program_bonus']:.2f}|{r['survey_complete']}|{r['wall_seconds']:.1f}|")
        lines += ['', '## 方法与选择记录', '']
        for d in self.decision_log:
            lines.append('- '+d['decision'])
        if self.frozen:
            lines += ['', '## 冻结的最终方案', '', '```json', json.dumps(self.frozen,ensure_ascii=False,indent=2), '```',
                '最终确认未参与选择；如回退也不会改写冻结记录。']
        if self.failures:
            lines += ['', '## 失败与未完成', '']
            for f in self.failures[-20:]:lines.append(f"- {f.get('job_id','stage')}: {f['error']}")
        lines += ['', '## 查阅结果', '',
            '- `results.json`：每次运行的详细分数与目录。',
            '- `jobs.json`：已排定任务与全部配置；`status.json`：当前运行任务。',
            '- `selection_decisions.json`：筛选依据；`final_confirmation.json`：新情景确认。',
            '- `training/`：训练指标、模型和纯NumPy导出。',
            '- `jobs/<编号>/trajectory.csv`、`actions.jsonl`、`api_trace.jsonl`：实际轨迹和API证据。',
            '- `packages/`：候选Agent项目ZIP及冻结配置，待官方云端复核。',
            '- v4交付是Agent ZIP；trajectory.csv是实验轨迹，不是v3 decisions.csv提交。',
            '- 开发环境共享部分近似几何；多天气结果不能消除模拟器与官方环境的差异。','']
        target=self.run/'RESULTS.md';tmp=self.run/'RESULTS.md.tmp'
        tmp.write_text('\n'.join(lines));tmp.replace(target)

    def config(self, name, **kwargs):
        value=dict(config_id=name,mode='search',strategy='baseline',belief_variant='legacy',
                   agent_variant='baseline',max_api_calls=8,**{})
        value.update(kwargs);self.configs[name]=value
        atomic_json(self.run/'configurations.json',self.configs)
        return value

    def run_job(self, job):
        out=self.run/'jobs'/job['job_id'];out.parent.mkdir(parents=True,exist_ok=True)
        cfg=job['config'];cmd=[sys.executable,'-B','-u','-m','experiments.v4_current_v2.experiment',
            '--cards',self.args.cards,'--out',str(out),'--card',job['card'],
            '--episode',str(job['episode']),'--weather-profile',job['weather_profile'],
            '--wall-limit',str(job['wall_limit'])]
        for key in ('mode','strategy','belief_variant','agent_variant','max_api_calls','checkpoint','shortlist_mode'):
            if key in cfg:cmd += ['--'+key.replace('_','-'),str(cfg[key])]
        if cfg.get('learning_variant'):cmd+=['--learning-variant']
        if job.get('collect'):cmd+=['--collect','--collection-samples','4','--collection-duration','180']
        try:
            timeout=min(job['wall_limit']+90,max(1,self.deadline-time.time()-30))
            self.command(cmd,out.with_suffix('.log'),timeout=timeout)
            result=json.loads((out/'result.json').read_text())
            result.update(job_id=job['job_id'],config_id=cfg['config_id'],phase=job['phase'],artifact_directory=str(out))
            return result,None
        except Exception as exc:
            return None,dict(job_id=job['job_id'],phase=job['phase'],error=str(exc),log=str(out.with_suffix('.log')))

    def matrix(self, phase, configs, cases, workers=2, collect=False, final=False, until=None):
        self.status(phase);phase_results=[]
        configs=list({c['config_id']:c for c in configs}.values())
        pending=[]
        # Cases outermost: the reference for a case runs before contenders.
        for card,episode,profile in cases:
            for cfg in configs:
                self.counter+=1
                job=dict(job_id=f'{self.counter:04d}-{cfg["config_id"]}-{card}-e{episode}-{profile}',
                    phase=phase,config=cfg,card=card,episode=episode,weather_profile=profile,
                    wall_limit=1800 if collect else 900,collect=collect,state='queued')
                self.jobs.append(job);pending.append(job)
        atomic_json(self.run/'jobs.json',self.jobs)
        for offset in range(0,len(pending),workers):
            batch=pending[offset:offset+workers]
            available=self.remaining(final=final)
            if until is not None:available=min(available,until-time.time())
            if available<max(j['wall_limit'] for j in batch)+100:
                for job in pending[offset:]:job['state']='not_started_deadline_reserve'
                self.decision(f'{phase} 达到预留时间，余下任务未启动。')
                break
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures={}
                for j in batch:
                    j['state']='running';self.current_jobs[j['job_id']]=dict(config=j['config']['config_id'],card=j['card'],phase=phase)
                    futures[pool.submit(self.run_job,j)]=j
                self.status(phase)
                for future in as_completed(futures):
                    j=futures[future];row,error=future.result();self.current_jobs.pop(j['job_id'],None)
                    if error:
                        j['state']='failed';self.failures.append(error)
                    else:
                        j['state']='complete' if row['survey_complete'] else 'partial'
                        self.results.append(row);phase_results.append(row)
                    atomic_json(self.run/'results.json',self.results)
                    atomic_json(self.run/'failures.json',self.failures)
                    atomic_json(self.run/'jobs.json',self.jobs)
                    self.status(phase)
        atomic_json(self.run/'jobs.json',self.jobs)
        return phase_results

    def promote(self, rows, count=2, baseline_id='reference', agents_only=False, expected_cases=None):
        ranked=rankings(rows,baseline_id)
        atomic_json(self.run/(self.stage+'-ranking.json'),ranked)
        expected=set(expected_cases or [])
        baseline_cases={case_key(r) for r in rows if r['config_id']==baseline_id and r.get('survey_complete') and not r.get('invalid_assignments')}
        if not expected or not expected.issubset(baseline_cases):
            self.decision('参考方案未完整覆盖预定配对情景，保留此前方案，不从有利子集晋级。',ranking=ranked)
            return []
        chosen=[]
        for item in ranked:
            name=item['config_id']
            eligible=item['failures']==0 and item['pairs']==len(expected) and len(expected)>0
            eligible=eligible and (name==baseline_id or item['mean_delta']>0)
            if agents_only:
                group=[r for r in rows if r['config_id']==name]
                eligible=eligible and self.configs[name]['mode']=='agent' and all(viable_agent(r) for r in group)
            if eligible:
                chosen.append(self.configs[name])
            if len(chosen)>=count:break
        self.decision('配对筛选完成：'+(', '.join(c['config_id'] for c in chosen) or '暂无通过门槛的候选'),ranking=ranked)
        return chosen

    def train_variants(self, dataset, tag):
        from .learning_variants import VARIANTS
        selected=[]
        for variant in VARIANTS:
            if self.remaining()<300:break
            name=tag+'-'+variant
            out=self.run/'training'/name;out.parent.mkdir(parents=True,exist_ok=True)
            free=sorted(idle_gpus());env=dict(os.environ)
            device='cpu'
            if free:env['CUDA_VISIBLE_DEVICES']=str(free[-1]);device='cuda:0'
            try:
                self.command([sys.executable,'-B','-u','-m','experiments.v4_current_v2.learning_variants',
                    str(dataset),str(out),'--variant',variant,'--device',device,'--seed','17','--epochs','30'],
                    out.with_suffix('.log'),env=env,timeout=min(1800,max(1,self.remaining()-60)))
                selected.append(dict(name=name,path=str(out)))
            except Exception as exc:
                self.failures.append(dict(job_id=name,error=str(exc)))
        return selected

    def start_model_when_available(self):
        # A terminated predecessor may need seconds to release its GPU memory.
        end=min(time.time()+900,self.selection_cutoff-1200)
        while time.time()<end:
            if len(idle_gpus())>=2:
                try:self.start_api();return True
                except Exception as exc:
                    self.stop_api()
                    self.failures.append(dict(job_id='model_load',error=str(exc)))
                    return False
            self.status('waiting_for_two_idle_gpus');time.sleep(30)
        self.decision('无两张空闲GPU，保留现有任务；此次API阶段未能启动。')
        return False

    def package_config(self, config, label):
        root=self.repo/'experiments/v4_current_v2';out=self.run/'packages';out.mkdir(exist_ok=True)
        env=dict(USE_LLM='1',PLANNING_STRATEGY=config['strategy'],BELIEF_VARIANT=config['belief_variant'],
            AGENT_VARIANT=config.get('agent_variant','baseline'),MAX_API_CALLS=str(config.get('max_api_calls',8)))
        with zipfile.ZipFile(out/(label+'.zip'),'x',zipfile.ZIP_DEFLATED) as z:
            z.writestr('experiments/__init__.py','')
            for name in ('__init__.py','common.py','planner.py','public_state.py','memory_variants.py','strategy.py',
                         'learning.py','learning_variants.py','agent.py','agent_variants.py','decision_tools.py','live_agent.py'):
                z.write(root/name,'experiments/v4_current_v2/'+name)
            for p in root.glob('*SKILL*.md'):z.write(p,'experiments/v4_current_v2/'+p.name)
            z.writestr('experiments/v4_online_v1/__init__.py','')
            z.write(self.repo/'experiments/v4_online_v1/api_client.py','experiments/v4_online_v1/api_client.py')
            # api_client imports protocol helpers from model_api; no model loaded by import.
            z.write(self.repo/'experiments/v4_online_v1/model_api.py','experiments/v4_online_v1/model_api.py')
            if config.get('checkpoint'):
                cp=Path(config['checkpoint'])
                if config.get('learning_variant'):
                    for name in ('weights.npz','variant.json'):z.write(cp/name,'weights/'+name)
                    env.update(SKY_WEIGHTS='weights/weights.npz',LEARNING_VARIANT='1')
                else:
                    z.write(cp,'weights.npz');env['SKY_WEIGHTS']='weights.npz'
            z.writestr('requirements.txt','numpy>=1.24,<3\n')
            z.writestr('observer.project.json',json.dumps(dict(protocol='jsonl-v4',
                run=['python3','-u','-m','experiments.v4_current_v2.live_agent'],
                build=['python3','-m','pip','install','-r','requirements.txt'],env=env)))
            z.writestr('experiment_config.json',json.dumps(dict(config=config,scope=SCOPE,cloud_validated=False),indent=2))
        atomic_json(out/(label+'.json'),dict(config=config,cloud_validated=False))

    def execute(self):
        try:
            previous=Path(self.args.previous_run).resolve()
            if not str(previous).startswith('/home/jovyan/huangzy183/'):
                raise ValueError('Previous run is outside user workspace')
            self.status('waiting_for_previous_queue')
            while not any((previous/n).exists() for n in ('complete.json','failed.json')):
                if self.remaining()<3600:raise RuntimeError('Predecessor did not finish with enough campaign time')
                time.sleep(30)
            self.status('unit_tests')
            self.command([sys.executable,'-B','-m','unittest','discover','-s','experiments/v4_current_v2','-t','.',
                          '-p','test_*.py','-v'],self.run/'tests.log',timeout=300)
            # Preserve the strongest complete incumbent, including the actual
            # closed-loop CNN hybrid; do not compare every new idea to a weaker
            # search baseline just because it has a simpler name.
            prior_results=[]
            if (previous/'complete.json').exists():
                prior_results=json.loads((previous/'complete.json').read_text()).get('results',[])
            incumbent_scores={}
            for mode in ('greedy','search','learned'):
                group=[r for r in prior_results if r.get('mode')==mode and r.get('episode')==1
                       and r.get('survey_complete') and not r.get('invalid_assignments')]
                if {r['card'] for r in group}==set(CARDS):
                    incumbent_scores[mode]=sum(r['proxy_total'] for r in group)
            incumbent=max(incumbent_scores,key=incumbent_scores.get) if incumbent_scores else 'search'
            base_options=dict(mode=incumbent)
            if incumbent=='learned':base_options['checkpoint']=str(previous/'training/weights.npz')
            reference=self.config('reference',**base_options)
            self.decision('参考方案取旧队列完整四卡的最佳数值策略：'+incumbent,scores=incumbent_scores)
            calibrated=self.config('calibrated',belief_variant='calibrated',**base_options)
            strategies=[calibrated]+[self.config(name,strategy=name,belief_variant='calibrated',**base_options)
                for name in ('window_rescue','fibre_pack','window_pack')]
            strategies += [self.config(name+'_legacy',strategy=name,belief_variant='legacy',**base_options)
                for name in ('fibre_pack','window_pack')]
            cases=[('alpha',2,'nominal'),('delta',2,'nominal')]
            rows=self.matrix('planning_screen',[reference]+strategies,cases,until=self.deadline-13*3600)
            finalists=self.promote(rows,count=3,expected_cases=cases)
            numeric=next((c for c in finalists if c['config_id']!='reference'),reference)
            self.decision('训练/Agent公共数值工具起点：'+numeric['config_id'])
            models=self.train_variants(previous/'dataset.npz','initial')
            learned=[]
            for model in models:
                cfg=dict(numeric);cfg.pop('config_id')
                cfg.update(mode='learned',checkpoint=model['path'],learning_variant=True)
                learned.append(self.config(model['name'],**cfg))
            initial_configs=list({c['config_id']:c for c in [reference,numeric]+learned}.values())
            rows=self.matrix('initial_learning_screen',initial_configs,cases,until=self.deadline-11*3600)
            learning_winners=self.promote(rows,count=2,expected_cases=cases)
            collection_cases=[(c,episode,profile) for episode,profile in ((4,'nominal'),(5,'adverse'),(6,'variable')) for c in CARDS]
            collector=dict(numeric,mode='search');collector.pop('checkpoint',None);collector.pop('learning_variant',None)
            data_rows=self.matrix('multi_domain_collection',[collector],collection_cases,collect=True,until=self.deadline-9*3600)
            data_files=[Path(r['artifact_directory'])/'dataset.npz' for r in data_rows
                        if r['survey_complete'] and r.get('training_groups',0)>=76]
            expanded_models=[]
            if len(data_files)==len(collection_cases):
                from .experiment import combine_datasets
                combine_datasets([previous/'dataset.npz']+data_files,self.run/'expanded_dataset.npz')
                expanded_models=self.train_variants(self.run/'expanded_dataset.npz','expanded')
            else:
                self.decision('跨域采集不完整，保留初始模型；不使用缺失划分训练。')
            learned2=[]
            for model in expanded_models:
                cfg=dict(numeric);cfg.pop('config_id');cfg.update(mode='learned',checkpoint=model['path'],learning_variant=True)
                learned2.append(self.config(model['name'],**cfg))
            robust=[reference]+[c for c in learned2+finalists+learning_winners if c['config_id']!='reference']
            robust=list({c['config_id']:c for c in robust}.values())
            robust_cases=[(c,10,'nominal') for c in CARDS]
            # Cap stage size: priority methods first, remaining methods still have
            # distinct evidence from the earlier screens.
            robust=robust[:6]
            rows=self.matrix('robust_numeric_selection',robust,robust_cases,until=self.deadline-7*3600)
            promoted=self.promote(rows,count=2,expected_cases=robust_cases)
            numeric=promoted[0] if promoted else numeric
            stress_configs=list({c['config_id']:c for c in [reference,numeric]+promoted}.values())
            stress_cases=[(c,e,p) for e,p in ((11,'adverse'),(12,'variable')) for c in CARDS]
            stress_rows=self.matrix('stress_numeric_selection',stress_configs,stress_cases,until=self.deadline-7*3600)
            stress_winners=self.promote(stress_rows,count=2,expected_cases=stress_cases)
            numeric=stress_winners[0] if stress_winners else numeric
            model_ready=self.start_model_when_available() if self.remaining()>3600 else False
            agent_candidates=[];agent_best=None;agent_gain_proven=False
            if model_ready:
                agent_candidates.append(self.config('agent-existing',mode='agent',
                    checkpoint=str(previous/'training/weights.npz'),agent_variant='baseline',max_api_calls=8))
                for variant in ('event_director','counterfactual_director','compact_skill_director'):
                    cfg=dict(numeric);cfg.pop('config_id');cfg.update(mode='agent',agent_variant=variant,max_api_calls=16)
                    agent_candidates.append(self.config('agent-'+variant,**cfg))
                cases=[('alpha',20,'nominal'),('delta',20,'nominal')]
                # Keep API service serial; never induce busy errors as a test.
                refs=self.matrix('agent_screen_reference',[numeric],cases)
                rows=refs+self.matrix('agent_prompt_screen',agent_candidates,cases,workers=1,until=self.deadline-5*3600)
                # Numeric incumbent is the paired comparator for model contribution.
                selected=self.promote(rows,count=2,baseline_id=numeric['config_id'],agents_only=True,expected_cases=cases)
                if not selected:
                    # Keep best valid integration as an explicit candidate, not
                    # a claimed scoring improvement, so required API role survives.
                    valid=[c for c in agent_candidates if len([r for r in rows if r['config_id']==c['config_id'] and viable_agent(r)])==len(cases)]
                    if valid:
                        ranked=rankings(rows,numeric['config_id']);order={r['config_id']:i for i,r in enumerate(ranked)}
                        selected=sorted(valid,key=lambda c:order.get(c['config_id'],999))[:1]
                        self.decision('Agent尚未证明增益；保留可运行API集成候选，数值最佳另行保留。')
                if selected:
                    cases=[(c,21,p) for p in ('nominal','variable') for c in CARDS]
                    refs=self.matrix('agent_validation_reference',[numeric],cases)
                    rows=refs+self.matrix('agent_full_card_selection',selected,cases,workers=1)
                    winners=self.promote(rows,count=1,baseline_id=numeric['config_id'],agents_only=True,expected_cases=cases)
                    if winners:agent_best=winners[0];agent_gain_proven=True
                    else:
                        eligible=[c for c in selected if len([r for r in rows if r['config_id']==c['config_id'] and viable_agent(r)])==len(cases)]
                        agent_best=eligible[0] if eligible else None
            # Spend available time on paired, previously unused public-weather
            # episodes, not repeated identical runs or extra training seeds.
            contenders=[numeric]+([agent_best] if agent_best else [])
            for episode in range(200,1000):
                if self.remaining()<2200:break
                profile=('nominal','adverse','variable','clear')[((episode-200)//4+(episode-200)%4)%4]
                card=CARDS[(episode-200)%4]
                configs=list({c['config_id']:c for c in [reference]+contenders}.values())
                rows=self.matrix('additional_weather_pairs',configs,[(card,episode,profile)],workers=1 if agent_best else 2)
                self.decision(f'新增配对天气评估 episode={episode}, {card}/{profile}；不重复训练种子。')
                if len(rows)<len(configs):break
            self.frozen=dict(numeric=numeric,agent=agent_best,selection_utc=datetime.now(timezone.utc).isoformat(),
                agent_gain_proven=agent_gain_proven)
            atomic_json(self.run/'frozen_selection.json',self.frozen)
            self.status('final_unseen_episode_confirmation')
            final_cases=[(c,100,'nominal') for c in CARDS]+[(c,101,'variable') for c in CARDS]
            confirmed_candidate=agent_best or numeric
            configs=list({c['config_id']:c for c in [reference,confirmed_candidate]}.values())
            # One complete set is worth more than uneven partial coverage. Start
            # the harder second set only if the deadline still allows it.
            confirmed=[]
            for case in final_cases:
                needed=1000
                if self.remaining(final=True)<needed:break
                confirmed+=self.matrix('final_confirmation',configs,[case],workers=2,final=True)
            atomic_json(self.run/'final_confirmation.json',dict(scope=SCOPE,official_score=None,
                frozen=self.frozen,rows=confirmed,paired_rankings=rankings(confirmed),
                completed_paired_cases=sum(all(any(case_key(r)==case and r['config_id']==c['config_id']
                    and r.get('survey_complete') and not r.get('invalid_assignments') for r in confirmed)
                    for c in configs) for case in final_cases),expected_cases=8))
            self.status('packaging_and_reporting')
            # Numerical package still includes the baseline API director; its
            # numerical score does NOT count as tested API package performance.
            self.package_config(numeric,'numeric-incumbent-with-api-pending-validation')
            if agent_best:self.package_config(agent_best,'agent-candidate')
            atomic_json(self.run/'complete.json',dict(status='complete',scope=SCOPE,official_score=None,
                completed=len(self.results),failures=self.failures,frozen=self.frozen,
                elapsed_seconds=time.monotonic()-self.start,finished_utc=datetime.now(timezone.utc).isoformat()))
            self.status('complete')
        except Exception as exc:
            self.failures.append(dict(job_id='campaign',error=str(exc)))
            atomic_json(self.run/'failed.json',dict(stage=self.stage,error=str(exc)))
            self.status('failed');raise
        finally:
            self.stop_api()
            for p in self.children:
                if p.poll() is None:
                    p.terminate()
                    try:p.wait(timeout=10)
                    except subprocess.TimeoutExpired:p.kill();p.wait()


def main():
    ap=argparse.ArgumentParser()
    for key in ('run','cards','model-dir','previous-run','deadline'):ap.add_argument('--'+key,required=True)
    Campaign(ap.parse_args()).execute()


if __name__=='__main__':main()
