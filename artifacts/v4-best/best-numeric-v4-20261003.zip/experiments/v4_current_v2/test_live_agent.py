"""JSONL contract tests: standard library only; numerical tools are injected."""
import copy
import io
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from .live_agent import LiveAgent, PROTOCOL, run, validate_action, _hybrid_indices
from .test_public_state import initialize as small_initialize, snapshot


def initial_message():
    payload = small_initialize()
    payload['instrument'] = {'n_fibers': 16, 'fiber_area_deg2': .4, 'gap_deg': 0.,
                             'exposure': {'min_duration_seconds': 60, 'max_duration_seconds': 3600}}
    payload['limits'] = {'global_wallclock_seconds': 900, 'response_max_bytes': 524288}
    payload['site'] = {'latitude_deg': -24.6157, 'longitude_deg': -70.3976, 'minimum_altitude_deg': 30.}
    return {'protocol_version': PROTOCOL, 'message_type': 'initialize', 'payload': payload}


def request(sequence=1, payload=None):
    return {'protocol_version': PROTOCOL, 'message_type': 'decision_request', 'decision_sequence': sequence,
            'payload': payload or snapshot(now='2026-10-02T00:00:00Z')}


class FakePlanner:
    def __init__(self, cat):
        self.cat = cat
        self.budgets, self.indices = [], []

    def propose(self, state, controls, max_candidates):
        self.budgets.append(max_candidates)
        return [{'action': {'type': 'observe', 'pointing': {'alt_deg': 60., 'az_deg': 120.},
                            'assignments': {'0': 'a'}, 'duration_seconds': 900+i, 'program': 'BACKUP'},
                 'rate': 10.-i, 'est_gain': float(10-i), 'pointing_ra_deg': 0., 'pointing_dec_deg': 0.,
                 'duration_seconds': 900+i, 'factors': [.5], 'scores': [.53], 'target_indices': [0],
                 'maps': [[[0.]*4 for _ in range(4)] for _ in range(12)], 'scalars': [0.]*12}
                for i in range(10)]

    def teacher_targets(self, candidates, state, controls, indices):
        self.indices.append(list(indices))
        return [float(i) for i in indices]


class FakeDirector:
    def __init__(self, cat, trace_path, max_calls=8):
        self.controls, self.feedback = {}, []
        self.stages, self.triggered = [], False

    def maybe_replan(self, state, candidates):
        if self.triggered:
            return False
        self.triggered = True
        self.stages.extend(['interpret_feedback', 'propose_group_plan'])
        self.controls = {'science_weight': 1.1}
        return True

    def observe_feedback(self, before, candidate, result):
        self.feedback.append(result)

    def summary(self):
        return {'stages': self.stages}


class FakePredictor:
    def predict(self, maps, scalars):
        return list(range(len(maps)))


class LiveAgentTests(unittest.TestCase):
    def session(self, env=None, **kwargs):
        return LiveAgent(environment=env or {'NUMERIC_NO_LLM': '1'}, stderr=io.StringIO(),
                         catalogue_factory=lambda payload: SimpleNamespace(ids=['a', 'b', 'zero']),
                         planner_factory=FakePlanner, **kwargs)

    def test_initialize_is_silent_and_response_sequence_is_exact(self):
        agent = self.session()
        self.assertIsNone(agent.handle(initial_message()))
        response = agent.handle(request(7))
        self.assertEqual(response['decision_sequence'], 7)
        self.assertEqual(response['action'], 'observe')
        self.assertNotIn('type', response)
        self.assertEqual(agent.planner.budgets, [32])
        self.assertEqual(len(agent.planner.indices[0]), 8)

    def test_score_only_feedback_and_resync_remove_completion(self):
        agent = self.session()
        agent.handle(initial_message())
        agent.handle(request())
        feedback = {'action': 'observe', 'observe_index': 0, 'hits': [{'target_id': 'a', 'score': .53}]}
        resync = {'record_type': 'state_resync', 'trigger_event_id': 'loss', 'issued_at_utc': '2026-10-02T00:15:00Z',
                  'invalidated_window': {'action_index_start': 0, 'action_index_end_exclusive': 1},
                  'best_scores': [], 'observed_target_ids': []}
        agent.handle(request(2, snapshot(1, feedback, messages=[resync])))
        self.assertEqual(agent.memory.best_factor, {})
        self.assertEqual(agent.memory.best_score, {})

    def test_jsonl_finish_no_reply_and_stdout_contains_only_json(self):
        agent = self.session()
        messages = [initial_message(), request(), {'protocol_version': PROTOCOL, 'message_type': 'finish', 'payload': {}}]
        input_stream = io.StringIO(''.join(json.dumps(m)+'\n' for m in messages))
        output, errors = io.StringIO(), io.StringIO()
        code = run(input_stream, output, errors, agent)
        self.assertEqual(code, 0)
        rows = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['message_type'], 'decision_response')

    def test_daytime_waits_until_next_night(self):
        agent = self.session()
        agent.handle(initial_message())
        response = agent.handle(request(payload=snapshot(now='2026-10-02T12:00:00Z')))
        self.assertEqual(response['action'], 'wait')
        self.assertEqual(response['until_utc'], '2026-10-03T00:00:00Z')
        self.assertEqual(agent.planner.budgets, [])

    def test_remaining_wallclock_uses_greedy_16(self):
        agent = self.session()
        agent.handle(initial_message())
        p = snapshot(); p['wallclock']['remaining_seconds'] = 40.
        response = agent.handle(request(payload=p))
        self.assertEqual(response['duration_seconds'], 900)
        self.assertEqual(agent.planner.budgets, [16])
        self.assertEqual(agent.planner.indices, [])

    def test_duplicate_sequence_and_boolean_sequence_rejected(self):
        agent = self.session(); agent.handle(initial_message()); agent.handle(request())
        with self.assertRaises(ValueError): agent.handle(request())
        with self.assertRaises(ValueError): agent.handle(request(True))

    def test_neural_hybrid_uses_same_eight_teacher_slots(self):
        agent = self.session({'NUMERIC_NO_LLM': '1', 'SKY_WEIGHTS': 'model.npz'},
                             predictor_loader=lambda *args, **kwargs: FakePredictor())
        agent.handle(initial_message()); agent.handle(request())
        selected = agent.planner.indices[0]
        self.assertEqual(len(set(selected)), 8)
        self.assertEqual(set(selected), {0, 1, 2, 3, 6, 7, 8, 9})
        self.assertEqual(agent.learned_uses, 1)

    def test_two_llm_stages_and_feedback_are_connected(self):
        with tempfile.TemporaryDirectory() as directory:
            agent = self.session({'RUN_LOG_DIR': directory}, director_factory=FakeDirector)
            agent.handle(initial_message()); agent.handle(request())
            feedback = {'action': 'observe', 'observe_index': 0, 'hits': [{'target_id': 'a', 'score': .53}]}
            agent.handle(request(2, snapshot(1, feedback)))
            self.assertEqual(agent.director.stages, ['interpret_feedback', 'propose_group_plan'])
            self.assertEqual(agent.director.feedback[0], feedback)

    def test_missing_credential_is_explicit_fallback(self):
        agent = self.session({'USE_LLM': '1'})
        agent.handle(initial_message())
        self.assertIsNone(agent.director)
        self.assertIn('No model API credential', agent.stderr.getvalue())

    def test_fault_probe_requires_repetition_and_respects_free_allowance(self):
        agent = self.session(); agent.handle(initial_message())
        agent.payload['scoring']['reporting'] = {'false_report_free_allowance': 2}
        candidate = FakePlanner(None).propose({}, {}, 32)[0]
        agent.previous = ({}, candidate)
        feedback = {'action': 'observe', 'hits': [{'target_id': 'a', 'score': .01}]}
        state = {'quality_estimate': .8, 'last_result': feedback, 'latest_bulletin': None}
        self.assertFalse(agent._report_if_needed(state))
        state['quality_estimate'] = .1
        self.assertFalse(agent._report_if_needed(state))
        self.assertFalse(agent._report_if_needed(state))
        self.assertTrue(agent._report_if_needed(state))
        agent.report_false_count = 2
        for _ in range(4): self.assertFalse(agent._report_if_needed(state))

    @unittest.skipUnless(importlib.util.find_spec('numpy') is not None, 'NumPy is required for the real numerical planner')
    def test_real_catalogue_and_planner_one_public_request(self):
        from .planner import local_sidereal_deg
        payload = initial_message()['payload']
        payload['scoring']['required']['penalty_per_missing'] = 50
        payload['scoring']['program']['bands'] = {'DARK': .65, 'BRIGHT': .4}
        payload['scoring']['observation_requests'] = {'completion_factor_threshold': .5}
        when = '2026-10-02T00:00:00Z'
        ra = local_sidereal_deg(when, payload['site']['longitude_deg'])
        dec = payload['site']['latitude_deg']
        payload['targets'] = {'columns': ['target_id', 'ra_deg', 'dec_deg', 'target_class', 'feature_flux', 'science_weight', 'required'],
                              'rows': [['a', ra, dec, 'Star', .5, 1., True],
                                       ['b', (ra+.2)%360, dec+.2, 'Star', 1., 2., False]]}
        agent = LiveAgent(environment={'NUMERIC_NO_LLM': '1'}, stderr=io.StringIO())
        agent.handle({'protocol_version': PROTOCOL, 'message_type': 'initialize', 'payload': payload})
        data = snapshot(now=when); data['wallclock']['remaining_seconds'] = 40.
        response = agent.handle(request(payload=data))
        self.assertEqual(response['action'], 'observe')
        self.assertGreater(len(response['assignments']), 0)
        self.assertEqual(agent.tool_errors, 0)

    def test_invalid_action_unknown_fields_and_fiber_aliases_rejected(self):
        payload = initial_message()['payload']; state = {'now_utc': '2026-10-02T00:00:00Z'}
        with self.assertRaises(ValueError):
            validate_action({'action': 'report', 'invented': True}, state, payload)
        command = FakePlanner(None).propose({}, {}, 32)[0]['action']
        command['assignments'] = {'0': 'a', '00': 'b'}
        with self.assertRaises(ValueError): validate_action(command, state, payload)
        with self.assertRaises(ValueError):
            validate_action({'action': 'wait', 'duration_seconds': True}, state, payload)
        with self.assertRaises(ValueError):
            validate_action({'action': 'wait', 'until_utc': '2026-10-01T00:00:00Z'}, state, payload)

    def test_bad_input_exits_nonzero_without_fabricating_response(self):
        output, errors = io.StringIO(), io.StringIO()
        self.assertEqual(run(io.StringIO('{"x":NaN}\n'), output, errors, self.session()), 2)
        self.assertEqual(output.getvalue(), '')
        self.assertIn('Fatal', errors.getvalue())


if __name__ == '__main__':
    unittest.main()
