"""Causal interface checks: model choices survive proposal and shortlist gates."""
from copy import deepcopy
import json
from pathlib import Path
import unittest

from .agent_variants import make_agent, AGENT_VARIANTS
from .test_agent import ScriptedClient, trace_directory
from .test_planner import fixture
from .planner import Planner


DIAGNOSIS = {'condition': 'uncertain', 'priority': 'required_windows'}
PLAN = dict(DIAGNOSIS, tool='joint_search', groups=['G0'], reason='Close reachable required window')


class AgentVariantTests(unittest.TestCase):
    def setup_state(self):
        cat, state = fixture()
        state.update(night_index=0, required_missing=2, observe_action_index=0, new_messages=[])
        candidates = Planner(cat).propose(state, {}, max_candidates=8)
        return cat, state, candidates

    def test_factory_has_baseline_and_three_executable_variants(self):
        cat, state, candidates = self.setup_state()
        for variant in AGENT_VARIANTS:
            with self.subTest(variant=variant), trace_directory() as directory:
                agent = make_agent(cat, directory/'trace.jsonl', variant=variant, client=ScriptedClient([]))
                self.assertEqual(agent.calls, 0)
        with self.assertRaises(ValueError):
            make_agent(cat, Path('unused'), variant='not-a-policy')

    def test_model_selected_low_rate_group_enters_numerical_shortlist(self):
        cat, state, candidates = self.setup_state()
        # Three different legal known-target groups with ranking intentionally
        # separated. Only the LLM's group selection may bring c into k=2.
        items = []
        for tid, rate in [('a', 10.), ('b', 8.), ('c', .1)]:
            item = deepcopy(candidates[0]); item['rate'] = rate
            item['action']['assignments'] = {'0': tid}
            item['required_gain'] = 50. if tid == 'c' else 0.
            item['science_gain'] = rate; item['request_gain'] = 0.
            items.append(item)
        with trace_directory() as directory:
            client = ScriptedClient([])
            agent = make_agent(cat, directory/'trace.jsonl', variant='compact_skill_director', client=client)
            menu = agent._groups(state, items)
            wanted = next(row['id'] for row in menu if row['examples'] == ['c'])
            client.responses = iter([dict(PLAN, groups=[wanted], tool='secure_completion')])
            self.assertTrue(agent.maybe_replan(state, items))
            indices = agent.shortlist_indices(items, k=2).tolist()
            self.assertIn(2, indices)
            self.assertIn(0, indices)
            self.assertEqual(len(set(indices)), 2)
            self.assertIn('c', agent.controls['priority_targets'])
            self.assertEqual(agent.controls['horizon'], 2)
            self.assertEqual(agent.summary()['outside_top_rate_candidates_admitted'], 1)

    def test_invalid_group_is_repaired_with_original_tool_error(self):
        cat, state, candidates = self.setup_state()
        with trace_directory() as directory:
            client = ScriptedClient([dict(PLAN, groups=['MADE_UP']), PLAN])
            agent = make_agent(cat, directory/'trace.jsonl', variant='compact_skill_director', client=client)
            self.assertTrue(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.errors, 1)
            self.assertEqual(agent.valid_plans, 1)
            repaired = json.loads(client.messages[-1][1]['content'])
            self.assertEqual(repaired['tool_error']['rejected_proposal']['groups'], ['MADE_UP'])
            self.assertEqual(agent.calls, 2)

    def test_new_request_replans_before_night_checkpoint_and_feedback_reaches_model(self):
        cat, state, candidates = self.setup_state()
        with trace_directory() as directory:
            client = ScriptedClient([DIAGNOSIS, PLAN, DIAGNOSIS, dict(PLAN, tool='fast_science')])
            agent = make_agent(cat, directory/'trace.jsonl', variant='event_director', client=client)
            agent.maybe_replan(state, candidates)
            self.assertFalse(agent.maybe_replan(state, candidates))
            agent.observe_feedback(state, candidates[0], dict(action='observe', hits=[]))
            state['active_requests'] = [dict(request_id='R1', target_ids=['a'], minimum_completed=1,
                completed_target_ids=[], deadline_utc=state['end_utc'], completion_reward=100.)]
            self.assertTrue(agent.maybe_replan(state, candidates))
            context = json.loads(client.messages[-1][1]['content'])
            self.assertEqual(context['trigger'], 'new_request')
            self.assertEqual(context['feedback'][0]['hit_fraction'], 0.)
            self.assertEqual(agent.revisions, 1)
            self.assertEqual(agent.controls['horizon'], 1)

    def test_resync_context_never_serializes_private_or_massive_tables(self):
        cat, state, candidates = self.setup_state()
        state['new_messages'] = [dict(record_type='state_resync', trigger_event_id='E1',
            invalidated_window={'action_index_start': 0, 'action_index_end_exclusive': 3},
            best_scores=[{'target_id': 'a', 'best_score': 1.}] * 20000,
            hidden_quality='NEVER_SERIALIZE')]
        state['hidden_truth'] = {'future_weather': 'NEVER_SERIALIZE'}
        with trace_directory() as directory:
            client = ScriptedClient([PLAN])
            agent = make_agent(cat, directory/'trace.jsonl', variant='compact_skill_director', client=client)
            agent.maybe_replan(state, candidates)
            content = client.messages[0][1]['content']
            self.assertNotIn('NEVER_SERIALIZE', content)
            self.assertNotIn('best_scores', content)
            self.assertLess(len(content), 11000)
            self.assertIn('invalidated_window', content)
            self.assertIn('whole_sky', content)

    def test_counterfactual_keeps_valid_proposal_when_critic_changes_policy(self):
        cat, state, candidates = self.setup_state()
        with trace_directory() as directory:
            client = ScriptedClient([PLAN, dict(PLAN, tool='fast_science')])
            agent = make_agent(cat, directory/'trace.jsonl', variant='counterfactual_director', client=client)
            self.assertTrue(agent.maybe_replan(state, candidates))
            self.assertIn('proposed_plan', json.loads(client.messages[-1][1]['content']))
            self.assertEqual(agent.controls['horizon'], 1)
            self.assertEqual(agent.calls, 2)
            self.assertEqual(agent.interpretations, 1)

    def test_call_budget_includes_repairs(self):
        cat, state, candidates = self.setup_state()
        with trace_directory() as directory:
            client = ScriptedClient([dict(PLAN, groups=['wrong'])])
            agent = make_agent(cat, directory/'trace.jsonl', variant='compact_skill_director', client=client, max_calls=1)
            self.assertFalse(agent.maybe_replan(state, candidates))
            self.assertFalse(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.calls, 1)
            self.assertEqual(agent.valid_plans, 0)

    def test_forecast_nights_and_initial_terrain_survive_in_context(self):
        cat, state, candidates = self.setup_state()
        state['latest_bulletin'] = dict(initial=True, notices=[
            dict(event_kind='terrain_obstruction', direction='SW')])
        with trace_directory() as directory:
            client = ScriptedClient([PLAN, PLAN])
            agent = make_agent(cat, directory/'trace.jsonl', variant='compact_skill_director', client=client)
            agent.maybe_replan(state, candidates)
            state['latest_bulletin'] = dict(initial=False, notices=[])
            state['new_messages'] = [dict(record_type='forecast', issued_at_utc=state['now_utc'],
                notices=[dict(event_kind='rocket_launch', direction='NW', nights=['2026-10-06'])])]
            agent.maybe_replan(state, candidates)
            context = json.loads(client.messages[-1][1]['content'])
            self.assertEqual(context['trigger'], 'new_event_forecast')
            self.assertEqual(context['new_messages'][0]['notices'][0]['nights'], ['2026-10-06'])
            self.assertEqual(context['persistent_initial_notices'][0]['event_kind'], 'terrain_obstruction')

    def test_ra_band_can_anchor_known_targets_absent_from_group_menu(self):
        cat, state, candidates = self.setup_state()
        cat.ra[2] += 10.
        band = int(cat.ra[2] // 10)
        candidates = [deepcopy(candidates[0])]
        candidates[0]['action']['assignments'] = {'0': 'a'}
        with trace_directory() as directory:
            client = ScriptedClient([dict(PLAN, ra_band=band)])
            agent = make_agent(cat, directory/'trace.jsonl', variant='compact_skill_director', client=client)
            self.assertTrue(agent.maybe_replan(state, candidates))
            self.assertIn('c', agent.controls['priority_targets'])
            self.assertEqual(agent.controls['focus_ra_deg'], 10. * band + 5.)

    def test_repeated_early_weather_cannot_exhaust_season_calls(self):
        cat, state, candidates = self.setup_state()
        state['remaining_nights'] = 38
        with trace_directory() as directory:
            client = ScriptedClient([DIAGNOSIS, PLAN] * 40)
            agent = make_agent(cat, directory/'trace.jsonl', variant='event_director', client=client, max_calls=16)
            agent.maybe_replan(state, candidates)
            for night in range(6):
                state.update(night_index=night, remaining_nights=38-night)
                for event in ('haze', 'overcast', 'haze', 'overcast'):
                    state['observe_action_index'] += 4
                    state['latest_bulletin'] = {'notices': [{'event_kind': event, 'direction': 'ALL'}]}
                    agent.maybe_replan(state, candidates)
            self.assertLessEqual(agent.calls, 3)
            self.assertEqual(agent._emergency_calls, 0)
            before = agent.calls
            state.update(night_index=24, remaining_nights=14)
            state['observe_action_index'] += 4
            agent.maybe_replan(state, candidates)
            self.assertGreater(agent.calls, before)

    def test_requests_and_weather_leave_calls_for_late_resync(self):
        cat, state, candidates = self.setup_state()
        state['remaining_nights'] = 38
        with trace_directory() as directory:
            client = ScriptedClient([DIAGNOSIS, PLAN] * 60)
            agent = make_agent(cat, directory/'trace.jsonl', variant='event_director', client=client, max_calls=16)
            for night in range(38):
                state.update(night_index=night, remaining_nights=38-night)
                state['active_requests'] = [{'request_id': 'R'+str(night), 'target_ids': ['a'],
                    'minimum_completed': 1, 'deadline_utc': state['end_utc'], 'completion_reward': 100.}]
                for event in ('haze', 'overcast'):
                    state['observe_action_index'] += 4
                    state['latest_bulletin'] = {'notices': [{'event_kind': event, 'direction': 'ALL'}]}
                    agent.maybe_replan(state, candidates)
            self.assertLessEqual(agent.calls, 14)
            self.assertLessEqual(agent._emergency_calls, 2)
            before = agent.calls
            state['new_messages'] = [{'record_type': 'state_resync', 'trigger_event_id': 'late-loss',
                'invalidated_window': {'action_index_start': 10, 'action_index_end_exclusive': 20}}]
            agent.maybe_replan(state, candidates)
            self.assertEqual(agent.calls, before+2)
            self.assertEqual(agent.summary()['replan_triggers']['state_resync'], 1)
            self.assertLessEqual(agent.calls, 16)

    def test_invalid_repair_does_not_spend_reserved_calls_and_tiny_budget_starts(self):
        cat, state, candidates = self.setup_state()
        state['remaining_nights'] = 38
        with trace_directory() as directory:
            bad = dict(PLAN, groups=['invalid'])
            client = ScriptedClient([DIAGNOSIS, bad, bad])
            agent = make_agent(cat, directory/'trace.jsonl', variant='event_director', client=client, max_calls=16)
            self.assertFalse(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.calls, 3)
            self.assertEqual(agent._emergency_calls, 0)
        with trace_directory() as directory:
            agent = make_agent(cat, directory/'trace.jsonl', variant='event_director',
                client=ScriptedClient([DIAGNOSIS, PLAN]), max_calls=2)
            self.assertTrue(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.calls, 2)


if __name__ == '__main__':
    unittest.main()
