import unittest
from .memory_variants import CalibratedPublicState
from .test_public_state import initialize, snapshot, action


class CalibrationTests(unittest.TestCase):
    def test_real_update_preserves_uncertainty_for_prediction_reference(self):
        m=CalibratedPublicState(initialize());s=m.update(snapshot())
        m.record_action(action(), {'target_indices':[0], 'factors':[.4]})
        self.assertGreater(s['quality_uncertainty'], 0.)
        self.assertAlmostEqual(m.pending['quality_prior'],s['quality_estimate']-.5*s['quality_uncertainty'])

    def test_conservative_prediction_reference_is_not_amplified(self):
        m = CalibratedPublicState(initialize())
        m.update(snapshot(now='2026-10-02T00:00:00Z'))
        m._last_state.update(quality_estimate=1., quality_uncertainty=.4)
        m.record_action(action(), {'target_indices': [0], 'factors': [.4]})
        # True factor .5, BACKUP match. Q lower = .8 * .5/.4 = 1.
        state=m.update(snapshot(1, {'action':'observe', 'observe_index':0,
            'hits':[{'target_id':'a', 'score':.53, 'quality':999.}]}))
        self.assertAlmostEqual(m._quality_samples[-1]['lower'], 1.)
        self.assertAlmostEqual(state['best_factor']['a'], .5)

    def test_explicit_reference_and_saturation(self):
        m=CalibratedPublicState(initialize());m.update(snapshot())
        m.record_action(action(), {'target_indices':[0], 'factors':[.4], 'quality_reference':.7})
        self.assertEqual(m.pending['quality_prior'], .7)
        m.update(snapshot(1, {'action':'observe', 'observe_index':0,
            'hits':[{'target_id':'a','score':1.06}]}))
        self.assertEqual(m._quality_samples, [])

if __name__ == '__main__': unittest.main()
