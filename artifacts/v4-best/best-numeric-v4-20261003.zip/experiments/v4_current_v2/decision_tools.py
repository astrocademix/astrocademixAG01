"""The identical bounded wait tool in development rollouts and deployed agent."""
from copy import deepcopy
from .common import timestamp, utc
from .planner import equatorial_to_horizontal


def checked_wait(planner, catalogue, state, chosen, controls, step, wall_remaining):
    wait=int(controls.get('wait_seconds',0))
    if not (60<=wait<=900 and step%12==0 and wall_remaining>120
            and timestamp(state['now_utc'])+wait+60<timestamp(state['end_utc'])):
        return False,False
    future=dict(state,now_utc=utc(timestamp(state['now_utc'])+wait))
    alt,az=equatorial_to_horizontal(chosen['pointing_ra_deg'],chosen['pointing_dec_deg'],
        future['now_utc'],catalogue.latitude,catalogue.longitude)
    action=deepcopy(chosen['action']);action['pointing']=dict(alt_deg=float(alt),az_deg=float(az))
    delayed=planner.evaluate_action(action,future)
    accepted=delayed is not None and delayed['est_gain']/(wait+delayed['duration_seconds'])>chosen['rate']*1.12
    return True,bool(accepted)
