"""Learn a bounded-planning candidate shortlist, not an official score model.

The NPZ must contain maps[N,12,4,4], scalars[N,12], target[N], baseline[N],
group_id[N] and split[N].  A group is one complete candidate set; it must not
cross train/validation/test.  metadata_json (a scalar JSON string, alternatively
a .json sidecar) must explain label_definition.  The caller owns stronger
episode/sky-region split isolation; merely grouping candidates cannot prove it.

``train`` uses Torch only at training time.  ``load_predictor(out)`` defaults to
the exported NumPy network and does not import Torch.  Predictions have the same
units as target.  They rank candidates before the exact planning tool; neither
predictions nor teacher regret are competition scores.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import time

import numpy as np

FORMAT = "v4-current-lookahead-shortlist-v1"
SPLITS = ("train", "validation", "test")
MAP_SHAPE = (12, 4, 4)
SCALAR_SHAPE = (12,)


def _plain(value):
    return json.loads(json.dumps(value, allow_nan=False))


def _json_write(path, data):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(_plain(data), stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_dataset(arrays, metadata):
    """Return a validated copy; refuse ambiguous split/group or label meaning."""
    required = ("maps", "scalars", "target", "baseline", "group_id", "split")
    if not all(key in arrays for key in required):
        raise ValueError("dataset is missing required arrays")
    result = {key: np.asarray(arrays[key]) for key in required}
    n = len(result["target"]) if result["target"].ndim else 0
    for key, shape in (("maps", (n,) + MAP_SHAPE), ("scalars", (n,) + SCALAR_SHAPE),
                       ("target", (n,)), ("baseline", (n,))):
        value = result[key]
        if value.shape != shape or value.dtype.kind not in "fiu" or not np.isfinite(value).all():
            raise ValueError(f"invalid shape, dtype or nonfinite values in {key}")
        result[key] = np.asarray(value, dtype=np.float32)
        if not np.isfinite(result[key]).all():
            raise ValueError(f"{key} overflows float32")
    for key in ("group_id", "split"):
        value = result[key]
        if value.shape != (n,) or value.dtype.kind != "U" or np.any(np.char.str_len(value) == 0):
            raise ValueError(f"{key} must be a nonempty unicode vector")
    if set(result["split"].tolist()) != set(SPLITS):
        raise ValueError("dataset must contain exactly train, validation and test")
    if not isinstance(metadata, dict) or not isinstance(metadata.get("label_definition"), str) or not metadata["label_definition"].strip():
        raise ValueError("metadata must contain an explicit label_definition")
    if metadata.get("teacher_is_official") is True:
        raise ValueError("this experiment requires a clearly marked surrogate teacher")
    if metadata.get("target_is_residual") is True:
        raise ValueError("target must be complete teacher value, not a residual requiring baseline composition")
    group_split = {}
    for group, split in zip(result["group_id"].tolist(), result["split"].tolist()):
        previous = group_split.setdefault(group, split)
        if previous != split:
            raise ValueError(f"candidate group crosses data splits: {group}")
    groups, sizes = np.unique(result["group_id"], return_counts=True)
    if np.any(sizes < 2):
        raise ValueError("every ranking group must contain at least two candidates")
    result["metadata"] = _plain(metadata)
    return result


def read_dataset(path):
    path = Path(path)
    with np.load(path, allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in archive.files}
    if "metadata_json" in arrays:
        encoded = arrays.pop("metadata_json")
        if encoded.shape != () or encoded.dtype.kind != "U":
            raise ValueError("metadata_json must be a scalar unicode JSON string")
        metadata = json.loads(str(encoded.item()))
    else:
        sidecar = path.with_suffix(".json")
        if not sidecar.is_file():
            raise ValueError("dataset needs metadata_json or a same-stem JSON sidecar")
        metadata = json.loads(sidecar.read_text(encoding="utf-8"))
    return validate_dataset(arrays, metadata)


def fit_normalization(data):
    """Fit *all* statistics on train only, including channels and label scale."""
    take = data["split"] == "train"
    maps = data["maps"][take].astype(np.float64)
    scalars = data["scalars"][take].astype(np.float64)
    target = data["target"][take].astype(np.float64)
    return dict(map_mean=maps.mean(axis=(0, 2, 3)).tolist(),
                map_std=np.maximum(maps.std(axis=(0, 2, 3)), 1e-6).tolist(),
                scalar_mean=scalars.mean(axis=0).tolist(),
                scalar_std=np.maximum(scalars.std(axis=0), 1e-6).tolist(),
                target_mean=float(target.mean()), target_std=float(max(target.std(), 1e-6)))


def _validate_normalization(norm):
    norm = _plain(norm)
    for key in ("map_mean", "map_std", "scalar_mean", "scalar_std"):
        array = np.asarray(norm.get(key), dtype=np.float32)
        if array.shape != (12,) or not np.isfinite(array).all():
            raise ValueError(f"invalid normalization {key}")
        if key.endswith("std") and np.any(array <= 0):
            raise ValueError(f"invalid normalization scale {key}")
    for key in ("target_mean", "target_std"):
        value = norm.get(key)
        if not isinstance(value, (float, int)) or not np.isfinite(value):
            raise ValueError(f"invalid normalization {key}")
    if norm["target_std"] <= 0:
        raise ValueError("target_std must be positive")
    return norm


def _features(maps, scalars, norm):
    maps = np.asarray(maps, dtype=np.float32)
    scalars = np.asarray(scalars, dtype=np.float32)
    if maps.shape == MAP_SHAPE:
        maps = maps[None]
    if scalars.shape == SCALAR_SHAPE:
        scalars = scalars[None]
    if (maps.ndim != 4 or maps.shape[1:] != MAP_SHAPE or scalars.shape != (len(maps), 12)
            or not np.isfinite(maps).all() or not np.isfinite(scalars).all()):
        raise ValueError("prediction needs finite maps[N,12,4,4] and scalars[N,12]")
    maps = (maps - np.asarray(norm["map_mean"], dtype=np.float32)[None, :, None, None]) / np.asarray(norm["map_std"], dtype=np.float32)[None, :, None, None]
    scalars = (scalars - np.asarray(norm["scalar_mean"], dtype=np.float32)) / np.asarray(norm["scalar_std"], dtype=np.float32)
    if not np.isfinite(maps).all() or not np.isfinite(scalars).all():
        raise ValueError("features overflow after normalization")
    return maps, scalars


def _group_indices(ids):
    # One pass avoids repeatedly scanning a large array for each candidate set.
    indices = {}
    for i, group in enumerate(ids.tolist()):
        indices.setdefault(group, []).append(i)
    return [np.asarray(value, dtype=np.int64) for value in indices.values()]


def shortlist(scores, baseline, k, mode="learned"):
    """Exactly min(k,N) distinct candidates, with deterministic stable ties.

    Hybrid reserves half the budget for each ordering. Overlap is refilled
    alternating the two orderings; it never receives a larger scoring budget.
    """
    scores, baseline = np.asarray(scores), np.asarray(baseline)
    if scores.ndim != 1 or baseline.shape != scores.shape or not np.isfinite(scores).all() or not np.isfinite(baseline).all():
        raise ValueError("shortlist requires finite equal-length vectors")
    if int(k) != k or k < 1 or mode not in ("learned", "baseline", "hybrid"):
        raise ValueError("invalid shortlist budget or mode")
    k = min(int(k), len(scores))
    learned = np.argsort(-scores, kind="stable").tolist()
    greedy = np.argsort(-baseline, kind="stable").tolist()
    if mode != "hybrid":
        return np.asarray((learned if mode == "learned" else greedy)[:k], dtype=np.int64)
    chosen, seen = [], set()
    order = greedy[:(k + 1) // 2] + learned[:k // 2]
    order += [item for pair in zip(greedy, learned) for item in pair]
    for item in order:
        if item not in seen and len(chosen) < k:
            chosen.append(item)
            seen.add(item)
    return np.asarray(chosen, dtype=np.int64)


def evaluate_shortlists(target, prediction, baseline, group_id, budgets=(4, 8)):
    """Teacher's best among shortlisted candidates at equal exact-tool budget.

    Normalized regret uses each group's oracle-to-worst span. Every group has
    equal weight. This prevents large label scales from dominating selection.
    """
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    baseline = np.asarray(baseline, dtype=np.float64)
    ids = np.asarray(group_id)
    if target.ndim != 1 or prediction.shape != target.shape or baseline.shape != target.shape or ids.shape != target.shape or not len(target):
        raise ValueError("invalid evaluation vectors")
    if not all(np.isfinite(value).all() for value in (target, prediction, baseline)):
        raise ValueError("nonfinite evaluation vectors")
    groups = _group_indices(ids)
    result = {"groups": len(groups), "candidates": len(target), "budgets": {}}
    for k in budgets:
        row = {}
        for mode in ("baseline", "learned", "hybrid"):
            regrets, relative, hits, actual_budgets = [], [], [], []
            for idx in groups:
                truth = target[idx]
                take = shortlist(prediction[idx], baseline[idx], k, mode)
                oracle = float(truth.max())
                regret = max(0.0, oracle - float(truth[take].max()))
                span = float(truth.max() - truth.min())
                regrets.append(regret)
                relative.append(regret / span if span > 1e-12 else 0.0)
                hits.append(regret <= max(1e-8, abs(oracle) * 1e-7))
                actual_budgets.append(len(take))
            row[mode] = dict(mean_regret=float(np.mean(regrets)),
                             mean_normalized_regret=float(np.mean(relative)),
                             oracle_in_shortlist_fraction=float(np.mean(hits)),
                             mean_candidates_scored=float(np.mean(actual_budgets)),
                             min_candidates_scored=min(actual_budgets),
                             max_candidates_scored=max(actual_budgets))
        result["budgets"][str(k)] = row
    result["regression_rmse"] = float(np.sqrt(np.mean((prediction - target) ** 2)))
    result["metric_scope"] = "surrogate bounded-planning teacher; not official competition score"
    return result


def _build_model():
    import torch
    from torch import nn

    class CandidateCNN(nn.Module):
        def __init__(self):
            super().__init__()
            self.conv1 = nn.Conv2d(12, 24, 3, padding=1)
            self.conv2 = nn.Conv2d(24, 16, 1)
            self.fc1 = nn.Linear(16 * 4 * 4 + 12, 64)
            self.fc2 = nn.Linear(64, 1)

        def forward(self, maps, scalars):
            x = torch.relu(self.conv1(maps))
            x = torch.relu(self.conv2(x)).flatten(1)
            x = torch.relu(self.fc1(torch.cat((x, scalars), dim=1)))
            return self.fc2(x).flatten()

    return CandidateCNN()


class NumpyPredictor:
    """No Torch dependency, including construction and deserialization."""
    SHAPES = {"conv1.weight": (24, 12, 3, 3), "conv1.bias": (24,),
              "conv2.weight": (16, 24, 1, 1), "conv2.bias": (16,),
              "fc1.weight": (64, 268), "fc1.bias": (64,),
              "fc2.weight": (1, 64), "fc2.bias": (1,)}

    def __init__(self, weights, normalization, metadata=None, batch_size=256):
        if int(batch_size) != batch_size or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        self.weights = {}
        for name, shape in self.SHAPES.items():
            value = np.asarray(weights[name], dtype=np.float32)
            if value.shape != shape or not np.isfinite(value).all():
                raise ValueError(f"invalid network weight {name}")
            self.weights[name] = value
        self.normalization = _validate_normalization(normalization)
        self.metadata = metadata or {}
        self.batch_size = int(batch_size)

    def predict(self, maps, scalars):
        maps, scalars = _features(maps, scalars, self.normalization)
        if not len(maps):
            return np.empty(0, dtype=np.float32)
        w, chunks = self.weights, []
        for start in range(0, len(maps), self.batch_size):
            x = maps[start:start + self.batch_size]
            padded = np.pad(x, ((0, 0), (0, 0), (1, 1), (1, 1)))
            windows = np.lib.stride_tricks.sliding_window_view(padded, (3, 3), axis=(2, 3))
            x = np.einsum("nihwkl,oikl->nohw", windows, w["conv1.weight"], optimize=True)
            x = np.maximum(0, x + w["conv1.bias"][None, :, None, None])
            x = np.einsum("nihw,oi->nohw", x, w["conv2.weight"][:, :, 0, 0], optimize=True)
            x = np.maximum(0, x + w["conv2.bias"][None, :, None, None])
            x = np.concatenate((x.reshape(len(x), -1), scalars[start:start + len(x)]), axis=1)
            x = np.maximum(0, x @ w["fc1.weight"].T + w["fc1.bias"])
            x = (x @ w["fc2.weight"].T + w["fc2.bias"]).ravel()
            chunks.append(x * self.normalization["target_std"] + self.normalization["target_mean"])
        result = np.concatenate(chunks).astype(np.float32)
        if not np.isfinite(result).all():
            raise ValueError("nonfinite network predictions")
        return result

    __call__ = predict


class TorchPredictor:
    def __init__(self, payload, device="cpu", batch_size=256):
        import torch
        self.device = torch.device(device)
        self.model = _build_model().to(self.device)
        self.model.load_state_dict(payload["state_dict"], strict=True)
        self.model.eval()
        self.normalization = _validate_normalization(payload["normalization"])
        self.metadata = payload.get("metadata", {})
        if int(batch_size) != batch_size or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        self.batch_size = int(batch_size)

    def predict(self, maps, scalars):
        import torch
        maps, scalars = _features(maps, scalars, self.normalization)
        if not len(maps):
            return np.empty(0, dtype=np.float32)
        chunks = []
        with torch.inference_mode():
            for start in range(0, len(maps), self.batch_size):
                m = torch.from_numpy(np.ascontiguousarray(maps[start:start + self.batch_size])).to(self.device)
                s = torch.from_numpy(np.ascontiguousarray(scalars[start:start + self.batch_size])).to(self.device)
                chunks.append(self.model(m, s).cpu().numpy())
        result = np.concatenate(chunks) * self.normalization["target_std"] + self.normalization["target_mean"]
        if not np.isfinite(result).all():
            raise ValueError("nonfinite network predictions")
        return result.astype(np.float32)

    __call__ = predict


def load_predictor(checkpoint_or_export, device="cpu", backend="numpy", batch_size=256):
    path = Path(checkpoint_or_export)
    if backend not in ("numpy", "torch"):
        raise ValueError("backend must be numpy or torch")
    if path.is_dir():
        path = path / ("weights.npz" if backend == "numpy" else "best.pt")
    if path.suffix == ".npz":
        with np.load(path, allow_pickle=False) as archive:
            metadata = json.loads(str(archive["metadata_json"].item()))
            if metadata.get("format") != FORMAT:
                raise ValueError("unsupported export format")
            weights = {key: archive[key] for key in NumpyPredictor.SHAPES}
        if backend == "numpy":
            return NumpyPredictor(weights, metadata["normalization"], metadata.get("metadata"), batch_size)
        import torch
        payload = dict(state_dict={key: torch.from_numpy(value) for key, value in weights.items()},
                       normalization=metadata["normalization"], metadata=metadata.get("metadata", {}))
    else:
        import torch
        payload = torch.load(path, map_location="cpu", weights_only=True)
        if payload.get("format") != FORMAT:
            raise ValueError("unsupported checkpoint format")
        if backend == "numpy":
            return NumpyPredictor({key: value.numpy() for key, value in payload["state_dict"].items()},
                                  payload["normalization"], payload.get("metadata"), batch_size)
    return TorchPredictor(payload, device, batch_size)


def _selection_key(metrics):
    return (metrics["budgets"]["4"]["learned"]["mean_normalized_regret"],
            metrics["budgets"]["8"]["learned"]["mean_normalized_regret"],
            metrics["budgets"]["4"]["learned"]["mean_regret"],
            metrics["regression_rmse"])


def train(dataset_npz, out, device="cuda:0", seed=17, epochs=20):
    """One seed, immutable final checkpoint, validation selection, test once.

    All candidates within each group participate in listwise optimization.
    The test arrays are never forwarded until checkpoint selection is complete.
    Existing output artifacts are refused, including a partial previous run.
    """
    import torch
    import torch.nn.functional as F

    if int(epochs) != epochs or epochs < 1:
        raise ValueError("epochs must be a positive integer")
    started = time.monotonic()
    dataset_npz, out = Path(dataset_npz), Path(out)
    data = read_dataset(dataset_npz)
    # Exact-path sentinels work on the server NFS even when a new directory's
    # readdir result lags behind directly readable files.
    known = ("run.started.json", "config.json", "progress.jsonl", "best.pt", "weights.npz", "training.json")
    if any((out / name).exists() for name in known):
        raise FileExistsError("training run already has artifacts; use a new run directory")
    if out.exists() and any(out.iterdir()):
        raise FileExistsError("training output is not empty; use a new run directory")
    out.mkdir(parents=True, exist_ok=True)
    _json_write(out / "run.started.json", dict(dataset=str(dataset_npz), seed=int(seed)))
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; choose device='cpu' explicitly")
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # Repeatable single-seed convolutions; no dependence on test for settings.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    norm = fit_normalization(data)
    model = _build_model().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    split_indices = {name: np.flatnonzero(data["split"] == name) for name in SPLITS}
    train_idx = split_indices["train"]
    val_idx = split_indices["validation"]
    train_maps, train_scalars = _features(data["maps"][train_idx], data["scalars"][train_idx], norm)
    train_target = ((data["target"][train_idx] - norm["target_mean"]) / norm["target_std"]).astype(np.float32)
    if not np.isfinite(train_target).all():
        raise ValueError("normalized target is not finite")
    group_indices = _group_indices(data["group_id"][train_idx])
    group_counts = {name: len(np.unique(data["group_id"][indices])) for name, indices in split_indices.items()}
    config = dict(format=FORMAT, seed=int(seed), epochs=int(epochs), device=str(device),
                  normalization=norm, metadata=data["metadata"], dataset_sha256=_sha256(dataset_npz),
                  counts={name: len(indices) for name, indices in split_indices.items()}, group_counts=group_counts,
                  loss="per-group soft best-choice cross entropy + 0.15 smooth-L1 regression",
                  selection="validation learned shortlist normalized regret k=4, then k=8, then raw k=4 regret, then RMSE",
                  budgets=[4, 8], batch_groups=16, learning_rate=1e-3,
                  official_score=False, split_audit="group isolation verified; episode/sky isolation is caller responsibility")
    _json_write(out / "config.json", config)
    history, best_key, best_state, selected = [], None, None, None
    stale = 0
    with (out / "progress.jsonl").open("x", encoding="utf-8") as progress:
        for epoch in range(1, int(epochs) + 1):
            model.train()
            order = rng.permutation(len(group_indices))
            loss_sum, groups_seen = 0.0, 0
            for start in range(0, len(order), 16):
                chosen = [group_indices[i] for i in order[start:start + 16]]
                idx = np.concatenate(chosen)
                maps = torch.from_numpy(np.ascontiguousarray(train_maps[idx])).to(device)
                scalars = torch.from_numpy(np.ascontiguousarray(train_scalars[idx])).to(device)
                target = torch.from_numpy(train_target[idx]).to(device)
                predicted = model(maps, scalars)
                losses, offset = [], 0
                for group in chosen:
                    p, y = predicted[offset:offset + len(group)], target[offset:offset + len(group)]
                    # Flat labels carry no ranking information; omit their CE.
                    spread = y.std(unbiased=False).clamp_min(0.1)
                    relevance = torch.softmax((y - y.max()) / (0.35 * spread), dim=0)
                    rank_loss = -(relevance * torch.log_softmax(p / spread, dim=0)).sum()
                    rank_loss = rank_loss * ((y.max() - y.min()) >= 1e-8).to(p.dtype)
                    # Top-weighted regression preserves units without allowing
                    # numerous low-value candidates to dominate the objective.
                    error = F.smooth_l1_loss(p, y, reduction="none")
                    regression = 0.5 * error.mean() + 0.5 * (relevance * error).sum()
                    losses.append(rank_loss + 0.15 * regression)
                    offset += len(group)
                loss = torch.stack(losses).mean()
                if not torch.isfinite(loss):
                    raise RuntimeError("training produced nonfinite loss")
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
                optimizer.step()
                loss_sum += float(loss.detach()) * len(chosen)
                groups_seen += len(chosen)
            model.eval()
            validation_predictor = TorchPredictor(dict(state_dict=model.state_dict(), normalization=norm), device)
            validation_prediction = validation_predictor(data["maps"][val_idx], data["scalars"][val_idx])
            validation = evaluate_shortlists(data["target"][val_idx], validation_prediction,
                                            data["baseline"][val_idx], data["group_id"][val_idx])
            row = dict(epoch=epoch, loss=loss_sum / groups_seen, validation=validation,
                       elapsed_seconds=time.monotonic() - started)
            history.append(row)
            progress.write(json.dumps(row, allow_nan=False) + "\n")
            progress.flush()
            print(json.dumps(dict(event="learning_epoch", epoch=epoch, loss=row["loss"],
                                  validation_regret_k4=validation["budgets"]["4"]["learned"]["mean_regret"],
                                  elapsed_seconds=row["elapsed_seconds"])), flush=True)
            key = _selection_key(validation)
            if best_key is None or key < best_key:
                best_key, selected, stale = key, row, 0
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            else:
                stale += 1
            if stale >= 6:
                break
    metadata = dict(dataset=data["metadata"], seed=int(seed), selected_epoch=selected["epoch"],
                    dataset_sha256=config["dataset_sha256"], official_score=False)
    payload = dict(format=FORMAT, state_dict=best_state, normalization=norm, metadata=metadata)
    with (out / "best.pt").open("xb") as stream:
        torch.save(payload, stream)
    export = {key: value.numpy() for key, value in best_state.items()}
    export["metadata_json"] = np.asarray(json.dumps(dict(format=FORMAT, normalization=norm, metadata=metadata), allow_nan=False))
    with (out / "weights.npz").open("xb") as stream:
        np.savez_compressed(stream, **export)
    # Export equivalence uses validation inputs, leaving test untouched until
    # the selected checkpoint and deployment format have both been finalized.
    torch_predictor = TorchPredictor(payload, device)
    numpy_predictor = load_predictor(out, backend="numpy")
    audit_idx = val_idx[:min(128, len(val_idx))]
    p_torch = torch_predictor(data["maps"][audit_idx], data["scalars"][audit_idx])
    p_numpy = numpy_predictor(data["maps"][audit_idx], data["scalars"][audit_idx])
    scale = max(1.0, float(np.max(np.abs(p_torch))))
    max_error = float(np.max(np.abs(p_torch - p_numpy)))
    if not np.allclose(p_torch, p_numpy, rtol=2e-4, atol=scale * 2e-5):
        raise RuntimeError(f"NumPy export mismatch: max absolute error {max_error}")
    # Exactly one held-out prediction and evaluation after model selection.
    test_idx = split_indices["test"]
    test_prediction = torch_predictor(data["maps"][test_idx], data["scalars"][test_idx])
    heldout = evaluate_shortlists(data["target"][test_idx], test_prediction,
                                  data["baseline"][test_idx], data["group_id"][test_idx])
    with (out / "heldout_predictions.npz").open("xb") as stream:
        np.savez_compressed(stream, prediction=test_prediction, target=data["target"][test_idx],
                            baseline=data["baseline"][test_idx], group_id=data["group_id"][test_idx])
    validation_k4 = selected["validation"]["budgets"]["4"]
    # A useful fallback: the neural shortlist is not promoted just because a
    # neural model was trained. Ties prefer the simplest baseline.
    mode_order = ("baseline", "hybrid", "learned")
    selected_mode = min(mode_order, key=lambda mode: (validation_k4[mode]["mean_normalized_regret"],
                                                     validation_k4[mode]["mean_regret"], mode_order.index(mode)))
    report = dict(status="complete", format=FORMAT, selected=selected, epochs_run=len(history),
                  stopped_early=len(history) < epochs, test_evaluations=1, heldout_test=heldout,
                  recommended_shortlist_mode=selected_mode, recommendation_basis="validation k=4 only",
                  checkpoint=str(out / "best.pt"), numpy_export=str(out / "weights.npz"),
                  checkpoint_sha256=_sha256(out / "best.pt"), export_sha256=_sha256(out / "weights.npz"),
                  export_validation_max_absolute_error=max_error,
                  parameter_count=sum(parameter.numel() for parameter in model.parameters()),
                  elapsed_seconds=time.monotonic() - started, official_score=False,
                  caveat="Targets come from a bounded surrogate planner; measured shortlist regret is not a competition result.")
    _json_write(out / "training.json", report)
    return report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset_npz")
    parser.add_argument("out")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--epochs", type=int, default=20)
    arguments = parser.parse_args()
    print(json.dumps(train(**vars(arguments)), indent=2, ensure_ascii=False))
