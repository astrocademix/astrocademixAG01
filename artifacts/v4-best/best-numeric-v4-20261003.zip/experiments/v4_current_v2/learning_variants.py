"""Three small-CNN shortlist objectives for the current v4 public-model teacher.

These models output *ranking scores*, not scientific gains. They share the
original architecture and train-only feature normalization. Validation selects
the actual deployed hybrid k=8 shortlist; the test split is evaluated once.

CLI: python -m experiments.v4_current_v2.learning_variants DATA.npz OUT
       --variant baseline_residual --device cuda:0 --seed 17 --epochs 24

Runtime: load_variant(OUT).predict(maps, scalars, baseline=immediate_rates).
``score_candidates`` is an alias. Each inference call is one candidate group
unless explicit group_id is supplied. Export and inference require only NumPy.
"""
from __future__ import annotations

import json
from pathlib import Path
import time

import numpy as np

from . import learning as base

FORMAT = 'v4-current-shortlist-variant-v1'
VARIANTS = ('group_rank', 'baseline_residual', 'shortlist_diversity')
RESIDUAL_LIMIT = .5
BASELINE_RESERVED = 4


def training_domain(group_id):
    """Use public card/weather domains, never the held-out night or episode ID."""
    parts = str(group_id).split(':')
    card = parts[0] if parts[0] in ('alpha', 'beta', 'gamma', 'delta') else 'unspecified'
    weather = next((part for part in parts[1:] if part in ('nominal', 'adverse', 'variable')), 'unspecified')
    return f'{card}:{weather}'


def rank_prior(values):
    """Average-rank prior in [-1,1]; invariant to positive affine unit changes."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ValueError('Baseline must be a finite vector')
    if len(values) < 2:
        return np.zeros(len(values), dtype=np.float32)
    unique, inverse, counts = np.unique(values, return_inverse=True, return_counts=True)
    ends = np.cumsum(counts)
    average_rank = (ends - counts + ends - 1) / 2
    return (2 * average_rank[inverse] / (len(values) - 1) - 1).astype(np.float32)


def transform_scores(raw, baseline, variant, group_id=None):
    """Apply public-baseline priors only; never consumes teacher labels."""
    raw = np.asarray(raw, dtype=np.float32)
    if raw.ndim != 1 or not np.isfinite(raw).all() or variant not in VARIANTS:
        raise ValueError('Invalid variant or neural scores')
    if baseline is None:
        if variant != 'group_rank':
            raise ValueError(f'{variant} requires immediate baseline scores at inference')
        baseline = np.zeros(len(raw), dtype=np.float32)
    baseline = np.asarray(baseline, dtype=np.float32)
    if baseline.shape != raw.shape or not np.isfinite(baseline).all():
        raise ValueError('Baseline and neural scores must have identical finite shapes')
    ids = np.repeat('one-candidate-set', len(raw)) if group_id is None else np.asarray(group_id)
    if ids.shape != raw.shape:
        raise ValueError('group_id must match score shape')
    result = raw.copy()
    for indices in base._group_indices(ids):
        if variant == 'baseline_residual':
            result[indices] = rank_prior(baseline[indices]) + RESIDUAL_LIMIT * np.tanh(raw[indices])
        elif variant == 'shortlist_diversity':
            # Reserve the strongest four baseline candidates for the *baseline*
            # half. The CNN half deliberately proposes distinct alternatives.
            result[indices] = np.tanh(raw[indices])
            if len(indices) > BASELINE_RESERVED:
                reserved = np.argsort(-baseline[indices], kind='stable')[:BASELINE_RESERVED]
                result[indices[reserved]] = -2.
    return result


class VariantPredictor:
    def __init__(self, weights, normalization, metadata, batch_size=256):
        if metadata.get('variant') not in VARIANTS:
            raise ValueError('Unknown shortlist variant')
        self.metadata = metadata
        self.variant = metadata['variant']
        self.model = base.NumpyPredictor(weights, normalization, metadata, batch_size)

    def predict(self, maps, scalars, baseline=None, group_id=None):
        raw = self.model.predict(maps, scalars)
        return transform_scores(raw, baseline, self.variant, group_id)

    score_candidates = predict
    __call__ = predict


def load_variant(path, batch_size=256):
    """Load a run directory, variant.json, or its self-contained weights.npz."""
    path = Path(path)
    if path.is_dir():
        path = path / 'variant.json'
    if path.suffix == '.json':
        manifest = json.loads(path.read_text(encoding='utf-8'))
        if manifest.get('format') != FORMAT or manifest.get('weights_filename') != 'weights.npz':
            raise ValueError('Unsupported variant manifest')
        weight_path = path.parent / manifest['weights_filename']
        if base._sha256(weight_path) != manifest['weights_sha256']:
            raise ValueError('Variant weights SHA256 mismatch')
        path = weight_path
    with np.load(path, allow_pickle=False) as archive:
        metadata = json.loads(str(archive['metadata_json'].item()))
        if metadata.get('format') != FORMAT:
            raise ValueError('Use load_variant only for a shortlist-variant export')
        weights = {key: archive[key] for key in base.NumpyPredictor.SHAPES}
    return VariantPredictor(weights, metadata['normalization'], metadata, batch_size)


def _metrics(target, prediction, baseline, groups):
    report = base.evaluate_shortlists(target, prediction, baseline, groups)
    # Rank scores are deliberately not in teacher-value units. Reporting their
    # RMSE against a scientific quantity would be meaningless.
    report.pop('regression_rmse', None)
    report['prediction_semantics'] = 'within-candidate-set ranking score, not scientific gain'
    return report


def _selection(metrics):
    # Tune the shortlist the agent actually uses, rather than a standalone CNN
    # surrogate metric. All variants use exactly the same selection criterion.
    return tuple(metrics['budgets'][str(k)]['hybrid'][name] for k, name in
                 ((8, 'mean_normalized_regret'), (8, 'mean_regret'),
                  (4, 'mean_normalized_regret'), (4, 'mean_regret')))


def _group_objective(prediction, target, immediate, variant):
    import torch
    import torch.nn.functional as F
    prior = torch.from_numpy(rank_prior(immediate)).to(prediction.device)
    if variant == 'baseline_residual':
        scores = prior + RESIDUAL_LIMIT * torch.tanh(prediction)
    else:
        scores = prediction
    keep = torch.ones(len(target), dtype=torch.bool, device=prediction.device)
    weight = 1.
    if variant == 'shortlist_diversity' and len(target) > BASELINE_RESERVED:
        reserved = np.argsort(-immediate, kind='stable')[:BASELINE_RESERVED]
        keep[torch.as_tensor(reserved, dtype=torch.long, device=prediction.device)] = False
        # Focus on candidate sets in which the baseline's reserved half misses
        # value. The weight uses train labels only and is bounded [0.2,3.2].
        span = (target.max() - target.min()).clamp_min(1e-6)
        missed = (target.max() - target[~keep].max()).clamp_min(0.) / span
        weight = .2 + 3. * missed.detach()
    y, p = target[keep], scores[keep]
    if len(y) < 2:
        return prediction.sum() * 0., weight
    # Each candidate set is its own ranking problem; absolute night/domain
    # value offsets and scales never become regression targets.
    yz = (y - y.mean()) / y.std(unbiased=False).clamp_min(1e-6)
    if variant == 'baseline_residual':
        # Keep the calibrated rank-prior scale fixed so the bounded correction
        # genuinely constrains how far a weak CNN can perturb the baseline.
        pz = p
        target_score = torch.tanh(yz / 2.)
    else:
        pz = (p - p.mean()) / p.std(unbiased=False).clamp_min(.1)
        target_score = yz
    relevance = torch.softmax(yz / .5, dim=0)
    rank_loss = -(relevance * torch.log_softmax(pz / .5, dim=0)).sum()
    rank_loss = rank_loss * ((y.max() - y.min()) > 1e-8).to(p.dtype)
    regression = F.smooth_l1_loss(pz, target_score, reduction='none')
    regression = .5 * regression.mean() + .5 * (relevance * regression).sum()
    return rank_loss + .1 * regression, weight


def train(dataset_npz, out, variant='group_rank', device='cuda:0', seed=17, epochs=24):
    """Train one configuration; split, finite and label audits reuse learning.py."""
    import torch
    if variant not in VARIANTS:
        raise ValueError(f'variant must be one of {VARIANTS}')
    if seed != 17:
        raise ValueError('This experiment protocol uses the single training seed 17')
    if type(epochs) is not int or epochs < 1:
        raise ValueError('epochs must be a positive integer')
    data = base.read_dataset(dataset_npz)
    out = Path(out)
    known = ('run.started.json', 'config.json', 'weights.npz', 'variant.json', 'training.json')
    if any((out / name).exists() for name in known) or (out.exists() and any(out.iterdir())):
        raise FileExistsError('Use a new training output directory')
    out.mkdir(parents=True, exist_ok=True)
    base._json_write(out/'run.started.json', dict(variant=variant, seed=seed, dataset=str(dataset_npz)))
    if str(device).startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; request CPU explicitly when appropriate')
    started = time.monotonic()
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    rng = np.random.default_rng(seed)
    norm = base.fit_normalization(data)
    norm['target_mean'], norm['target_std'] = 0., 1.
    split_idx = {name: np.flatnonzero(data['split'] == name) for name in base.SPLITS}
    training_idx, val_idx = split_idx['train'], split_idx['validation']
    maps, scalars = base._features(data['maps'][training_idx], data['scalars'][training_idx], norm)
    targets = data['target'][training_idx]
    immediate = data['baseline'][training_idx]
    groups = base._group_indices(data['group_id'][training_idx])
    group_domains = [training_domain(data['group_id'][training_idx][indices[0]]) for indices in groups]
    domain_counts = {name: group_domains.count(name) for name in set(group_domains)}
    # No validation/test statistics determine normalization or domain weights.
    domain_weights = [len(groups) / (len(domain_counts) * domain_counts[name]) for name in group_domains]
    model = base._build_model().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=6e-4, weight_decay=3e-4)
    config = dict(format=FORMAT, variant=variant, seed=seed, epochs=epochs, device=str(device),
        normalization=norm, source_metadata=data['metadata'], dataset_sha256=base._sha256(dataset_npz),
        train_domain_groups=domain_counts, domain_definition='public card and declared nominal/adverse/variable weather tokens only; equal expected group weight per training domain',
        prediction_semantics='ranking score, not scientific gain', shortlist_budget=8,
        residual_limit=RESIDUAL_LIMIT, baseline_reserved=BASELINE_RESERVED,
        selection='validation hybrid k8 normalized regret, raw regret; ties by hybrid k4 regret; test once',
        counts={name: len(idx) for name, idx in split_idx.items()}, official_score=False)
    base._json_write(out/'config.json', config)
    history, selected, best_state, best_key, stale = [], None, None, None, 0
    with (out/'progress.jsonl').open('x', encoding='utf-8') as progress:
        for epoch in range(1, epochs+1):
            model.train()
            order = rng.permutation(len(groups))
            loss_sum, batches = 0., 0
            for start in range(0, len(order), 16):
                selected_groups = order[start:start+16]
                indices = np.concatenate([groups[i] for i in selected_groups])
                tensor_maps = torch.from_numpy(np.ascontiguousarray(maps[indices])).to(device)
                tensor_scalars = torch.from_numpy(np.ascontiguousarray(scalars[indices])).to(device)
                y = torch.from_numpy(targets[indices]).to(device)
                predictions = model(tensor_maps, tensor_scalars)
                losses, weights, offset = [], [], 0
                for group_index in selected_groups:
                    size = len(groups[group_index])
                    selection = slice(offset, offset+size)
                    loss, hard_weight = _group_objective(predictions[selection], y[selection],
                        immediate[indices[selection]], variant)
                    weight = torch.as_tensor(hard_weight, device=device) * domain_weights[group_index]
                    losses.append(loss * weight)
                    weights.append(weight)
                    offset += size
                loss = torch.stack(losses).sum() / torch.stack(weights).sum().clamp_min(1e-6)
                if not torch.isfinite(loss):
                    raise RuntimeError('Nonfinite variant training loss')
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
                optimizer.step()
                loss_sum += float(loss.detach())
                batches += 1
            model.eval()
            predictor = base.TorchPredictor(dict(state_dict=model.state_dict(), normalization=norm), device=device)
            raw = predictor(data['maps'][val_idx], data['scalars'][val_idx])
            score = transform_scores(raw, data['baseline'][val_idx], variant, data['group_id'][val_idx])
            validation = _metrics(data['target'][val_idx], score, data['baseline'][val_idx], data['group_id'][val_idx])
            row = dict(epoch=epoch, loss=loss_sum/max(1,batches), validation=validation,
                       elapsed_seconds=time.monotonic()-started)
            history.append(row)
            progress.write(json.dumps(row, allow_nan=False)+'\n')
            progress.flush()
            print(json.dumps(dict(event='variant_epoch', variant=variant, epoch=epoch,
                hybrid_k8_normalized_regret=validation['budgets']['8']['hybrid']['mean_normalized_regret'])), flush=True)
            key = _selection(validation)
            if best_key is None or key < best_key:
                best_key, selected, stale = key, row, 0
                best_state = {name: tensor.detach().cpu().clone() for name,tensor in model.state_dict().items()}
            else:
                stale += 1
            if stale >= 8:
                break
    metadata = dict(config, selected_epoch=selected['epoch'])
    payload = dict(format=FORMAT, state_dict=best_state, normalization=norm, metadata=metadata)
    with (out/'best.pt').open('xb') as stream:
        torch.save(payload, stream)
    weights = {name: value.numpy() for name,value in best_state.items()}
    encoded = dict(metadata, normalization=norm)
    with (out/'weights.npz').open('xb') as stream:
        np.savez_compressed(stream, **weights, metadata_json=np.asarray(json.dumps(encoded, allow_nan=False)))
    manifest = dict(format=FORMAT, variant=variant, weights_filename='weights.npz',
        weights_sha256=base._sha256(out/'weights.npz'), inference='load_variant(path).predict(maps,scalars,baseline=base)',
        baseline_required=variant != 'group_rank', intended_shortlist='hybrid k=8', seed=seed)
    base._json_write(out/'variant.json', manifest)
    numpy_predictor = load_variant(out)
    torch_predictor = base.TorchPredictor(payload, device=device)
    # Validate runtime math on complete validation groups, avoiding accidental
    # rank-prior changes caused by cutting a candidate set in half.
    val_groups = base._group_indices(data['group_id'][val_idx])
    audit_idx = val_idx[np.concatenate(val_groups[:min(4,len(val_groups))])]
    raw = torch_predictor(data['maps'][audit_idx], data['scalars'][audit_idx])
    expected = transform_scores(raw, data['baseline'][audit_idx], variant, data['group_id'][audit_idx])
    actual = numpy_predictor(data['maps'][audit_idx], data['scalars'][audit_idx],
        baseline=data['baseline'][audit_idx], group_id=data['group_id'][audit_idx])
    if not np.allclose(actual, expected, rtol=2e-4, atol=2e-5):
        raise RuntimeError('Exported variant does not match training inference')
    # All hyperparameters and the checkpoint are now fixed. Test is read once
    # for one prediction/evaluation; no deployment switch is chosen from it.
    test_idx = split_idx['test']
    test_scores = numpy_predictor(data['maps'][test_idx], data['scalars'][test_idx],
        baseline=data['baseline'][test_idx], group_id=data['group_id'][test_idx])
    heldout = _metrics(data['target'][test_idx], test_scores, data['baseline'][test_idx], data['group_id'][test_idx])
    with (out/'heldout_predictions.npz').open('xb') as stream:
        np.savez_compressed(stream, prediction=test_scores, target=data['target'][test_idx],
            baseline=data['baseline'][test_idx], group_id=data['group_id'][test_idx])
    val_k8 = selected['validation']['budgets']['8']
    choices = ('baseline', 'hybrid', 'learned') if variant != 'shortlist_diversity' else ('baseline', 'hybrid')
    recommendation = min(choices, key=lambda mode: (val_k8[mode]['mean_normalized_regret'],
        val_k8[mode]['mean_regret'], choices.index(mode)))
    report = dict(status='complete', format=FORMAT, variant=variant, seed=seed, selected=selected,
        epochs_run=len(history), test_evaluations=1, heldout_test=heldout,
        recommended_shortlist_mode=recommendation, recommendation_basis='validation k8 only',
        numpy_export=str(out/'weights.npz'), variant_manifest=str(out/'variant.json'), checkpoint=str(out/'best.pt'),
        export_sha256=manifest['weights_sha256'], export_validation_max_absolute_error=float(np.max(abs(actual-expected))),
        parameter_count=sum(p.numel() for p in model.parameters()), elapsed_seconds=time.monotonic()-started,
        official_score=False, scope='Surrogate bounded-planning teacher; results are not official competition scores.',
        heldout_scope='Chronological public-card test is reused across these predeclared variants; comparison is model development, not a fresh untouched final evaluation.')
    base._json_write(out/'training.json', report)
    return report


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset_npz')
    parser.add_argument('out')
    parser.add_argument('--variant', choices=VARIANTS, default='group_rank')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--seed', type=int, default=17)
    parser.add_argument('--epochs', type=int, default=24)
    print(json.dumps(train(**vars(parser.parse_args())), indent=2, ensure_ascii=False))
