import copy
from datetime import timedelta
import unittest

import numpy as np

from .planner import (Planner, equatorial_to_horizontal, horizontal_to_equatorial,
                      utc_datetime)
from .strategy import STRATEGIES, make_planner, visible_window_seconds
from .test_planner import fixture


class StrategyTests(unittest.TestCase):
    def test_analytic_visible_window_matches_dense_geometry_across_ra_wrap(self):
        start = '2026-10-05T00:00:00Z'
        end = '2026-10-05T09:00:00Z'
        ra = np.asarray([359.99, .01, 80., 160., 250.])
        dec = np.asarray([-85., -20., 30., 0., -45.])
        duration, peak = visible_window_seconds(ra, dec, start, end, -24.6157, -70.3976, 30.)
        times = [utc_datetime(start)+timedelta(seconds=30*i+15) for i in range(1080)]
        sampled = np.asarray([equatorial_to_horizontal(ra, dec, t, -24.6157, -70.3976)[0] for t in times])
        np.testing.assert_allclose(duration, (sampled >= 30.).sum(axis=0)*30., atol=60.)
        np.testing.assert_allclose(peak, sampled.max(axis=0), atol=.06)

    def test_circumpolar_and_never_visible(self):
        seconds, peak = visible_window_seconds([0., 0.], [-90., 90.],
            '2026-10-05T00:00:00Z', '2026-10-05T08:00:00Z', -45., 0., 30.)
        np.testing.assert_allclose(seconds, [28800., 0.])
        np.testing.assert_allclose(peak, [45., -45.])

    def test_baseline_wrapper_preserves_candidates_and_values(self):
        cat, state = fixture()
        expected = Planner(cat).propose(state, {}, max_candidates=8)
        wrapped = make_planner(cat)
        actual = wrapped.propose(state, {}, max_candidates=8)
        self.assertEqual([x['action'] for x in expected], [x['action'] for x in actual])
        np.testing.assert_allclose(wrapped.selection_values(actual, state), [x['rate'] for x in expected])

    def test_scarcity_increases_when_no_later_opportunity_remains(self):
        cat, state = fixture()
        cat.calendar = [dict(observing_start_utc='2026-10-06T02:00:00Z', observing_end_utc='2026-10-06T06:00:00Z')]
        planner = make_planner(cat, 'window_rescue')
        earlier = planner.window_summary(state)
        final = planner.window_summary(dict(state, now_utc='2026-10-06T02:00:00Z', end_utc='2026-10-06T06:00:00Z'))
        self.assertEqual(earlier['future_nights'][0], 1)
        self.assertEqual(final['future_nights'][0], 0)
        self.assertGreater(final['bonus'][0], earlier['bonus'][0])
        self.assertEqual(final['bonus'][1], 0.)
        completed = planner.window_summary(dict(state, best_factor={'a': .5}))
        self.assertEqual(completed['bonus'][0], 0.)

    def test_strategies_respect_cap_and_preserve_scoring_of_fixed_actions(self):
        for name in STRATEGIES:
            cat, state = fixture()
            frozen = copy.deepcopy(state)
            planner = make_planner(cat, name)
            candidates = planner.propose(state, {}, max_candidates=8)
            self.assertTrue(candidates, name)
            self.assertLessEqual(len(candidates), 8)
            for item in candidates:
                check = Planner(cat).evaluate_action(item['action'], state)
                self.assertIsNotNone(check)
                self.assertAlmostEqual(item['est_gain'], check['est_gain'], places=8)
                self.assertAlmostEqual(item['rate'], item['est_gain']/item['duration_seconds'])
                self.assertEqual(item['maps'].shape, (12, 4, 4))
            self.assertEqual(state, frozen)
            self.assertLessEqual(planner.strategy_stats['packing_geometries'], 8)
            self.assertLessEqual(planner.strategy_stats['rescue_evaluations'], 3)

    def test_window_objective_changes_selection_not_score(self):
        cat, state = fixture()
        planner = make_planner(cat, 'window_rescue')
        candidates = planner.propose(state, {}, max_candidates=8)
        raw = np.asarray([x['rate'] for x in candidates])
        selected = planner.selection_values(candidates, state)
        self.assertTrue(np.all(selected+1e-7 >= raw))
        self.assertTrue(np.any(selected > raw+1e-4))
        labels = planner.teacher_targets(candidates, state, dict(horizon=1))
        for item, value in zip(candidates, labels):
            expected = (item['est_gain']+item['strategy_window_bonus'])/7200.
            self.assertAlmostEqual(float(value), expected, places=7)

    def test_packing_can_resolve_same_fibre_conflict(self):
        cat, state = fixture()
        # Two valuable targets initially occupy one cell. A small boundary
        # translation assigns them to distinct fibres without moving targets.
        cat.required[:] = False
        ra, dec = horizontal_to_equatorial(np.asarray([65.0, 65.0, 65.0]),
                                          np.asarray([30.0, 30.2, 30.4]),
                                          state['now_utc'], cat.latitude, cat.longitude)
        cat.ra = np.asarray(ra); cat.dec = np.asarray(dec)
        cat.flux[:] = 1.; cat.weight[:] = 10.
        planner = make_planner(cat, 'fibre_pack')
        base = Planner(cat).propose(state, {}, max_candidates=8)
        packed = planner.propose(state, {}, max_candidates=8)
        self.assertGreater(max(x['rate'] for x in packed), max(x['rate'] for x in base))
        self.assertTrue(any(x.get('strategy_origin') == 'fibre_boundary_translation' for x in packed))

    def test_invalid_strategy_rejected(self):
        cat, _ = fixture()
        with self.assertRaises(ValueError):
            make_planner(cat, 'weather_oracle')


if __name__ == '__main__':
    unittest.main()
