import json
from pathlib import Path
import tempfile
import unittest
from contextlib import contextmanager

from .agent import GroupAgent
from .test_planner import fixture
from .planner import Planner


class ScriptedClient:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.messages = []

    def plan(self, messages, max_tokens=256):
        self.messages.append(messages)
        return dict(plan=next(self.responses))


DIAGNOSIS = dict(condition='uncertain', replan_reason='Use current public feedback', priority='required_windows')


@contextmanager
def trace_directory():
    directory = Path(tempfile.mkdtemp(prefix='test-agent-', dir=Path(__file__).resolve().parent))
    try:
        yield directory
    finally:
        # The server NFS may hide just-created files from directory listings.
        (directory/'trace.jsonl').unlink(missing_ok=True)
        directory.rmdir()


class AgentTests(unittest.TestCase):
    def test_real_control_change_and_rejection_repair_reach_model(self):
        cat, state = fixture()
        state.update(night_index=0, remaining_nights=38, required_missing=2)
        candidates = Planner(cat).propose(state, {}, max_candidates=4)
        client = ScriptedClient([DIAGNOSIS, {'exposure_margin': 1.3},
                                 DIAGNOSIS, {'priority_targets': ['UNKNOWN']}, {'exposure_margin': 1.1}])
        with trace_directory() as directory:
            agent = GroupAgent(cat, Path(directory)/'trace.jsonl', client=client)
            self.assertTrue(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.changed_plans, 1)
            agent.observe_feedback(state, candidates[0], dict(action='observe', hits=[]))
            state['night_index'] = 10
            self.assertTrue(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.controls['exposure_margin'], 1.1)
            self.assertEqual(agent.revisions, 1)
            repair_context = json.loads(client.messages[-1][1]['content'])
            self.assertIn('tool_error', repair_context)
            self.assertEqual(repair_context['tool_error']['rejected_proposal']['priority_targets'], ['UNKNOWN'])
            self.assertIn('whole_sky', repair_context)
            self.assertLessEqual(len(repair_context['whole_sky']['displayed_bands']), 12)

    def test_reason_only_does_not_count_as_policy_change(self):
        cat, state = fixture()
        state.update(night_index=0, remaining_nights=38)
        candidates = Planner(cat).propose(state, {}, max_candidates=2)
        client = ScriptedClient([DIAGNOSIS, {'reason': 'Same numerical plan'}])
        with trace_directory() as directory:
            agent = GroupAgent(cat, Path(directory)/'trace.jsonl', client=client)
            self.assertFalse(agent.maybe_replan(state, candidates))
            self.assertEqual(agent.valid_plans, 1)
            self.assertEqual(agent.changed_plans, 0)
            self.assertEqual(agent.revisions, 0)


if __name__ == '__main__':
    unittest.main()
