"""Bounded, resumable-by-inspection server queue; owns only its own processes."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
import urllib.request
import zipfile

from .common import CARDS, SCOPE, atomic_json


def idle_gpus():
    raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu',
                                 '--format=csv,noheader,nounits'],text=True)
    return {int(i) for i,m,u in (x.split(',') for x in raw.splitlines()) if int(m)<1000 and int(u)<10}


class Queue:
    def __init__(self,args):
        self.args=args;self.run=Path(args.run).resolve();self.repo=Path.cwd()
        if not str(self.run).startswith('/home/jovyan/huangzy183/'):
            raise ValueError('Server outputs must stay within huangzy183')
        self.start=time.monotonic();self.model=None;self.children=[];self.results=[];self.stage='created'
        self.training=None;self.pilot=None;self.eta=None;self.error=None
        self.run.mkdir(parents=True,exist_ok=True)
        if (self.run/'started.json').exists():raise ValueError('Run already started')
        atomic_json(self.run/'started.json',dict(pid=os.getpid(),utc=datetime.now(timezone.utc).isoformat(),seed=17,scope=SCOPE))

    def status(self,stage):
        self.stage=stage
        atomic_json(self.run/'status.json',dict(stage=stage,pid=os.getpid(),elapsed_seconds=time.monotonic()-self.start,
            results=len(self.results),estimated_finish_utc=self.eta,official_score=None))
        self.report()
        print(json.dumps(dict(stage=stage,elapsed_seconds=round(time.monotonic()-self.start,1))),flush=True)

    def command(self,command,log,env=None,timeout=2000):
        with Path(log).open('w') as f:
            p=subprocess.Popen(command,env=env,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
            self.children.append(p)
            try:code=p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                p.terminate()
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:p.kill();p.wait()
                raise RuntimeError('Owned child timeout: '+str(log))
        if code:raise RuntimeError('Child failed; inspect '+str(log))

    def episode(self,card,mode,episode,collect=False,max_nights=None,wall_limit=900,prefix='evaluation'):
        out=self.run/prefix/f'{mode}-{card}'
        out.parent.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,'-B','-u','-m','experiments.v4_current_v2.experiment',
            '--cards',self.args.cards,'--card',card,'--out',str(out),'--mode',mode,
            '--episode',str(episode),'--wall-limit',str(wall_limit)]
        if collect:cmd+=['--collect']
        if max_nights:cmd+=['--max-nights',str(max_nights)]
        if mode in ('learned','agent') and self.training:cmd+=['--checkpoint',self.training['numpy_export']]
        self.command(cmd,out.with_suffix('.log'),timeout=wall_limit+180)
        result=json.loads((out/'result.json').read_text())
        result['artifact_directory']=str(out)
        return result

    def start_api(self):
        free=idle_gpus();time.sleep(3);gpus=sorted(free & idle_gpus())[:2]
        if len(gpus)<2:raise RuntimeError('Need two idle GPUs for own Qwen API; existing jobs untouched')
        key=self.run/'local_api_token'
        if not key.exists():
            fd=os.open(key,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w') as f:f.write(secrets.token_urlsafe(32))
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=','.join(map(str,gpus)))
        with socket.socket() as probe:
            probe.bind(('127.0.0.1',0))
            port=probe.getsockname()[1]
        self.api_log=(self.run/'api_server.log').open('a')
        self.model=subprocess.Popen([sys.executable,'-B','-u','-m','experiments.v4_online_v1.model_api',
            '--model-dir',self.args.model_dir,'--key-file',str(key),'--port',str(port)],
            env=env,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=self.api_log,stderr=subprocess.STDOUT)
        self.children.append(self.model)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        until=time.monotonic()+240
        while time.monotonic()<until:
            if self.model.poll() is not None:raise RuntimeError('Owned Qwen API exited; inspect api_server.log')
            try:
                with opener.open(f'http://127.0.0.1:{port}/health',timeout=1) as r:health=json.load(r)
                if health.get('model')=='qwen27b-v4':break
            except (OSError,ValueError):pass
            time.sleep(1)
        else:raise RuntimeError('Qwen API load timed out')
        os.environ.update(OPENAI_BASE_URL=f'http://127.0.0.1:{port}/v1',OPENAI_API_KEY_FILE=str(key),OPENAI_MODEL='qwen27b-v4')
        atomic_json(self.run/'api_runtime.json',dict(model_dir=self.args.model_dir,gpus=gpus,pid=self.model.pid,
            endpoint_scope='authenticated loopback only; not platform public HTTPS',port=port))

    def stop_api(self):
        if self.model and self.model.poll() is None:
            self.model.terminate()
            try:self.model.wait(timeout=20)
            except subprocess.TimeoutExpired:self.model.kill();self.model.wait()
        self.model=None
        if hasattr(self,'api_log'):self.api_log.close()

    def report(self):
        lines=['# 当前 v4 四卡：Agent＋窗口规划＋学习候选筛选','',
            '**全部分数为公开目录＋合成天气/事件的开发代理分，不是官方排行榜分数。**','',
            f'- 当前阶段：`{self.stage}`',f'- 训练种子：17',f'- 当前已耗时：{(time.monotonic()-self.start)/60:.1f} 分钟',
            f'- 预计完成 UTC：{self.eta or "等待首夜计时"}',
            '- 天气不公开；环境自行生成，策略只通过官方形状的公开消息接收信息。',
            '- 评分/几何依照现行公开文档自主实现，尚未经官方运行器或云端复核。',
            '- 不同策略在相同合成天气与事件上闭环运行；训练与评估使用不同天气情景。','',
            '| 类型 | 卡 | 开发代理总分 | 必观测缺失 | 科学含加成 | 完成全季 | 秒 |',
            '|---|---|---:|---:|---:|---|---:|']
        for r in self.results:
            lines.append(f"| {r['mode']} | {r['card']} | {r['proxy_total']:.2f} | {r['required_missing']} | {r['science_with_program_bonus']:.2f} | {r['survey_complete']} | {r['wall_seconds']:.1f} |")
        if self.error:
            lines += ['', '## 本次未完成的原因', '', self.error, '', '详细日志请看 failed.json 和对应阶段日志。']
        if self.training:
            lines += ['', '## 学习结果', '',f"- 训练轮数：{self.training['epochs_run']}",
                f"- 验证集推荐 shortlist：{self.training['recommended_shortlist_mode']}",
                f"- NumPy 推理导出：`{self.training['numpy_export']}`",
                '- learned/agent 行固定测试混合候选（启发式＋CNN），不因为训练完成就认定其更强。',
                '- 详细候选 regret、Torch/NumPy 一致性与测试集指标见 training/training.json。']
        agents=[r for r in self.results if r.get('agent')]
        if agents:
            lines += ['', '## API Agent 闭环', '']
            for r in agents:
                a=r['agent'];lines.append(f"- {r['card']}：API {a['api_calls']} 次，公告/反馈解释 {a['interpretations']} 次，有效计划 {a['valid_group_plans']} 次，后续修订 {a['feedback_revisions']} 次，错误 {a['errors']} 次。")
        lines += ['', '## 文件', '', '- 每次运行：evaluation/<mode>-<card>/result.json、trajectory.csv、actions.jsonl。',
            '- 模型实际请求、响应、拒绝反馈：evaluation/agent-<card>/api_trace.jsonl。',
            '- 训练数据：dataset.npz；单卡收集记录在 collection/。',
            '- participant-agent.zip 是待云端验证的 v4 项目，不是 v3 decisions.csv。',
            '- 训练在已知四卡上按整夜划分，不能宣称未知星表泛化；合成天气提升也不等同正式提分。','']
        (self.run/'RESULTS.md').write_text('\n'.join(lines))

    def package(self):
        root=self.repo/'experiments/v4_current_v2'
        names=['__init__.py','common.py','planner.py','public_state.py','learning.py','agent.py','live_agent.py']
        with zipfile.ZipFile(self.run/'participant-agent.zip','x',zipfile.ZIP_DEFLATED) as z:
            z.writestr('experiments/__init__.py','')
            for name in names:z.write(root/name,'experiments/v4_current_v2/'+name)
            z.writestr('experiments/v4_online_v1/__init__.py','')
            for name in ('api_client.py','model_api.py'):
                z.write(self.repo/'experiments/v4_online_v1'/name,'experiments/v4_online_v1/'+name)
            z.write(self.run/'training/weights.npz','weights.npz')
            z.writestr('requirements.txt','numpy>=1.24,<3\n')
            z.writestr('observer.project.json',json.dumps(dict(protocol='jsonl-v4',
                run=['python3','-u','-m','experiments.v4_current_v2.live_agent'],
                build=['python3','-m','pip','install','-r','requirements.txt'],
                env=dict(USE_LLM='1',SKY_WEIGHTS='weights.npz'))))

    def execute(self):
        try:
            self.status('unit_tests')
            self.command([sys.executable,'-B','-m','unittest','discover','-s','experiments/v4_current_v2',
                '-t','.', '-p','test_*.py','-v'],self.run/'tests.log',timeout=240)
            self.status('profiling_one_night')
            self.pilot=self.episode('alpha','search',0,max_nights=1,wall_limit=180,prefix='pilot')
            atomic_json(self.run/'pilot.json',self.pilot)
            # Four collection + twelve numeric + four serial API episodes.
            # Numerical workers run two at a time. Allow 1.7x the measured first
            # night for later conditions; include labels, model calls and training.
            unit=max(4.,self.pilot['wall_seconds'])*38*1.7
            estimate=min(4*3600,unit*13 + 12*60)
            atomic_json(self.run/'time_estimate.json',dict(measured_pilot_seconds=self.pilot['wall_seconds'],
                estimated_remaining_seconds=estimate,assumptions='38 nights; 1.7x later-night factor; two numerical workers; API cards serial; 12min overhead',
                uncertainty='An estimate, not a deadline; full episode timing can differ from the first night.'))
            self.eta=(datetime.now(timezone.utc)+timedelta(seconds=estimate)).isoformat()
            self.status('checking_real_qwen27b_feedback_loop')
            self.start_api()
            self.command([sys.executable,'-B','-u','-m','experiments.v4_current_v2.api_probe',
                '--cards',self.args.cards,'--out',str(self.run/'api_acceptance')],self.run/'api_acceptance.log',timeout=220)
            self.stop_api()
            self.status('collecting_four_current_cards')
            with ThreadPoolExecutor(max_workers=2) as pool:
                fs={pool.submit(self.episode,card,'search',0,collect=True,wall_limit=1800,prefix='collection'):card for card in CARDS}
                collected=[]
                for f in as_completed(fs):
                    r=f.result();collected.append(r);self.results.append(dict(r,mode='teacher-collection'))
                    self.report()
            if not all(r['survey_complete'] for r in collected):
                raise RuntimeError('A collection rollout did not reach the end of the current card; refusing partial chronological-split training')
            from .experiment import combine_datasets
            combine_datasets([self.run/'collection'/f'search-{card}'/'dataset.npz' for card in CARDS],self.run/'dataset.npz')
            self.status('training_current_sky_ranker')
            free=idle_gpus();time.sleep(3);available=sorted(free & idle_gpus())
            if not available:raise RuntimeError('No idle GPU for training; existing jobs untouched')
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(available[-1]))
            self.command([sys.executable,'-B','-u','-m','experiments.v4_current_v2.learning',str(self.run/'dataset.npz'),
                str(self.run/'training'),'--device','cuda:0','--seed','17','--epochs','20'],
                self.run/'training.log',env=env,timeout=1800)
            self.training=json.loads((self.run/'training/training.json').read_text())
            self.status('evaluating_paired_numeric_policies')
            with ThreadPoolExecutor(max_workers=2) as pool:
                fs=[pool.submit(self.episode,c,m,1) for m in ('greedy','search','learned') for c in CARDS]
                for f in as_completed(fs):self.results.append(f.result());self.report()
            self.status('loading_qwen27b_api')
            self.start_api()
            self.status('evaluating_qwen27b_agent')
            for card in CARDS:
                self.results.append(self.episode(card,'agent',1))
                self.report()
            self.status('packaging_and_reporting')
            self.package()
            self.stage='complete'
            atomic_json(self.run/'complete.json',dict(stage=self.stage,scope=SCOPE,official_score=None,
                elapsed_seconds=time.monotonic()-self.start,results=self.results,training=self.training))
            self.status('complete')
        except Exception as exc:
            self.error=str(exc)
            atomic_json(self.run/'failed.json',dict(stage=self.stage,error=str(exc),elapsed_seconds=time.monotonic()-self.start))
            self.status('failed')
            raise
        finally:
            self.stop_api()
            for p in self.children:
                if p.poll() is None:
                    p.terminate()
                    try:p.wait(timeout=10)
                    except subprocess.TimeoutExpired:p.kill();p.wait()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',required=True);ap.add_argument('--cards',required=True)
    ap.add_argument('--model-dir',required=True)
    Queue(ap.parse_args()).execute()


if __name__=='__main__':main()
