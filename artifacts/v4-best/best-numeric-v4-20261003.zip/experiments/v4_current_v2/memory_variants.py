"""Public-feedback calibration variants; no environment truth is accessible."""
from .public_state import PublicState


class CalibratedPublicState(PublicState):
    """Undo the SAME conservative Q used to predict an unsaturated exposure.

    The legacy estimate multiplies actual/predicted by the unadjusted prior,
    even though prediction used prior - uncertainty/2. That introduces upward
    bias every time feedback is ingested. Completion bounds stay unchanged.
    """
    def record_action(self, action, prediction=None):
        super().record_action(action, prediction)
        if prediction and self.pending['kind'] == 'observe':
            state = self._last_state or {}
            reference = prediction.get('quality_reference', max(0.,
                float(state.get('quality_estimate', self.scoring.get('q0', .68)))
                - .5 * max(0., float(state.get('quality_uncertainty', 0.)))))
            self.pending['quality_prior'] = float(reference)


def make_memory(payload, variant='legacy'):
    if variant == 'legacy':
        return PublicState(payload)
    if variant == 'calibrated':
        return CalibratedPublicState(payload)
    raise ValueError('Unknown public belief variant: ' + str(variant))
