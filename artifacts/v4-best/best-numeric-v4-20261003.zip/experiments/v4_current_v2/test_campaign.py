"""Protect promotion and deadline behavior, not a mirror of policy scores."""
import tempfile
from pathlib import Path
import unittest
from .campaign import Campaign,rankings,viable_agent


def row(name,card,score,complete=True):
    return dict(config_id=name,card=card,episode=2,weather_profile='nominal',
        proxy_total=score,survey_complete=complete,invalid_assignments=0)


class CampaignTests(unittest.TestCase):
    def test_pairing_ignores_different_weather_and_deduplicates(self):
        base=row('reference','alpha',10)
        extra=dict(row('candidate','alpha',100),weather_profile='adverse')
        data=[base,dict(base),row('candidate','alpha',15),extra]
        scores={x['config_id']:x for x in rankings(data)}
        self.assertEqual(scores['reference']['pairs'],1)
        self.assertEqual(scores['candidate']['mean_delta'],5)

    def test_incomplete_season_cannot_win(self):
        data=[row('reference','alpha',10),row('candidate','alpha',1e6,False)]
        self.assertNotIn('candidate',{x['config_id'] for x in rankings(data)})

    def test_reference_missing_planned_card_blocks_promotion(self):
        q=object.__new__(Campaign);q.stage='test';q.configs={'candidate':{'config_id':'candidate'}}
        q.decision=lambda *args,**kwargs:None
        with tempfile.TemporaryDirectory() as directory:
            q.run=Path(directory)
            rows=[row('reference','alpha',10),row('candidate','alpha',20),row('candidate','delta',30)]
            result=q.promote(rows,expected_cases=[('alpha',2,'nominal'),('delta',2,'nominal')])
            self.assertEqual(result,[])
            (q.run/'test-ranking.json').unlink()

    def test_agent_needs_actual_two_role_work(self):
        r=row('candidate','alpha',10)
        r['agent']=dict(valid_group_plans=1,interpretations=0,changed_group_plans=1)
        self.assertFalse(viable_agent(r))
        r['agent']['interpretations']=1
        self.assertTrue(viable_agent(r))

if __name__=='__main__':unittest.main()
