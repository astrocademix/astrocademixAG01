import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from . import learning as base
from . import learning_variants as variants
from .test_learning import fixture, META


class VariantTests(unittest.TestCase):
    def test_domain_does_not_use_night_episode_or_strategy(self):
        a = variants.training_domain('alpha:episode1:adverse:greedy:legacy:night4:decision6')
        b = variants.training_domain('alpha:episode100:adverse:beam:calibrated:night35:decision9')
        self.assertEqual(a, b)
        self.assertEqual(a, 'alpha:adverse')
        self.assertEqual(variants.training_domain('alpha:episode0:night8:decision4'), 'alpha:unspecified')

    def test_rank_prior_has_ties_and_unit_invariance(self):
        values = np.asarray([4,1,4,8], dtype=float)
        np.testing.assert_array_equal(variants.rank_prior(values), variants.rank_prior(values*130+19))
        self.assertEqual(variants.rank_prior(values)[0], variants.rank_prior(values)[2])
        np.testing.assert_array_equal(variants.rank_prior([5,5,5]), np.zeros(3))

    def test_residual_is_bounded_and_requires_baseline(self):
        baseline = np.arange(12, dtype=float)
        neural = np.linspace(-100,100,12)
        combined = variants.transform_scores(neural, baseline, 'baseline_residual')
        self.assertTrue(np.all(abs(combined-variants.rank_prior(baseline)) <= variants.RESIDUAL_LIMIT+1e-7))
        with self.assertRaisesRegex(ValueError, 'requires'):
            variants.transform_scores(neural, None, 'baseline_residual')

    def test_diversity_spends_same_budget_on_distinct_candidates(self):
        baseline = np.arange(16, dtype=float)
        prediction = variants.transform_scores(baseline, baseline, 'shortlist_diversity')
        selected = base.shortlist(prediction, baseline, 8, 'hybrid')
        self.assertEqual(len(set(selected.tolist())), 8)
        self.assertTrue(set(range(12,16)).issubset(selected))
        learned = np.argsort(-prediction)[:4]
        self.assertTrue(set(learned).isdisjoint(range(12,16)))

    def test_group_transform_does_not_mix_candidate_sets(self):
        baseline = np.asarray([1.,2.,3.,100.,200.,300.])
        neural = np.zeros(6)
        result = variants.transform_scores(neural, baseline, 'baseline_residual', np.repeat(['a','b'],3))
        np.testing.assert_array_equal(result, [-1,0,1,-1,0,1])

    @unittest.skipUnless(importlib.util.find_spec('torch'), 'Torch unavailable locally; run on server')
    def test_training_export_and_immutable_outputs(self):
        import torch
        torch.set_num_threads(min(2,torch.get_num_threads()))
        root = Path(tempfile.mkdtemp(prefix='test-variant-', dir=Path(__file__).resolve().parent))
        try:
            np.savez_compressed(root/'dataset.npz', **fixture(), metadata_json=np.asarray(json.dumps(META)))
            for name in variants.VARIANTS:
                result = variants.train(root/'dataset.npz', root/name, variant=name, device='cpu', epochs=2)
                self.assertEqual(result['test_evaluations'], 1)
                self.assertLess(result['export_validation_max_absolute_error'], 1e-3)
                predictor = variants.load_variant(root/name)
                data = fixture()
                scores = predictor(data['maps'][:12], data['scalars'][:12], baseline=data['baseline'][:12])
                self.assertTrue(np.isfinite(scores).all())
                with self.assertRaises(FileExistsError):
                    variants.train(root/'dataset.npz', root/name, variant=name, device='cpu', epochs=1)
        finally:
            # Exact-file cleanup is safe on NFS with stale readdir results.
            for name in variants.VARIANTS:
                for artifact in ('run.started.json','config.json','progress.jsonl','best.pt','weights.npz',
                                 'variant.json','heldout_predictions.npz','training.json'):
                    (root/name/artifact).unlink(missing_ok=True)
                if (root/name).exists():
                    (root/name).rmdir()
            (root/'dataset.npz').unlink(missing_ok=True)
            root.rmdir()


if __name__ == '__main__':
    unittest.main()
