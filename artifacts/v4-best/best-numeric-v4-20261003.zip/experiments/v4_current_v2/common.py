"""Run metadata and clocks shared by the current-card experiments."""
from datetime import datetime, timezone
import json
from pathlib import Path

CARDS = ('alpha', 'beta', 'gamma', 'delta')
SCOPE = ('Current public catalogues and calendars, with explicitly synthetic hidden '
         'weather/events and independently implemented approximate geometry/scoring. '
         'These are development proxy scores, never official leaderboard scores.')


def timestamp(value):
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def utc(value):
    return datetime.fromtimestamp(float(value), timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n')
    temporary.replace(path)


def required_missing(catalogue, factors):
    threshold = catalogue.score_config['required']['observed_factor_threshold']
    return sum(bool(required) and factors.get(str(tid), 0.) < threshold
               for tid, required in zip(catalogue.ids, catalogue.required))


def planning_duration_floor(state, nights, decision_seconds, wall_remaining):
    """Choose time granularity from measured compute cost and remaining season.

    This is a planning approximation, not a change to legal exposure bounds.
    Reserve 35% of remaining wall time for model calls, feedback and variability.
    Astronomy/requests can still end a feasible exposure sooner at a boundary.
    """
    import math
    now=timestamp(state['now_utc'])
    seconds=sum(max(0.,timestamp(n['observing_end_utc'])-max(now,timestamp(n['observing_start_utc'])))
                for n in nights)
    predicted=seconds*max(.02,float(decision_seconds))/max(1.,float(wall_remaining)*.65)
    return int(min(600,max(60,30*math.ceil(predicted/30))))
