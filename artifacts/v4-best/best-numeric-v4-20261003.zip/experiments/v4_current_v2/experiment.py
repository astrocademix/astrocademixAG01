"""Current-card, one-training-seed, end-to-end development experiments.

The agent sees only official-shaped public messages from DevelopmentSurvey.
Private synthetic truth is used exclusively for environment transitions and the
final separately-labelled proxy report. No v3 decisions CSV is a v4 submission.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import time
import numpy as np

from .common import CARDS, SCOPE, atomic_json, timestamp, utc, planning_duration_floor
from .planner import Catalogue, Planner, MAP_CHANNELS, SCALAR_NAMES, PLANNING_BUDGET
from .environment import DevelopmentSurvey
from .public_state import PublicState
from .agent import GroupAgent, DEFAULT_CONTROLS
from .learning import load_predictor, shortlist


def _features(candidates):
    return (np.stack([c['maps'] for c in candidates]).astype(np.float32),
            np.stack([c['scalars'] for c in candidates]).astype(np.float32))


def run_episode(cards, card, out, mode='search', episode=0, seed=17, checkpoint=None,
                collect=False, max_nights=None, wall_limit=900, max_steps=12000,
                strategy='baseline', belief_variant='legacy', agent_variant='baseline',
                learning_variant=False, max_api_calls=8, weather_profile='nominal',
                shortlist_mode='hybrid', collection_samples=2, collection_duration=180):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    cat = Catalogue.from_directory(Path(cards) / card)
    env = DevelopmentSurvey(cat, episode=episode, seed=seed, max_nights=max_nights, weather_profile=weather_profile)
    from .memory_variants import make_memory
    memory = make_memory(env.initialize_payload(), belief_variant)
    if strategy == 'baseline':
        planner = Planner(cat)
    else:
        from .strategy import make_planner
        planner = make_planner(cat, strategy)
    predictor = None
    if checkpoint and mode in ('learned', 'agent'):
        if learning_variant:
            from .learning_variants import load_variant
            predictor = load_variant(checkpoint)
        else:
            predictor = load_predictor(checkpoint)
    director = None
    if mode == 'agent':
        if agent_variant == 'baseline':
            director = GroupAgent(cat, out/'api_trace.jsonl', max_calls=max_api_calls)
        else:
            from .agent_variants import make_agent
            director = make_agent(cat, out/'api_trace.jsonl', agent_variant, max_calls=max_api_calls)
    controls = dict(DEFAULT_CONTROLS)
    records = []
    selected_per_night = {}
    decisions_per_night = {}
    timing = dict(proposal_seconds=0., teacher_seconds=0., learned_seconds=0., environment_seconds=0.)
    started = time.monotonic()
    candidate_count = teacher_count = learned_uses = reports = waits_considered = waits_accepted = 0
    replan_candidates = wait_candidates = 0
    low_feedback = 0
    previous_q = None
    termination = 'unknown'
    trace = (out/'actions.jsonl').open('x')
    csv_file = (out/'trajectory.csv').open('x', newline='')
    writer = csv.DictWriter(csv_file, fieldnames=['decision','now_utc','night','action','duration_seconds',
        'pointing_ra_deg','predicted_gain','assigned_count','hit_count','observed_science','wall_seconds'])
    writer.writeheader()
    try:
        for step in range(max_steps):
            elapsed = time.monotonic()-started
            if env.done:
                termination = 'survey_complete'
                break
            if elapsed >= wall_limit:
                termination = 'development_wallclock_expired'
                break
            payload = env.public_payload(elapsed, wall_limit)
            state = memory.update(payload)
            night = int(state['night_index'])
            decisions_per_night[night] = decisions_per_night.get(night, 0)+1
            remaining = wall_limit-elapsed
            cost=(timing['proposal_seconds']+timing['teacher_seconds'])/max(1,step) if step else .10
            state['min_planning_duration'] = collection_duration if collect else planning_duration_floor(state,env.nights,cost,remaining)
            # Reserve wall time for the rest of the season. This is a real runtime
            # fallback, recorded in the trace, not a successful neural decision.
            max_candidates = min(int(controls.get('candidate_budget', 48)), 32)
            if collect:
                max_candidates = 48
            fast = remaining < max(60., state['remaining_nights'] * 15)
            if fast:
                max_candidates = 16
            mark = time.monotonic()
            candidates = planner.propose(state, controls, max_candidates=max_candidates)
            timing['proposal_seconds'] += time.monotonic()-mark
            candidate_count += len(candidates)
            if director and wall_limit - (time.monotonic() - started) > 110:
                if director.maybe_replan(state, candidates):
                    controls = dict(director.controls)
                    mark = time.monotonic()
                    candidates = planner.propose(state, controls, max_candidates=min(16 if fast else 32, controls['candidate_budget']))
                    timing['proposal_seconds'] += time.monotonic()-mark
                    replan_candidates += len(candidates)
                    candidate_count += len(candidates)
            remaining = wall_limit - (time.monotonic() - started)
            if remaining <= 0:
                termination = 'development_wallclock_expired'
                break
            chosen = None
            teacher = None
            if candidates:
                base = np.asarray([c['rate'] for c in candidates], dtype=np.float32)
                selection = np.asarray(planner.selection_values(candidates, state), dtype=np.float32) if hasattr(planner, 'selection_values') else base
                maps, scalars = _features(candidates)
                # Data are split by complete nights BEFORE candidate generation.
                # All candidates, states and weather in one night stay together.
                sample = (collect and selected_per_night.get(night, 0) < collection_samples and
                          (decisions_per_night[night] - 1) % 6 == 0 and len(candidates) >= 2)
                if sample:
                    mark = time.monotonic()
                    teacher = planner.teacher_targets(candidates, state, controls)
                    timing['teacher_seconds'] += time.monotonic()-mark
                    teacher_count += len(candidates)
                    fold = 'train' if night < 24 else 'validation' if night < 31 else 'test'
                    group = f'{card}:episode{episode}:{weather_profile}:{strategy}:{belief_variant}:night{night}:decision{step}'
                    records.append(dict(maps=maps, scalars=scalars, target=np.asarray(teacher,dtype=np.float32),
                        baseline=base, group_id=np.full(len(candidates), group), split=np.full(len(candidates), fold)))
                    selected_per_night[night] = selected_per_night.get(night, 0)+1
                if mode == 'greedy' or fast or (collect and teacher is None):
                    best = int(selection.argmax())
                else:
                    if predictor:
                        mark = time.monotonic()
                        prediction = predictor.score_candidates(maps, scalars, base) if hasattr(predictor, 'score_candidates') else predictor.predict(maps, scalars)
                        timing['learned_seconds'] += time.monotonic()-mark
                        indices = shortlist(prediction, selection, min(8,len(candidates)), mode=shortlist_mode)
                        learned_uses += 1
                    else:
                        indices = np.argsort(-selection, kind='stable')[:8]
                    if director and hasattr(director, 'shortlist_indices'):
                        directed = list(director.shortlist_indices(candidates, k=min(4,len(candidates))))
                        merged = list(indices[:4]) + directed + list(indices)
                        indices = np.asarray(list(dict.fromkeys(int(i) for i in merged))[:min(8,len(candidates))])
                    if teacher is None:
                        mark = time.monotonic()
                        values = planner.teacher_targets(candidates, state, controls, indices=indices)
                        timing['teacher_seconds'] += time.monotonic()-mark
                        teacher_count += len(indices)
                    else:
                        values = np.asarray(teacher)[indices]
                    best = int(indices[int(np.argmax(values))])
                chosen = candidates[best]
                action = chosen['action']
                # A bounded optional delayed observation is accepted only after
                # accounting for the consumed wait and current-science opportunity.
                from .decision_tools import checked_wait
                mark=time.monotonic()
                checked,accepted=checked_wait(planner,cat,state,chosen,controls,step,
                    wall_limit-(time.monotonic()-started))
                timing['teacher_seconds']+=time.monotonic()-mark
                waits_considered+=int(checked);wait_candidates+=int(checked);teacher_count+=int(checked)
                if accepted:
                    action=dict(action='wait',duration_seconds=int(controls['wait_seconds']))
                    chosen=None;waits_accepted+=1
            else:
                action = dict(action='wait', duration_seconds=900)
            # Conservative feedback-based instrument check, shared by every
            # policy. Weather alone is ambiguous: require repeated discrepancy,
            # cap attempts and respect the report action limit.
            q = float(state['quality_estimate'])
            if previous_q is not None and q < .35 * previous_q:
                low_feedback += 1
            elif q > .50:
                low_feedback = 0
            if previous_q is None or q > previous_q:
                previous_q = q
            if low_feedback >= 3 and reports < 3 and step % 8 == 0:
                action = dict(action='report'); chosen = None
                reports += 1; low_feedback = 0; previous_q = q
            if time.monotonic() - started >= wall_limit:
                termination = 'development_wallclock_expired'
                break
            memory.record_action(action, prediction=chosen)
            mark = time.monotonic()
            result = env.step(action)
            timing['environment_seconds'] += time.monotonic()-mark
            if director and chosen:
                director.observe_feedback(state, chosen, result)
            row = dict(decision=step, now_utc=state['now_utc'], night=night,
                action=action['action'], duration_seconds=action.get('duration_seconds',0),
                pointing_ra_deg=chosen.get('pointing_ra_deg','') if chosen else '',
                predicted_gain=chosen.get('est_gain',0.) if chosen else 0.,
                assigned_count=len(action.get('assignments',{})), hit_count=result.get('hit_count',0),
                observed_science=sum(h['score'] for h in result.get('hits',[])), wall_seconds=time.monotonic()-started)
            writer.writerow(row)
            trace.write(json.dumps(dict(**row, command=action, result=result),ensure_ascii=False)+'\n')
            if step % 25 == 0:
                trace.flush(); csv_file.flush()
                atomic_json(out/'status.json', dict(stage='running',card=card,mode=mode,night=night,
                    actions=step+1,elapsed_seconds=time.monotonic()-started,remaining_seconds=max(0,wall_limit-(time.monotonic()-started))))
        else:
            termination = 'development_action_cap'
    except Exception as exc:
        atomic_json(out/'error.json', dict(stage='episode_failed',card=card,mode=mode,
            error_type=type(exc).__name__,error=str(exc),elapsed_seconds=time.monotonic()-started))
        atomic_json(out/'status.json', dict(stage='failed',card=card,mode=mode,
            error_type=type(exc).__name__,error=str(exc)))
        raise
    finally:
        trace.close(); csv_file.close()
    elapsed = time.monotonic()-started
    result = dict(env.summary(),card=card,mode=mode,seed=seed,episode=episode,
        strategy=strategy,belief_variant=belief_variant,agent_variant=agent_variant,
        weather_profile=weather_profile,learning_variant=learning_variant,checkpoint=str(checkpoint) if checkpoint else None,
        termination_reason=termination,wall_seconds=elapsed,wall_limit=wall_limit,
        timing=timing,candidates=candidate_count,teacher_evaluations=teacher_count,
        replan_candidates=replan_candidates,wait_candidates=wait_candidates,
        budget_scope='Nominal shortlist k=8 and compute-adaptive exposure granularity; all runtime counted. Not an equal-compute benchmark. Collection uses 180s minimum planning granularity and cheap greedy decisions between labelled states.',
        learned_shortlist_decisions=learned_uses,training_groups=len(records),
        waits_considered=waits_considered,waits_accepted=waits_accepted,
        agent=director.summary() if director else None)
    if records:
        arrays={k:np.concatenate([r[k] for r in records]) for k in records[0]}
        metadata = dict(scope=SCOPE,cards=[card],training_seed=seed,planning_budget=PLANNING_BUDGET,
            strategy=strategy,belief_variant=belief_variant,weather_profile=weather_profile,episode=episode,
            feature_schema=dict(maps=list(MAP_CHANNELS),scalars=list(SCALAR_NAMES)),
            label_definition='Public-estimate finite two-step joint planning value with remaining-time science opportunity approximation; same budget for every first candidate; not official terminal return.',
            teacher_is_official=False,target_is_residual=False,
            split_method='Whole chronological nights:0..23 train,24..30 validation,31..37 test. Same public card; not unseen-catalogue generalization.')
        temporary = out/'dataset.npz.tmp'
        with temporary.open('xb') as f:
            np.savez_compressed(f,**arrays,metadata_json=np.asarray(json.dumps(metadata)))
        temporary.replace(out/'dataset.npz')
        result['dataset_samples']=len(arrays['target'])
        result['dataset_sha256']=hashlib.sha256((out/'dataset.npz').read_bytes()).hexdigest()
    atomic_json(out/'result.json',result)
    atomic_json(out/'status.json',dict(stage='complete',**result))
    return result


def combine_datasets(paths, destination):
    keys=('maps','scalars','target','baseline','group_id','split')
    data={k:[] for k in keys}; sources=[]; metadata=None; seen_groups=set(); actual_cards=set()
    for path in paths:
        path=Path(path)
        with np.load(path,allow_pickle=False) as z:
            current=json.loads(str(z['metadata_json'].item()))
            if metadata and current['feature_schema'] != metadata['feature_schema']:
                raise ValueError('Dataset schema mismatch')
            if set(z['split'].tolist()) != {'train','validation','test'}:
                raise ValueError(f'Incomplete chronological split coverage in {path}')
            groups=set(z['group_id'].tolist())
            if seen_groups & groups:
                raise ValueError('Candidate groups duplicated across collected datasets')
            seen_groups.update(groups)
            actual_cards.update(current['cards'])
            metadata=current
            for k in keys:data[k].append(z[k])
        sources.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            metadata=current))
    if actual_cards != set(CARDS):
        raise ValueError('Combined training dataset must include all four current cards')
    metadata=dict(metadata,cards=sorted(actual_cards),source_datasets=sources)
    for key in ('strategy','belief_variant','weather_profile','episode'):
        values=sorted({str(s['metadata'].get(key,'legacy_unspecified')) for s in sources})
        metadata.pop(key,None);metadata[key+'_values']=values
    with Path(destination).open('xb') as f:
        np.savez_compressed(f,**{k:np.concatenate(v) for k,v in data.items()},metadata_json=np.asarray(json.dumps(metadata)))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--cards',required=True);ap.add_argument('--card',choices=CARDS,required=True)
    ap.add_argument('--out',required=True);ap.add_argument('--mode',choices=['greedy','search','learned','agent'],default='search')
    ap.add_argument('--checkpoint');ap.add_argument('--episode',type=int,default=0)
    ap.add_argument('--collect',action='store_true');ap.add_argument('--max-nights',type=int)
    ap.add_argument('--wall-limit',type=float,default=900)
    ap.add_argument('--strategy',default='baseline');ap.add_argument('--belief-variant',choices=['legacy','calibrated'],default='legacy')
    ap.add_argument('--agent-variant',default='baseline');ap.add_argument('--max-api-calls',type=int,default=8)
    ap.add_argument('--learning-variant',action='store_true');ap.add_argument('--shortlist-mode',choices=['baseline','learned','hybrid'],default='hybrid')
    ap.add_argument('--weather-profile',choices=['nominal','adverse','variable','clear'],default='nominal')
    ap.add_argument('--collection-samples',type=int,default=2);ap.add_argument('--collection-duration',type=int,default=180)
    a=ap.parse_args()
    print(json.dumps(run_episode(**vars(a)),ensure_ascii=False))


if __name__=='__main__':main()
