"""Numerical incumbent entry point; not an API-enabled submission claim."""
import os
from pathlib import Path
root=Path(__file__).resolve().parent
os.environ.update(NUMERIC_NO_LLM='1',USE_LLM='0',PLANNING_STRATEGY='fibre_pack',BELIEF_VARIANT='calibrated',LEARNING_VARIANT='1',SKY_WEIGHTS=str(root/'weights/weights.npz'))
from experiments.v4_current_v2.live_agent import run
if __name__ == '__main__':
    raise SystemExit(run())
