# 当前最佳平均分数值方案（2026-10-03）

配置：`expanded-shortlist_diversity`，即光纤网格重排 `fibre_pack`＋质量校准 `calibrated`＋多天气训练的互补候选 CNN，训练种子17。

35个新增配对开发情景的平均分 **6700.94**，旧混合CNN参考 **6137.97**，平均提升 **562.97 / 9.17%**，胜出 **34/35**。明细在 `evidence/paired_results.json`，汇总在 `evidence/summary.json`。

**这些是公开目录＋合成天气/事件上的开发代理分，不是官方排行榜成绩。** 此方案未跑预留的episode100/101最终确认。分数来自experiment.py闭环评估；JSONL部署入口没有官方云端成绩，不能将该代理分当成压缩包的官方提交成绩。

## 内容与边界

- 源码取自服务器该次运行的冻结快照，包含规划、天空特征、学习、公共状态与实验环境。
- `weights/` 为实际选中的小CNN NumPy权重、变体清单和训练记录；不是27B模型权重。
- 不含API密钥、服务器token、原始API调用日志或隐藏比赛数据。
- 默认明确关闭LLM/API，保留数值方案配置。**因此本包不能声称已满足要求接入API/LLM的比赛提交条件。** Agent源码保留供后续整合，开启Agent后的成绩必须另测。
- 保留了原始实验和部署入口的区别：要复核所列代理分，应使用下方experiment命令与相同公开数据；不要用部署入口结果代替。

## 本地开发复核

```bash
python3 -m pip install -r requirements.txt
python3 -m experiments.v4_current_v2.experiment \
  --cards /path/to/current-public-cards \
  --card alpha --episode 200 --weather-profile nominal \
  --mode learned --strategy fibre_pack --belief-variant calibrated \
  --learning-variant --checkpoint weights --wall-limit 900 \
  --out results/alpha-e200
```

公开cards目录包含alpha/beta/gamma/delta的config与public文件。其余情景号/天气见配对明细。策略有基于实测耗时的自适应计算预算，不保证换机器后逐位重现得分。

JSONL-v4入口：`python3 -u run_agent.py`。

训练源码依赖PyTorch，但数值推理只需NumPy；本包无需下载Qwen。`SHA256SUMS.json`记录除自身之外的文件哈希。
